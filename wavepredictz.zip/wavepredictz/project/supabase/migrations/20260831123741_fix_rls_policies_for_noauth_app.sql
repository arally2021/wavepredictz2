/*
# Fix RLS policies for no-auth app

## Problem
The app has no sign-in screen, so the frontend uses the anon key for all
database operations. However, RLS policies on `analyses`, `memory_semantic`,
`memory_episodes`, and `event_log` are scoped to `authenticated` only.
This means every SELECT returns zero rows (Historical Facility shows null)
and every INSERT silently fails (patterns and analyses are never stored).

## Fix
Replace all `authenticated`-only policies on these four tables with
`anon, authenticated` policies so the anon-key client can read and write.
This is appropriate because the app is single-tenant with no user accounts —
all data is intentionally shared/public.

## Tables affected
- `analyses` — football match analysis records
- `memory_semantic` — extracted tactical patterns (semantic memory)
- `memory_episodes` — individual pattern observations (episodic memory)
- `event_log` — system event audit log
*/

-- analyses: drop old authenticated-only policies, add anon+authenticated policies
DROP POLICY IF EXISTS "Users can insert own analyses" ON analyses;
DROP POLICY IF EXISTS "Users can view own analyses" ON analyses;

CREATE POLICY "anon_select_analyses" ON analyses FOR SELECT
  TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_analyses" ON analyses FOR INSERT
  TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_analyses" ON analyses FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_analyses" ON analyses FOR DELETE
  TO anon, authenticated USING (true);

-- memory_semantic: drop old authenticated-only policies, add anon+authenticated policies
DROP POLICY IF EXISTS "Authenticated users can insert semantic memory" ON memory_semantic;
DROP POLICY IF EXISTS "Authenticated users can view semantic memory" ON memory_semantic;

CREATE POLICY "anon_select_memory_semantic" ON memory_semantic FOR SELECT
  TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_memory_semantic" ON memory_semantic FOR INSERT
  TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_memory_semantic" ON memory_semantic FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_memory_semantic" ON memory_semantic FOR DELETE
  TO anon, authenticated USING (true);

-- memory_episodes: drop old authenticated-only policies, add anon+authenticated policies
DROP POLICY IF EXISTS "Authenticated users can insert memory episodes" ON memory_episodes;
DROP POLICY IF EXISTS "Authenticated users can view memory episodes" ON memory_episodes;

CREATE POLICY "anon_select_memory_episodes" ON memory_episodes FOR SELECT
  TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_memory_episodes" ON memory_episodes FOR INSERT
  TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_memory_episodes" ON memory_episodes FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_memory_episodes" ON memory_episodes FOR DELETE
  TO anon, authenticated USING (true);

-- event_log: drop old authenticated-only policies, add anon+authenticated policies
DROP POLICY IF EXISTS "Authenticated users can insert events" ON event_log;
DROP POLICY IF EXISTS "Authenticated users can view event log" ON event_log;

CREATE POLICY "anon_select_event_log" ON event_log FOR SELECT
  TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_event_log" ON event_log FOR INSERT
  TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_event_log" ON event_log FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_event_log" ON event_log FOR DELETE
  TO anon, authenticated USING (true);
