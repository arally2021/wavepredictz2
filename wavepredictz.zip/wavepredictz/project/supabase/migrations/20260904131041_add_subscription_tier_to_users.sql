-- Add subscription tier column to users table
ALTER TABLE users ADD COLUMN IF NOT EXISTS subscription_tier text NOT NULL DEFAULT 'free';

-- Create index for quick tier lookups
CREATE INDEX IF NOT EXISTS idx_users_subscription_tier ON users(subscription_tier);

-- Update RLS policies for users table (no-auth app: anon+authenticated can read own row)
-- Allow anon and authenticated to read user data
DROP POLICY IF EXISTS "select_users" ON users;
CREATE POLICY "select_users" ON users FOR SELECT
  TO anon, authenticated USING (true);

-- Allow users to update their own subscription tier (via service role from edge functions)
-- The actual tier updates happen via Stripe webhook edge functions using service role key
-- so we only need read access for the anon client
DROP POLICY IF EXISTS "update_users_own" ON users;
CREATE POLICY "update_users_own" ON users FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
