-- Add columns needed for Stripe subscription fulfillment
ALTER TABLE users ADD COLUMN IF NOT EXISTS is_active boolean NOT NULL DEFAULT false;
ALTER TABLE users ADD COLUMN IF NOT EXISTS stripe_customer_id text;

-- Index for fast lookups by Stripe customer ID (used by webhook handler)
CREATE INDEX IF NOT EXISTS idx_users_stripe_customer_id ON users(stripe_customer_id);
