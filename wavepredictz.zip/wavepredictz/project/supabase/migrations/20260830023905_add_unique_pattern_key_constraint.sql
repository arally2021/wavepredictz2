-- Add unique constraint on pattern_key to prevent duplicate patterns
-- and enable upsert semantics for the forced-fetch pipeline

-- First remove any existing duplicates (there shouldn't be any, but safeguard)
DELETE FROM memory_semantic a
USING memory_semantic b
WHERE a.id > b.id AND a.pattern_key = b.pattern_key;

-- Make the existing index unique
DROP INDEX IF EXISTS idx_semantic_pattern;
CREATE UNIQUE INDEX idx_semantic_pattern_unique ON public.memory_semantic USING btree (pattern_key);
