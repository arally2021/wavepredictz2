/*
  # WavePredictz Database Schema
  
  1. New Tables
    - `users`
      - `id` (uuid, primary key)
      - `email` (text, unique)
      - `name` (text)
      - `is_premium` (boolean)
      - `created_at` (timestamptz)
    
    - `analyses`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key)
      - `input` (jsonb) - analysis request data
      - `output` (jsonb) - AI response data
      - `created_at` (timestamptz)
    
    - `memory_episodes`
      - `id` (uuid, primary key)
      - `team_id` (text)
      - `type` (text) - e.g., 'match', 'context'
      - `content` (jsonb)
      - `embedding` (jsonb) - optional vector data
      - `confidence` (numeric)
      - `created_at` (timestamptz)
    
    - `memory_semantic`
      - `id` (uuid, primary key)
      - `pattern_key` (text)
      - `pattern_doc` (jsonb)
      - `provenance` (jsonb)
      - `usefulness_score` (numeric)
      - `safety_review` (boolean)
      - `created_at` (timestamptz)
    
    - `pattern_suggestions`
      - `id` (uuid, primary key)
      - `team_id` (text)
      - `suggestion` (jsonb)
      - `status` (text)
      - `created_at` (timestamptz)
    
    - `task_queue`
      - `id` (uuid, primary key)
      - `queue_name` (text)
      - `task` (jsonb)
      - `priority` (numeric)
      - `status` (text)
      - `created_at` (timestamptz)
    
    - `event_log`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key, nullable)
      - `event_type` (text)
      - `details` (jsonb)
      - `created_at` (timestamptz)
  
  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated user access
  
  3. Indexes
    - Index on memory_episodes.team_id for fast lookups
    - Index on analyses.user_id for user queries
    - Index on event_log.event_type for audit queries
*/

-- Users table
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE,
  name text,
  is_premium boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Analyses table
CREATE TABLE IF NOT EXISTS analyses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id),
  input jsonb DEFAULT '{}'::jsonb,
  output jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

-- Episodic memory table
CREATE TABLE IF NOT EXISTS memory_episodes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  team_id text NOT NULL,
  type text DEFAULT 'match',
  content jsonb DEFAULT '{}'::jsonb,
  embedding jsonb DEFAULT '{}'::jsonb,
  confidence numeric DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Semantic memory table (promoted patterns)
CREATE TABLE IF NOT EXISTS memory_semantic (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pattern_key text NOT NULL,
  pattern_doc jsonb DEFAULT '{}'::jsonb,
  provenance jsonb DEFAULT '{}'::jsonb,
  usefulness_score numeric DEFAULT 0,
  safety_review boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Pattern suggestions table
CREATE TABLE IF NOT EXISTS pattern_suggestions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  team_id text NOT NULL,
  suggestion jsonb DEFAULT '{}'::jsonb,
  status text DEFAULT 'pending',
  created_at timestamptz DEFAULT now()
);

-- Task queue table
CREATE TABLE IF NOT EXISTS task_queue (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  queue_name text NOT NULL,
  task jsonb DEFAULT '{}'::jsonb,
  priority numeric DEFAULT 0,
  status text DEFAULT 'queued',
  created_at timestamptz DEFAULT now()
);

-- Event log table
CREATE TABLE IF NOT EXISTS event_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id),
  event_type text NOT NULL,
  details jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_memory_team ON memory_episodes(team_id);
CREATE INDEX IF NOT EXISTS idx_analysis_user ON analyses(user_id);
CREATE INDEX IF NOT EXISTS idx_event_type ON event_log(event_type);
CREATE INDEX IF NOT EXISTS idx_pattern_team ON pattern_suggestions(team_id);
CREATE INDEX IF NOT EXISTS idx_semantic_pattern ON memory_semantic(pattern_key);

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE analyses ENABLE ROW LEVEL SECURITY;
ALTER TABLE memory_episodes ENABLE ROW LEVEL SECURITY;
ALTER TABLE memory_semantic ENABLE ROW LEVEL SECURITY;
ALTER TABLE pattern_suggestions ENABLE ROW LEVEL SECURITY;
ALTER TABLE task_queue ENABLE ROW LEVEL SECURITY;
ALTER TABLE event_log ENABLE ROW LEVEL SECURITY;

-- RLS Policies for users
CREATE POLICY "Users can view own profile"
  ON users FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON users FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- RLS Policies for analyses
CREATE POLICY "Users can view own analyses"
  ON analyses FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own analyses"
  ON analyses FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- RLS Policies for memory_episodes (read-only for authenticated users)
CREATE POLICY "Authenticated users can view memory episodes"
  ON memory_episodes FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert memory episodes"
  ON memory_episodes FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- RLS Policies for memory_semantic (read-only for authenticated users)
CREATE POLICY "Authenticated users can view semantic memory"
  ON memory_semantic FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert semantic memory"
  ON memory_semantic FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- RLS Policies for pattern_suggestions
CREATE POLICY "Authenticated users can view pattern suggestions"
  ON pattern_suggestions FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert pattern suggestions"
  ON pattern_suggestions FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- RLS Policies for task_queue
CREATE POLICY "Authenticated users can view tasks"
  ON task_queue FOR SELECT
  TO authenticated
  USING (true);

-- RLS Policies for event_log
CREATE POLICY "Authenticated users can view event log"
  ON event_log FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert events"
  ON event_log FOR INSERT
  TO authenticated
  WITH CHECK (true);