/*
# Fix RLS policies for remaining no-auth tables

## Problem
Same as the previous migration: the app has no sign-in screen, but many
tables still have `authenticated`-only RLS policies. The anon-key frontend
can't read or write to any of them.

## Fix
Replace `authenticated`-only policies with `anon, authenticated` policies
on all non-Stripe tables. Stripe tables (stripe_customers, stripe_orders,
stripe_subscriptions) keep their authenticated-only policies since payment
data must be tied to real authenticated users.

## Tables affected
- contextual_matches
- human_factor_evaluation
- human_factor_evaluations
- impulsiveness_tracking
- outcome_declarations
- outcomes
- pattern_suggestions
- reliability_assessment
- reliability_assessments
- task_queue
- triangulation_analysis
- triangulation_data
- users (profile table, not auth.users)
*/

-- contextual_matches
DROP POLICY IF EXISTS "Authenticated users can insert contextual matches" ON contextual_matches;
DROP POLICY IF EXISTS "Authenticated users can view contextual matches" ON contextual_matches;
CREATE POLICY "anon_select_contextual_matches" ON contextual_matches FOR SELECT
  TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_contextual_matches" ON contextual_matches FOR INSERT
  TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_contextual_matches" ON contextual_matches FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_contextual_matches" ON contextual_matches FOR DELETE
  TO anon, authenticated USING (true);

-- human_factor_evaluation
DROP POLICY IF EXISTS "Authenticated users can insert human factor" ON human_factor_evaluation;
DROP POLICY IF EXISTS "Authenticated users can view human factor" ON human_factor_evaluation;
CREATE POLICY "anon_select_human_factor_evaluation" ON human_factor_evaluation FOR SELECT
  TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_human_factor_evaluation" ON human_factor_evaluation FOR INSERT
  TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_human_factor_evaluation" ON human_factor_evaluation FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_human_factor_evaluation" ON human_factor_evaluation FOR DELETE
  TO anon, authenticated USING (true);

-- human_factor_evaluations
DROP POLICY IF EXISTS "Users can insert human factor evaluations for own outcomes" ON human_factor_evaluations;
DROP POLICY IF EXISTS "Users can view own human factor evaluations" ON human_factor_evaluations;
CREATE POLICY "anon_select_human_factor_evaluations" ON human_factor_evaluations FOR SELECT
  TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_human_factor_evaluations" ON human_factor_evaluations FOR INSERT
  TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_human_factor_evaluations" ON human_factor_evaluations FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_human_factor_evaluations" ON human_factor_evaluations FOR DELETE
  TO anon, authenticated USING (true);

-- impulsiveness_tracking
DROP POLICY IF EXISTS "Authenticated users can insert impulsiveness" ON impulsiveness_tracking;
DROP POLICY IF EXISTS "Authenticated users can view impulsiveness" ON impulsiveness_tracking;
CREATE POLICY "anon_select_impulsiveness_tracking" ON impulsiveness_tracking FOR SELECT
  TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_impulsiveness_tracking" ON impulsiveness_tracking FOR INSERT
  TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_impulsiveness_tracking" ON impulsiveness_tracking FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_impulsiveness_tracking" ON impulsiveness_tracking FOR DELETE
  TO anon, authenticated USING (true);

-- outcome_declarations
DROP POLICY IF EXISTS "Authenticated users can insert outcome declarations" ON outcome_declarations;
DROP POLICY IF EXISTS "Authenticated users can view outcome declarations" ON outcome_declarations;
CREATE POLICY "anon_select_outcome_declarations" ON outcome_declarations FOR SELECT
  TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_outcome_declarations" ON outcome_declarations FOR INSERT
  TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_outcome_declarations" ON outcome_declarations FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_outcome_declarations" ON outcome_declarations FOR DELETE
  TO anon, authenticated USING (true);

-- outcomes
DROP POLICY IF EXISTS "Users can delete own outcomes" ON outcomes;
DROP POLICY IF EXISTS "Users can insert own outcomes" ON outcomes;
DROP POLICY IF EXISTS "Users can update own outcomes" ON outcomes;
DROP POLICY IF EXISTS "Users can view own outcomes" ON outcomes;
CREATE POLICY "anon_select_outcomes" ON outcomes FOR SELECT
  TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_outcomes" ON outcomes FOR INSERT
  TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_outcomes" ON outcomes FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_outcomes" ON outcomes FOR DELETE
  TO anon, authenticated USING (true);

-- pattern_suggestions
DROP POLICY IF EXISTS "Authenticated users can insert pattern suggestions" ON pattern_suggestions;
DROP POLICY IF EXISTS "Authenticated users can view pattern suggestions" ON pattern_suggestions;
CREATE POLICY "anon_select_pattern_suggestions" ON pattern_suggestions FOR SELECT
  TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_pattern_suggestions" ON pattern_suggestions FOR INSERT
  TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_pattern_suggestions" ON pattern_suggestions FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_pattern_suggestions" ON pattern_suggestions FOR DELETE
  TO anon, authenticated USING (true);

-- reliability_assessment
DROP POLICY IF EXISTS "Authenticated users can insert reliability" ON reliability_assessment;
DROP POLICY IF EXISTS "Authenticated users can view reliability" ON reliability_assessment;
CREATE POLICY "anon_select_reliability_assessment" ON reliability_assessment FOR SELECT
  TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_reliability_assessment" ON reliability_assessment FOR INSERT
  TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_reliability_assessment" ON reliability_assessment FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_reliability_assessment" ON reliability_assessment FOR DELETE
  TO anon, authenticated USING (true);

-- reliability_assessments
DROP POLICY IF EXISTS "Users can insert reliability assessments for own outcomes" ON reliability_assessments;
DROP POLICY IF EXISTS "Users can view own reliability assessments" ON reliability_assessments;
CREATE POLICY "anon_select_reliability_assessments" ON reliability_assessments FOR SELECT
  TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_reliability_assessments" ON reliability_assessments FOR INSERT
  TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_reliability_assessments" ON reliability_assessments FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_reliability_assessments" ON reliability_assessments FOR DELETE
  TO anon, authenticated USING (true);

-- task_queue
DROP POLICY IF EXISTS "Authenticated users can view tasks" ON task_queue;
CREATE POLICY "anon_select_task_queue" ON task_queue FOR SELECT
  TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_task_queue" ON task_queue FOR INSERT
  TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_task_queue" ON task_queue FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_task_queue" ON task_queue FOR DELETE
  TO anon, authenticated USING (true);

-- triangulation_analysis
DROP POLICY IF EXISTS "Authenticated users can insert triangulation" ON triangulation_analysis;
DROP POLICY IF EXISTS "Authenticated users can view triangulation" ON triangulation_analysis;
CREATE POLICY "anon_select_triangulation_analysis" ON triangulation_analysis FOR SELECT
  TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_triangulation_analysis" ON triangulation_analysis FOR INSERT
  TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_triangulation_analysis" ON triangulation_analysis FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_triangulation_analysis" ON triangulation_analysis FOR DELETE
  TO anon, authenticated USING (true);

-- triangulation_data
DROP POLICY IF EXISTS "Users can insert triangulation data for own outcomes" ON triangulation_data;
DROP POLICY IF EXISTS "Users can view own triangulation data" ON triangulation_data;
CREATE POLICY "anon_select_triangulation_data" ON triangulation_data FOR SELECT
  TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_triangulation_data" ON triangulation_data FOR INSERT
  TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_triangulation_data" ON triangulation_data FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_triangulation_data" ON triangulation_data FOR DELETE
  TO anon, authenticated USING (true);

-- users (app profile table, not auth.users)
DROP POLICY IF EXISTS "Users can update own profile" ON users;
DROP POLICY IF EXISTS "Users can view own profile" ON users;
CREATE POLICY "anon_select_users" ON users FOR SELECT
  TO anon, authenticated USING (true);
CREATE POLICY "anon_insert_users" ON users FOR INSERT
  TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon_update_users" ON users FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon_delete_users" ON users FOR DELETE
  TO anon, authenticated USING (true);
