-- Add access_level integer column for feature gating
ALTER TABLE users ADD COLUMN IF NOT EXISTS access_level integer NOT NULL DEFAULT 0;

-- Index for quick access-level checks
CREATE INDEX IF NOT EXISTS idx_users_access_level ON users(access_level);
