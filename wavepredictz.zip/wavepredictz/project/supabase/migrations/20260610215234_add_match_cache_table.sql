-- Match data cache table for storing API responses
CREATE TABLE IF NOT EXISTS match_cache (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  team_name text NOT NULL,
  match_data jsonb DEFAULT '{}'::jsonb,
  stats_summary jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  expires_at timestamptz DEFAULT (now() + interval '24 hours'),
  UNIQUE(team_name)
);

-- Index for fast lookups
CREATE INDEX IF NOT EXISTS idx_match_cache_team ON match_cache(team_name);
CREATE INDEX IF NOT EXISTS idx_match_cache_expires ON match_cache(expires_at);

-- Enable RLS
ALTER TABLE match_cache ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Authenticated users can view match cache"
  ON match_cache FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert match cache"
  ON match_cache FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update match cache"
  ON match_cache FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);