import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import Stripe from "npm:stripe@14.21.0";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

// ---------------------------------------------------------------------------
// Stripe Webhook Handler — Subscription Fulfillment
// ---------------------------------------------------------------------------
// Public endpoint (verify_jwt = false) that receives raw Stripe webhook events,
// verifies the cryptographic signature, and updates user subscription state
// in the database accordingly.
// ---------------------------------------------------------------------------

const STRIPE_SECRET_KEY = Deno.env.get("STRIPE_SECRET_KEY") || "";
const STRIPE_WEBHOOK_SECRET = Deno.env.get("STRIPE_WEBHOOK_SECRET") || "";
const SUPABASE_URL = Deno.env.get("SUPABASE_URL") || "";
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
  auth: { persistSession: false },
});

// ---------------------------------------------------------------------------
// Stripe Product ID → Subscription Tier Configuration Map
// ---------------------------------------------------------------------------
// When a checkout completes or subscription activates, we look up the Stripe
// Product ID from the line items to determine which tier to assign.
//
// Replace the stub values with real Stripe Product IDs from your dashboard:
//   https://dashboard.stripe.com/products
// ---------------------------------------------------------------------------
// Stripe Product ID → Tier + Access Level Configuration Matrix
// ---------------------------------------------------------------------------
// Each product maps to a subscription tier string and a numeric access level.
// Access levels are cumulative: higher levels inherit all lower-level features.
//
//   Level 1 (casual_fans):          match-simulations, W/D/L probabilities, basic dashboard
//   Level 2 (professional_trader):   Level 1 + EV+ value-bets, prop-bet matrices, backtesting
//   Level 3 (b2b_api):               Level 2 + developer data keys, scraper endpoints
//   Level 4 (elite_teams_media):     Level 3 + spatial-tracking, video-alignment (unrestricted)
interface TierConfig {
  tier: string;
  access_level: number;
}

const PRODUCT_TIER_MAP: Record<string, TierConfig> = {
  // Tier 1: Casual Fans — $25/mo
  "prod_VCM7y6YDPZktW1": { tier: "casual_fans", access_level: 1 },

  // Tier 2: Professional Traders & Syndicates — $99/mo
  "prod_VCM5z8R9xiSTp8": { tier: "professional_trader", access_level: 2 },

  // Tier 3: B2B API Integration — $79/mo
  // (stub — replace with real product ID when created in Stripe Dashboard)
  "prod_B2B_PLACEHOLDER": { tier: "b2b_api", access_level: 3 },

  // Tier 4: Elite Teams & Media — $599/mo
  "prod_VCM8W8FwAjKynU": { tier: "elite_teams_media", access_level: 4 },
};

// Fallback tier config when tier is resolved from metadata instead of product ID
const METADATA_TIER_MAP: Record<string, TierConfig> = {
  casual: { tier: "casual_fans", access_level: 1 },
  casual_fans: { tier: "casual_fans", access_level: 1 },
  pro: { tier: "professional_trader", access_level: 2 },
  professional_trader: { tier: "professional_trader", access_level: 2 },
  b2b: { tier: "b2b_api", access_level: 3 },
  b2b_api: { tier: "b2b_api", access_level: 3 },
  elite: { tier: "elite_teams_media", access_level: 4 },
  elite_teams_media: { tier: "elite_teams_media", access_level: 4 },
};

// ---------------------------------------------------------------------------
// Database Operations
// ---------------------------------------------------------------------------

/**
 * Resolve a Stripe customer to a Supabase user record.
 * Tries client_reference_id (supabase_uid) first, then stripe_customer_id,
 * then falls back to email lookup.
 */
async function findUserByStripeCustomer(
  stripe: Stripe,
  customerId: string,
  clientReferenceId?: string
): Promise<{ id: string; email: string | null } | null> {
  // 1. If client_reference_id is a UUID, look up directly by user id
  if (clientReferenceId) {
    console.log(`[webhook] Looking up user by client_reference_id: ${clientReferenceId}`);
    const { data, error } = await supabase
      .from("users")
      .select("id, email")
      .eq("id", clientReferenceId)
      .maybeSingle();

    if (data) {
      console.log(`[webhook] Found user by client_reference_id: ${data.id}`);
      return data;
    }
    if (error) {
      console.warn(`[webhook] Error looking up by client_reference_id: ${error.message}`);
    }
  }

  // 2. Try stripe_customer_id column on users table
  console.log(`[webhook] Looking up user by stripe_customer_id: ${customerId}`);
  const { data: byCustomerId, error: custError } = await supabase
    .from("users")
    .select("id, email")
    .eq("stripe_customer_id", customerId)
    .maybeSingle();

  if (byCustomerId) {
    console.log(`[webhook] Found user by stripe_customer_id: ${byCustomerId.id}`);
    return byCustomerId;
  }
  if (custError) {
    console.warn(`[webhook] Error looking up by stripe_customer_id: ${custError.message}`);
  }

  // 3. Fall back to email — retrieve customer from Stripe to get email
  console.log(`[webhook] Falling back to email lookup via Stripe customer: ${customerId}`);
  try {
    const customer = await stripe.customers.retrieve(customerId);
    if (customer && !customer.deleted && customer.email) {
      const { data: byEmail, error: emailError } = await supabase
        .from("users")
        .select("id, email")
        .eq("email", customer.email)
        .maybeSingle();

      if (byEmail) {
        console.log(`[webhook] Found user by email: ${byEmail.id}`);
        return byEmail;
      }
      if (emailError) {
        console.warn(`[webhook] Error looking up by email: ${emailError.message}`);
      }
    }
  } catch (err) {
    console.warn(`[webhook] Failed to retrieve Stripe customer for email lookup: ${err}`);
  }

  return null;
}

/**
 * Resolve the subscription tier from a Stripe subscription's line items.
 * Fetches the product ID from each price and maps it via PRODUCT_TIER_MAP.
 */
async function resolveTierFromSubscription(
  stripe: Stripe,
  subscription: Stripe.Subscription
): Promise<TierConfig | null> {
  console.log(`[webhook] Resolving tier from subscription: ${subscription.id}`);

  // Expand line items to get price + product IDs
  const items = await stripe.subscriptions.listLineItems(subscription.id, {
    expand: ["data.price.product"],
  });

  for (const item of items.data) {
    const price = item.price;
    if (!price) continue;

    // price.product can be a string or an expanded Product object
    let productId: string | undefined;
    if (typeof price.product === "string") {
      productId = price.product;
    } else if (price.product && "id" in price.product) {
      productId = price.product.id;
    }

    if (productId && PRODUCT_TIER_MAP[productId]) {
      const config = PRODUCT_TIER_MAP[productId];
      console.log(`[webhook] Mapped product ${productId} → tier: ${config.tier}, access_level: ${config.access_level}`);
      return config;
    }
  }

  // Fallback: check subscription metadata for a tier key (set at checkout)
  const metadataTier = subscription.metadata?.tier;
  if (metadataTier && METADATA_TIER_MAP[metadataTier]) {
    const config = METADATA_TIER_MAP[metadataTier];
    console.log(`[webhook] Using tier from subscription metadata: ${metadataTier} → ${config.tier}`);
    return config;
  }

  console.warn(`[webhook] Could not resolve tier from subscription ${subscription.id}`);
  return null;
}

/**
 * Activate a user's subscription — set tier, is_active, and stripe_customer_id.
 */
async function activateSubscription(
  userId: string,
  tierConfig: TierConfig,
  stripeCustomerId: string
): Promise<void> {
  console.log(`[webhook] Activating subscription for user ${userId} → tier: ${tierConfig.tier}, access_level: ${tierConfig.access_level}, customer: ${stripeCustomerId}`);

  const { error } = await supabase
    .from("users")
    .update({
      subscription_tier: tierConfig.tier,
      access_level: tierConfig.access_level,
      is_active: true,
      stripe_customer_id: stripeCustomerId,
      is_premium: true,
    })
    .eq("id", userId);

  if (error) {
    console.error(`[webhook] Failed to activate subscription for ${userId}: ${error.message}`);
    throw new Error(`Database update failed: ${error.message}`);
  }

  console.log(`[webhook] Successfully activated user ${userId} to tier "${tierConfig.tier}" (access_level ${tierConfig.access_level})`);
}

/**
 * Deactivate a user's subscription — revert to free tier and mark inactive.
 */
async function deactivateSubscription(userId: string): Promise<void> {
  console.log(`[webhook] Deactivating subscription for user ${userId} → reverting to free tier, access_level 0`);

  const { error } = await supabase
    .from("users")
    .update({
      subscription_tier: "free",
      access_level: 0,
      is_active: false,
      is_premium: false,
    })
    .eq("id", userId);

  if (error) {
    console.error(`[webhook] Failed to deactivate subscription for ${userId}: ${error.message}`);
    throw new Error(`Database update failed: ${error.message}`);
  }

  console.log(`[webhook] Successfully reverted user ${userId} to free tier`);
}

// ---------------------------------------------------------------------------
// Event Handlers
// ---------------------------------------------------------------------------

/**
 * Handle checkout.session.completed — initial subscription purchase.
 */
async function handleCheckoutCompleted(
  stripe: Stripe,
  session: Stripe.Checkout.Session
): Promise<void> {
  console.log(`[webhook] Processing checkout.session.completed: ${session.id}`);
  console.log(`[webhook]   mode: ${session.mode}, customer: ${session.customer}`);

  if (session.mode !== "subscription") {
    console.log(`[webhook] Skipping non-subscription checkout (mode: ${session.mode})`);
    return;
  }

  const customerId = typeof session.customer === "string" ? session.customer : session.customer?.id || "";
  const clientRef = session.client_reference_id || session.metadata?.supabase_uid || undefined;

  const user = await findUserByStripeCustomer(stripe, customerId, clientRef);
  if (!user) {
    console.error(`[webhook] No user found for checkout session ${session.id} (customer: ${customerId})`);
    return;
  }

  // Resolve tier config from metadata (set during checkout) or from the subscription
  let tierConfig: TierConfig | null = null;

  const metaTier = session.metadata?.tier;
  if (metaTier && METADATA_TIER_MAP[metaTier]) {
    tierConfig = METADATA_TIER_MAP[metaTier];
  } else if (session.subscription) {
    const subId = typeof session.subscription === "string" ? session.subscription : session.subscription.id;
    const subscription = await stripe.subscriptions.retrieve(subId, {
      expand: ["items.data.price.product"],
    });
    tierConfig = await resolveTierFromSubscription(stripe, subscription);
  }

  if (!tierConfig) {
    console.error(`[webhook] Could not determine tier for checkout ${session.id}`);
    return;
  }

  await activateSubscription(user.id, tierConfig, customerId);
}

/**
 * Handle invoice.payment_succeeded — recurring renewal payment.
 */
async function handleInvoicePaid(
  stripe: Stripe,
  invoice: Stripe.Invoice
): Promise<void> {
  console.log(`[webhook] Processing invoice.payment_succeeded: ${invoice.id}`);

  // Only process subscription invoices (skip one-time payments)
  if (!invoice.subscription) {
    console.log(`[webhook] Skipping non-subscription invoice ${invoice.id}`);
    return;
  }

  const customerId = typeof invoice.customer === "string" ? invoice.customer : invoice.customer?.id || "";
  const subId = typeof invoice.subscription === "string" ? invoice.subscription : invoice.subscription.id;

  const user = await findUserByStripeCustomer(stripe, customerId);
  if (!user) {
    console.error(`[webhook] No user found for invoice ${invoice.id} (customer: ${customerId})`);
    return;
  }

  // Ensure the subscription is still active and re-confirm the tier
  const subscription = await stripe.subscriptions.retrieve(subId, {
    expand: ["items.data.price.product"],
  });

  if (subscription.status !== "active") {
    console.warn(`[webhook] Subscription ${subId} is not active (status: ${subscription.status}), skipping`);
    return;
  }

  const tierConfig = await resolveTierFromSubscription(stripe, subscription);
  if (!tierConfig) {
    console.error(`[webhook] Could not resolve tier for invoice ${invoice.id}`);
    return;
  }

  await activateSubscription(user.id, tierConfig, customerId);
}

/**
 * Handle customer.subscription.deleted — user cancelled or subscription expires.
 */
async function handleSubscriptionDeleted(
  stripe: Stripe,
  subscription: Stripe.Subscription
): Promise<void> {
  console.log(`[webhook] Processing customer.subscription.deleted: ${subscription.id}`);

  const customerId = typeof subscription.customer === "string" ? subscription.customer : subscription.customer?.id || "";

  const user = await findUserByStripeCustomer(stripe, customerId);
  if (!user) {
    console.error(`[webhook] No user found for deleted subscription ${subscription.id} (customer: ${customerId})`);
    return;
  }

  await deactivateSubscription(user.id);
}

/**
 * Handle invoice.payment_failed — payment issue, revert to free.
 */
async function handlePaymentFailed(
  stripe: Stripe,
  invoice: Stripe.Invoice
): Promise<void> {
  console.log(`[webhook] Processing invoice.payment_failed: ${invoice.id}`);

  if (!invoice.subscription) {
    console.log(`[webhook] Skipping non-subscription failed invoice ${invoice.id}`);
    return;
  }

  const customerId = typeof invoice.customer === "string" ? invoice.customer : invoice.customer?.id || "";

  const user = await findUserByStripeCustomer(stripe, customerId);
  if (!user) {
    console.error(`[webhook] No user found for failed invoice ${invoice.id} (customer: ${customerId})`);
    return;
  }

  await deactivateSubscription(user.id);
}

// ---------------------------------------------------------------------------
// Main Handler
// ---------------------------------------------------------------------------

Deno.serve(async (req: Request) => {
  // Stripe sends webhooks as POST; reject anything else
  if (req.method !== "POST") {
    return new Response("Method Not Allowed", { status: 405 });
  }

  if (!STRIPE_SECRET_KEY || !STRIPE_WEBHOOK_SECRET) {
    console.error("[webhook] Missing STRIPE_SECRET_KEY or STRIPE_WEBHOOK_SECRET");
    return new Response("Server not configured", { status: 503 });
  }

  const stripe = new Stripe(STRIPE_SECRET_KEY, {
    apiVersion: "2024-06-20",
    httpClient: Stripe.createFetchHttpClient(),
  });

  // Read the raw body — Stripe requires the unmodified payload for signature verification
  const rawBody = await req.text();
  const signature = req.headers.get("stripe-signature");

  if (!signature) {
    console.error("[webhook] Missing stripe-signature header");
    return new Response("Missing signature", { status: 400 });
  }

  // Verify the webhook signature to prevent spoofing
  let event: Stripe.Event;
  try {
    event = await stripe.webhooks.constructEventAsync(
      rawBody,
      signature,
      STRIPE_WEBHOOK_SECRET
    );
    console.log(`[webhook] Signature verified — event: ${event.type} (id: ${event.id})`);
  } catch (err) {
    console.error(`[webhook] Signature verification failed: ${err}`);
    return new Response(`Signature verification failed: ${err}`, { status: 400 });
  }

  // Route the verified event to the appropriate handler
  try {
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;
        await handleCheckoutCompleted(stripe, session);
        break;
      }

      case "invoice.payment_succeeded": {
        const invoice = event.data.object as Stripe.Invoice;
        await handleInvoicePaid(stripe, invoice);
        break;
      }

      case "customer.subscription.deleted": {
        const subscription = event.data.object as Stripe.Subscription;
        await handleSubscriptionDeleted(stripe, subscription);
        break;
      }

      case "invoice.payment_failed": {
        const invoice = event.data.object as Stripe.Invoice;
        await handlePaymentFailed(stripe, invoice);
        break;
      }

      default:
        console.log(`[webhook] Unhandled event type: ${event.type} — ignoring`);
    }

    // Always return 200 to Stripe so it doesn't retry unhandled events
    return new Response(JSON.stringify({ received: true }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error(`[webhook] Error processing event ${event.type} (${event.id}): ${err}`);
    // Return 500 so Stripe retries the event
    return new Response(
      JSON.stringify({ error: "Webhook handler failed" }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }
});
