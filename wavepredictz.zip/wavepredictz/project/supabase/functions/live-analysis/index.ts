import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const FOOTBALL_DATA_API_KEY = Deno.env.get("FOOTBALL_DATA_API_KEY") || "";
const SUPABASE_URL = Deno.env.get("SUPABASE_URL") || "";
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
  auth: { persistSession: false },
});

// League code mapping
const LEAGUE_CODE_MAP: Record<string, string> = {
  "premier league": "PL",
  "english premier league": "PL",
  "epl": "PL",
  "la liga": "PD",
  "primera division": "PD",
  "laliga": "PD",
  "serie a": "SA",
  "italian serie a": "SA",
  "bundesliga": "BL1",
  "german bundesliga": "BL1",
  "ligue 1": "FL1",
  "french ligue 1": "FL1",
  "champions league": "CL",
  "ucl": "CL",
  "championship": "ELC",
  "english championship": "ELC",
};

const LEAGUE_DISPLAY: Record<string, string> = {
  PL: "Premier League",
  PD: "La Liga",
  SA: "Serie A",
  BL1: "Bundesliga",
  FL1: "Ligue 1",
  CL: "Champions League",
  ELC: "Championship",
};

// Team name aliases → team ID (reuse from fetch-matches, extended)
const TEAM_ID_MAP: Record<string, number> = {
  "arsenal": 57, "arsenal fc": 57,
  "aston villa": 58, "villa": 58,
  "chelsea": 61, "chelsea fc": 61,
  "everton": 62, "everton fc": 62,
  "fulham": 63, "fulham fc": 63,
  "liverpool": 64, "liverpool fc": 64,
  "manchester city": 65, "man city": 65, "city": 65, "manchester city fc": 65,
  "manchester united": 66, "man utd": 66, "man united": 66, "united": 66, "manchester united fc": 66,
  "newcastle": 67, "newcastle united": 67, "newcastle united fc": 67,
  "tottenham": 73, "tottenham hotspur": 73, "spurs": 73, "tottenham hotspur fc": 73,
  "wolverhampton": 76, "wolves": 76, "wolverhampton wanderers": 76,
  "leicester": 338, "leicester city": 338, "foxes": 338, "leicester city fc": 338,
  "southampton": 340, "saints": 340, "southampton fc": 340,
  "ipswich": 349, "ipswich town": 349, "ipswich town fc": 349,
  "nottingham forest": 351, "forest": 351, "nottm forest": 351, "nottingham forest fc": 351,
  "crystal palace": 354, "palace": 354, "crystal palace fc": 354,
  "brighton": 397, "brighton hove albion": 397, "brighton & hove albion fc": 397,
  "brentford": 402, "brentford fc": 402,
  "west ham": 563, "west ham united": 563, "ham": 563, "west ham united fc": 563,
  "bournemouth": 1044, "afc bournemouth": 1044, "cherries": 1044,
  // La Liga
  "barcelona": 81, "fc barcelona": 81,
  "real madrid": 86, "real madrid cf": 86,
  "atletico madrid": 78, "atletico": 78, "atletico de madrid": 78,
  "sevilla": 558, "sevilla fc": 558,
  "valencia": 95, "valencia cf": 95,
  "villarreal": 94, "villarreal cf": 94,
  "real sociedad": 92, "real sociedad cf": 92,
  "betis": 543, "real betis": 543,
  "athletic bilbao": 77, "athletic club": 77,
  // Serie A
  "juventus": 99, "juventus fc": 99,
  "inter": 108, "inter milan": 108, "fc internazionale": 108,
  "ac milan": 98, "milan": 98,
  "napoli": 113, "ssc napoli": 113,
  "roma": 100, "as roma": 100,
  "lazio": 111, "ss lazio": 111,
  "fiorentina": 109, "acf fiorentina": 109,
  "atalanta": 112, "atalanta bc": 112,
  // Bundesliga
  "bayern munich": 157, "bayern": 157, "fc bayern munchen": 157,
  "borussia dortmund": 4, "dortmund": 4, "bvb": 4,
  "leverkusen": 3, "bayer leverkusen": 3,
  "rb leipzig": 721, "leipzig": 721,
  "frankfurt": 10, "eintracht frankfurt": 10,
  "wolfsburg": 11, "vfl wolfsburg": 11,
  "monchengladbach": 18, "borussia monchengladbach": 18,
  "stuttgart": 16, "vfb stuttgart": 16,
  // Ligue 1
  "psg": 524, "paris saint-germain": 524, "paris saint germain": 524, "paris sg": 524,
  "marseille": 516, "olympique marseille": 516, "om": 516,
  "lyon": 522, "olympique lyonnais": 522, "ol": 522,
  "monaco": 548, "as monaco": 548,
  "lille": 521, "losc lille": 521,
  "nice": 526, "ogc nice": 526,
  "rennes": 529, "stade rennais": 529,
};

const TEAM_DISPLAY: Record<number, string> = {
  57: "Arsenal", 58: "Aston Villa", 61: "Chelsea", 62: "Everton",
  63: "Fulham", 64: "Liverpool", 65: "Manchester City", 66: "Manchester United",
  67: "Newcastle United", 73: "Tottenham Hotspur", 76: "Wolverhampton",
  338: "Leicester City", 340: "Southampton", 349: "Ipswich Town",
  351: "Nottingham Forest", 354: "Crystal Palace", 397: "Brighton",
  402: "Brentford", 563: "West Ham United", 1044: "AFC Bournemouth",
  // La Liga
  81: "FC Barcelona", 86: "Real Madrid", 78: "Atlético Madrid",
  558: "Sevilla", 95: "Valencia", 94: "Villarreal",
  92: "Real Sociedad", 543: "Real Betis", 77: "Athletic Bilbao",
  // Serie A
  99: "Juventus", 108: "Inter", 98: "AC Milan", 113: "Napoli",
  100: "Roma", 111: "Lazio", 109: "Fiorentina", 112: "Atalanta",
  // Bundesliga
  157: "Bayern Munich", 4: "Borussia Dortmund", 3: "Bayer Leverkusen",
  721: "RB Leipzig", 10: "Eintracht Frankfurt", 11: "Wolfsburg",
  18: "Borussia Mönchengladbach", 16: "Stuttgart",
  // Ligue 1
  524: "PSG", 516: "Marseille", 522: "Lyon", 548: "Monaco",
  521: "Lille", 526: "Nice", 529: "Rennes",
};

const TEAM_LEAGUE: Record<number, string> = {
  57: "PL", 58: "PL", 61: "PL", 62: "PL", 63: "PL", 64: "PL",
  65: "PL", 66: "PL", 67: "PL", 73: "PL", 76: "PL", 338: "PL",
  340: "PL", 349: "PL", 351: "PL", 354: "PL", 397: "PL",
  402: "PL", 563: "PL", 1044: "PL",
  // La Liga
  81: "PD", 86: "PD", 78: "PD", 558: "PD", 95: "PD", 94: "PD",
  92: "PD", 543: "PD", 77: "PD",
  // Serie A
  99: "SA", 108: "SA", 98: "SA", 113: "SA", 100: "SA", 111: "SA",
  109: "SA", 112: "SA",
  // Bundesliga
  157: "BL1", 4: "BL1", 3: "BL1", 721: "BL1", 10: "BL1", 11: "BL1",
  18: "BL1", 16: "BL1",
  // Ligue 1
  524: "FL1", 516: "FL1", 522: "FL1", 548: "FL1", 521: "FL1", 526: "FL1", 529: "FL1",
};

const STATUSES: Record<string, string> = {
  "TIMED": "Scheduled",
  "IN_PLAY": "Live",
  "PAUSED": "Half-Time",
  "FINISHED": "Finished",
  "SUSPENDED": "Suspended",
  "POSTPONED": "Postponed",
  "CANCELLED": "Cancelled",
  "AWARDED": "Awarded",
};

interface MatchInfo {
  date: string;
  competition: string;
  homeTeam: string;
  awayTeam: string;
  homeId: number | null;
  awayId: number | null;
  status: string;
  statusDetail: string;
  matchday: number | null;
  stage: string | null;
  fullTimeHome: number | null;
  fullTimeAway: number | null;
  halfTimeHome: number | null;
  halfTimeAway: number | null;
  isHome: boolean;
}

interface StandingRow {
  position: number;
  team: string;
  teamId: number | null;
  played: number;
  won: number;
  drawn: number;
  lost: number;
  goalsFor: number;
  goalsAgainst: number;
  goalDifference: number;
  points: number;
  form: string | null;
}

interface ScorerInfo {
  name: string;
  team: string;
  goals: number;
  assists: number | null;
  penalties: number | null;
}

interface TeamInfo {
  name: string;
  shortName: string;
  tla: string;
  venue: string;
  founded: number | null;
  colors: string;
  website: string;
}

interface LiveAnalysisResponse {
  team: TeamInfo;
  leagueCode: string;
  leagueName: string;
  liveMatch: MatchInfo | null;
  recentMatches: MatchInfo[];
  upcomingMatch: MatchInfo | null;
  standing: StandingRow | null;
  topScorers: ScorerInfo[];
  note: string;
  error?: string;
  warning?: string;
}

async function getCachedAnalysis(cacheKey: string, allowStale = false): Promise<LiveAnalysisResponse | null> {
  let query = supabase
    .from("match_cache")
    .select("match_data, expires_at")
    .eq("team_name", cacheKey)
    .maybeSingle();
  if (!allowStale) {
    query = query.gte("expires_at", new Date().toISOString());
  }
  const { data, error } = await query;
  if (error || !data) return null;
  return data.match_data as LiveAnalysisResponse;
}

async function setCachedAnalysis(cacheKey: string, result: LiveAnalysisResponse): Promise<void> {
  await supabase.from("match_cache").delete().eq("team_name", cacheKey);
  const { error } = await supabase
    .from("match_cache")
    .insert({ team_name: cacheKey, match_data: result });
  if (error) console.error("Cache write error:", error.message);
}

async function apiFetch(url: string): Promise<any> {
  const res = await fetch(url, { headers: { "X-Auth-Token": FOOTBALL_DATA_API_KEY } });
  if (res.status === 429) throw new Error("API rate limit reached. Please wait a minute and try again.");
  if (!res.ok) throw new Error(`Football API error: ${res.status}`);
  return res.json();
}

function parseMatch(m: any, teamId: number | null): MatchInfo {
  const homeId = m.homeTeam?.id ?? null;
  const awayId = m.awayTeam?.id ?? null;
  const isHome = teamId !== null && homeId === teamId;
  const ft = m.score?.fullTime ?? {};
  const ht = m.score?.halfTime ?? {};

  return {
    date: m.utcDate ?? "",
    competition: m.competition?.name ?? "",
    homeTeam: m.homeTeam?.name ?? "TBD",
    awayTeam: m.awayTeam?.name ?? "TBD",
    homeId,
    awayId,
    status: m.status ?? "",
    statusDetail: STATUSES[m.status] ?? m.status ?? "",
    matchday: m.matchday ?? null,
    stage: m.stage ?? null,
    fullTimeHome: ft.home ?? null,
    fullTimeAway: ft.away ?? null,
    halfTimeHome: ht.home ?? null,
    halfTimeAway: ht.away ?? null,
    isHome,
  };
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const teamParam = url.searchParams.get("team") || "";
    const leagueParam = url.searchParams.get("league") || "";

    if (!teamParam) {
      return new Response(
        JSON.stringify({ error: "Team parameter required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!FOOTBALL_DATA_API_KEY) {
      return new Response(
        JSON.stringify({ error: "API key not configured on the server" }),
        { status: 503, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const normalizedInput = teamParam.toLowerCase().trim();
    const teamId = TEAM_ID_MAP[normalizedInput];

    if (!teamId) {
      return new Response(
        JSON.stringify({ error: `Team "${teamParam}" not recognized. Supported: Premier League, La Liga, Serie A, Bundesliga, and Ligue 1 teams.` }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Determine league code
    let leagueCode = TEAM_LEAGUE[teamId] || "PL";
    if (leagueParam) {
      const normalizedLeague = leagueParam.toLowerCase().trim();
      const mapped = LEAGUE_CODE_MAP[normalizedLeague];
      if (mapped) leagueCode = mapped;
    }
    const leagueName = LEAGUE_DISPLAY[leagueCode] || leagueCode;

    const cacheKey = `live-${teamId}-${leagueCode}`;

    // Try fresh cache first
    const cached = await getCachedAnalysis(cacheKey);
    if (cached) {
      return new Response(
        JSON.stringify({ ...cached, warning: undefined }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Determine current season: European seasons start around July.
    const nowDate = new Date();
    const currentYear = nowDate.getUTCMonth() >= 6 ? nowDate.getUTCFullYear() : nowDate.getUTCFullYear() - 1;
    const seasons = [currentYear, currentYear - 1, currentYear - 2];

    // 1. Fetch team detail once (not season-dependent)
    let teamData: any;
    try {
      teamData = await apiFetch(`https://api.football-data.org/v4/teams/${teamId}`);
    } catch (err: any) {
      throw new Error(`Could not fetch team info: ${err.message}`);
    }

    // 2. Fetch matches — try current season, fall back to previous
    let matchesData: any = null;
    let apiError = "";
    let matchedSeason = currentYear;

    for (const season of seasons) {
      try {
        matchesData = await apiFetch(
          `https://api.football-data.org/v4/teams/${teamId}/matches?season=${season}&limit=50`
        );
        const finishedMatches = (matchesData.matches || []).filter((m: any) => m.status === "FINISHED");
        if (finishedMatches.length > 0) {
          matchedSeason = season;
          break;
        }
      } catch (err: any) {
        apiError = err.message;
        matchesData = null;
      }
    }

    if (!matchesData || !matchesData.matches || matchesData.matches.length === 0) {
      throw new Error(apiError || "No match data available for this team in the current or previous season");
    }

    // 3. Fetch optional data (standings, scorers) — only if enough matches, failures don't break
    const finishedCount = (matchesData.matches || []).filter((m: any) => m.status === "FINISHED").length;
    let standingsData: any = null;
    let scorersData: any = null;

    if (finishedCount >= 3) {
      const [standingsResult, scorersResult] = await Promise.allSettled([
        apiFetch(`https://api.football-data.org/v4/competitions/${leagueCode}/standings?season=${matchedSeason}`),
        apiFetch(`https://api.football-data.org/v4/competitions/${leagueCode}/scorers?season=${matchedSeason}&limit=10`),
      ]);
      standingsData = standingsResult.status === "fulfilled" ? standingsResult.value : null;
      scorersData = scorersResult.status === "fulfilled" ? scorersResult.value : null;
    }

    const teamInfo: TeamInfo = {
      name: teamData.name || TEAM_DISPLAY[teamId] || teamParam,
      shortName: teamData.shortName || teamData.name || "",
      tla: teamData.tla || "",
      venue: teamData.venue || "",
      founded: teamData.founded ?? null,
      colors: teamData.clubColors || "",
      website: teamData.website || "",
    };

    // Process all team matches
    const allMatches: MatchInfo[] = (matchesData.matches || [])
      .map((m: any) => parseMatch(m, teamId))
      .sort((a: MatchInfo, b: MatchInfo) => new Date(b.date).getTime() - new Date(a.date).getTime());

    const now = Date.now();

    // Find live/in-progress match for this team
    const liveMatch = allMatches.find(
      m => m.status === "IN_PLAY" || m.status === "PAUSED"
    ) || null;

    // Recent finished matches (most recent first, up to 10)
    const recentMatches = allMatches
      .filter(m => m.status === "FINISHED")
      .slice(0, 10);

    // Upcoming scheduled match (nearest future)
    const upcomingMatch = allMatches
      .filter(m => (m.status === "TIMED" || m.status === "SCHEDULED") && new Date(m.date).getTime() > now)
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())[0] || null;

    // Find this team in standings
    let standing: StandingRow | null = null;
    const totalStandings = standingsData?.standings?.find((s: any) => s.type === "TOTAL");
    if (totalStandings?.table) {
      const row = totalStandings.table.find((r: any) => r.team?.id === teamId);
      if (row) {
        standing = {
          position: row.position ?? 0,
          team: row.team?.name ?? teamInfo.name,
          teamId: row.team?.id ?? null,
          played: row.playedGames ?? 0,
          won: row.won ?? 0,
          drawn: row.draw ?? 0,
          lost: row.lost ?? 0,
          goalsFor: row.goalsFor ?? 0,
          goalsAgainst: row.goalsAgainst ?? 0,
          goalDifference: row.goalDifference ?? 0,
          points: row.points ?? 0,
          form: row.form ?? null,
        };
      }
    }

    // Top scorers
    const topScorers: ScorerInfo[] = [];
    if (scorersData?.scorers) {
      for (const s of scorersData.scorers.slice(0, 10)) {
        topScorers.push({
          name: s.player?.name ?? "Unknown",
          team: s.team?.name ?? "",
          goals: s.goals ?? 0,
          assists: s.assists ?? null,
          penalties: s.penalties ?? null,
        });
      }
    }

    const note = liveMatch
      ? `Live match in progress: ${liveMatch.homeTeam} vs ${liveMatch.awayTeam}.`
      : recentMatches.length > 0
      ? `No live match. Showing data from the most recent fixture: ${recentMatches[0].homeTeam} vs ${recentMatches[0].awayTeam} on ${new Date(recentMatches[0].date).toLocaleDateString()}.`
      : "No recent matches found for this team in the selected league.";

    const response: LiveAnalysisResponse = {
      team: teamInfo,
      leagueCode,
      leagueName,
      liveMatch,
      recentMatches,
      upcomingMatch,
      standing,
      topScorers,
      note,
    };

    await setCachedAnalysis(cacheKey, response);

    return new Response(
      JSON.stringify(response),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Live analysis edge function error:", error);

    // Try serving stale cache as a last resort
    const url = new URL(req.url);
    const teamParam = url.searchParams.get("team") || "";
    const leagueParam = url.searchParams.get("league") || "";
    const normalizedInput = teamParam.toLowerCase().trim();
    const teamId = TEAM_ID_MAP[normalizedInput];
    let leagueCode = TEAM_LEAGUE[teamId] || "PL";
    const mappedLeague = LEAGUE_CODE_MAP[leagueParam.toLowerCase().trim()];
    if (mappedLeague) leagueCode = mappedLeague;

    if (teamId) {
      const stale = await getCachedAnalysis(`live-${teamId}-${leagueCode}`, true);
      if (stale) {
        return new Response(
          JSON.stringify({ ...stale, warning: error.message }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    }

    return new Response(
      JSON.stringify({ error: error.message || "Failed to fetch live analysis data" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
