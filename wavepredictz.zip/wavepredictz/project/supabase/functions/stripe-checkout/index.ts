import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import Stripe from "npm:stripe@14.21.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const STRIPE_SECRET_KEY = Deno.env.get("STRIPE_SECRET_KEY") || "";
const SUPABASE_URL = Deno.env.get("SUPABASE_URL") || "";
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";

import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
  auth: { persistSession: false },
});

// Price IDs per tier and billing cycle — used as fallback when the frontend
// doesn't pass an explicit priceId. The frontend now sends the real priceId
// from src/config/stripePrices.ts, so this map is a safety net.
const PRICE_IDS: Record<string, Record<string, string>> = {
  casual: {
    monthly: "price_1UBxOqGgWeF9kZ8tomZ8KNEw",
    annual: "price_YOUR_CASUAL_ANNUAL_ID_HERE",
  },
  professional: {
    monthly: "price_1UBxMqGgWeF9kZ8tB5hXlYqZ",
    annual: "price_YOUR_PRO_ANNUAL_ID_HERE",
  },
  b2b: {
    monthly: "price_1UBxQ4GgWeF9kZ8teg8wGei",
    annual: "price_YOUR_B2B_ANNUAL_ID_HERE",
  },
  elite: {
    monthly: "price_1UBxRMGgWeF9kZ8tR8y5OY9X",
    annual: "price_YOUR_ELITE_ANNUAL_ID_HERE",
  },
};

const TIER_PRODUCT_MAP: Record<string, string> = {
  casual: "Wave Predictz Casual",
  pro: "Wave Predictz Professional",
  b2b: "Wave Predictz B2B API",
  elite: "Wave Predictz Elite",
};

const TIER_PRICES: Record<string, { monthly: number; annual: number }> = {
  casual: { monthly: 2500, annual: 24000 },
  pro: { monthly: 9900, annual: 94800 },
  b2b: { monthly: 7900, annual: 75600 },
  elite: { monthly: 59900, annual: 574800 },
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  if (!STRIPE_SECRET_KEY) {
    return new Response(
      JSON.stringify({ error: "Stripe is not configured on the server" }),
      { status: 503, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  const stripe = new Stripe(STRIPE_SECRET_KEY, {
    apiVersion: "2024-06-20",
    httpClient: Stripe.createFetchHttpClient(),
  });

  try {
    const { tier, cycle, priceId } = await req.json();

    if (!tier || !cycle) {
      return new Response(
        JSON.stringify({ error: "Missing tier or cycle" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Get the user from the JWT
    const authHeader = req.headers.get("Authorization") || "";
    const token = authHeader.replace("Bearer ", "");
    const { data: { user } } = await supabase.auth.getUser(token);

    if (!user) {
      return new Response(
        JSON.stringify({ error: "Authentication required" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Find or create Stripe customer
    const { data: existingCustomer } = await supabase
      .from("stripe_customers")
      .select("customer_id")
      .eq("user_id", user.id)
      .is("deleted_at", null)
      .maybeSingle();

    let customerId = existingCustomer?.customer_id;

    if (!customerId) {
      const customer = await stripe.customers.create({
        email: user.email || undefined,
        metadata: { supabase_uid: user.id },
      });
      customerId = customer.id;

      await supabase.from("stripe_customers").insert({
        user_id: user.id,
        customer_id: customerId,
      });
    }

    // Resolve the Stripe Price ID — prefer the explicit priceId from the frontend
    let resolvedPriceId = priceId || PRICE_IDS[tier]?.[cycle];

    // Reject placeholder price IDs that haven't been configured yet
    if (!resolvedPriceId || resolvedPriceId.includes("YOUR_")) {
      return new Response(
        JSON.stringify({
          error: `Stripe Price ID for tier "${tier}" cycle "${cycle}" is not configured. Add the real Price ID in the stripePrices config or Stripe Dashboard.`,
        }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const origin = req.headers.get("origin") || "http://localhost:5173";

    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      mode: "subscription",
      line_items: [{ price: resolvedPriceId, quantity: 1 }],
      client_reference_id: user.id,
      success_url: `${origin}/?checkout=success&tier=${tier}`,
      cancel_url: `${origin}/?checkout=cancelled`,
      metadata: {
        supabase_uid: user.id,
        tier,
        cycle,
      },
    });

    return new Response(
      JSON.stringify({ url: session.url, sessionId: session.id }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Stripe checkout error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Failed to create checkout session" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
