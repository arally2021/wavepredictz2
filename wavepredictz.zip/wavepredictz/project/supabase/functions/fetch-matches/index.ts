import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const FOOTBALL_DATA_API_KEY = Deno.env.get("FOOTBALL_DATA_API_KEY") || "";
const SUPABASE_URL = Deno.env.get("SUPABASE_URL") || "";
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";

const CACHE_TTL_HOURS = 6;

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
  auth: { persistSession: false },
});

// Maps user input (lowercase aliases) to football-data.org team IDs
const TEAM_ID_MAP: Record<string, number> = {
  "arsenal": 57,
  "arsenal fc": 57,
  "aston villa": 58,
  "aston villa fc": 58,
  "villa": 58,
  "chelsea": 61,
  "chelsea fc": 61,
  "everton": 62,
  "everton fc": 62,
  "fulham": 63,
  "fulham fc": 63,
  "liverpool": 64,
  "liverpool fc": 64,
  "manchester city": 65,
  "manchester city fc": 65,
  "man city": 65,
  "city": 65,
  "manchester united": 66,
  "manchester united fc": 66,
  "man utd": 66,
  "man united": 66,
  "united": 66,
  "newcastle": 67,
  "newcastle united": 67,
  "newcastle united fc": 67,
  "tottenham": 73,
  "tottenham hotspur": 73,
  "tottenham hotspur fc": 73,
  "spurs": 73,
  "wolverhampton": 76,
  "wolverhampton wanderers": 76,
  "wolverhampton wanderers fc": 76,
  "wolves": 76,
  "leicester": 338,
  "leicester city": 338,
  "leicester city fc": 338,
  "foxes": 338,
  "southampton": 340,
  "southampton fc": 340,
  "saints": 340,
  "ipswich": 349,
  "ipswich town": 349,
  "ipswich town fc": 349,
  "nottingham forest": 351,
  "nottingham forest fc": 351,
  "forest": 351,
  "nottm forest": 351,
  "crystal palace": 354,
  "crystal palace fc": 354,
  "palace": 354,
  "brighton": 397,
  "brighton hove albion": 397,
  "brighton & hove albion fc": 397,
  "brentford": 402,
  "brentford fc": 402,
  "west ham": 563,
  "west ham united": 563,
  "west ham united fc": 563,
  "ham": 563,
  "bournemouth": 1044,
  "afc bournemouth": 1044,
  "cherries": 1044,
  "the cherries": 1044,
  // La Liga
  "barcelona": 81, "fc barcelona": 81,
  "real madrid": 86, "real madrid cf": 86,
  "atletico madrid": 78, "atletico": 78, "atletico de madrid": 78,
  "sevilla": 558, "sevilla fc": 558,
  "valencia": 95, "valencia cf": 95,
  "villarreal": 94, "villarreal cf": 94,
  "real sociedad": 92, "real sociedad cf": 92,
  "betis": 543, "real betis": 543, "real betis balompie": 543,
  "athletic bilbao": 77, "athletic club": 77,
  // Serie A
  "juventus": 99, "juventus fc": 99,
  "inter": 108, "inter milan": 108, "fc internazionale": 108,
  "ac milan": 98, "milan": 98,
  "napoli": 113, "ssc napoli": 113,
  "roma": 100, "as roma": 100,
  "lazio": 111, "ss lazio": 111,
  "fiorentina": 109, "acf fiorentina": 109,
  "atalanta": 112, "atalanta bc": 112,
  // Bundesliga
  "bayern munich": 157, "bayern": 157, "fc bayern munchen": 157,
  "borussia dortmund": 4, "dortmund": 4, "bvb": 4,
  "leverkusen": 3, "bayer leverkusen": 3,
  "rb leipzig": 721, "leipzig": 721,
  "frankfurt": 10, "eintracht frankfurt": 10,
  "wolfsburg": 11, "vfl wolfsburg": 11,
  "monchengladbach": 18, "borussia monchengladbach": 18,
  "stuttgart": 16, "vfb stuttgart": 16,
  // Ligue 1
  "psg": 524, "paris saint-germain": 524, "paris saint germain": 524, "paris sg": 524,
  "marseille": 516, "olympique marseille": 516, "om": 516,
  "lyon": 522, "olympique lyonnais": 522, "ol": 522,
  "monaco": 548, "as monaco": 548,
  "lille": 521, "losc lille": 521,
  "nice": 526, "ogc nice": 526,
  "rennes": 529, "stade rennais": 529,
};

const TEAM_DISPLAY_NAME: Record<number, string> = {
  57: "Arsenal",
  58: "Aston Villa",
  61: "Chelsea",
  62: "Everton",
  63: "Fulham",
  64: "Liverpool",
  65: "Manchester City",
  66: "Manchester United",
  67: "Newcastle United",
  73: "Tottenham Hotspur",
  76: "Wolverhampton",
  338: "Leicester City",
  340: "Southampton",
  349: "Ipswich Town",
  351: "Nottingham Forest",
  354: "Crystal Palace",
  397: "Brighton",
  402: "Brentford",
  563: "West Ham United",
  1044: "AFC Bournemouth",
  // La Liga
  81: "FC Barcelona", 86: "Real Madrid", 78: "Atlético Madrid",
  558: "Sevilla", 95: "Valencia", 94: "Villarreal",
  92: "Real Sociedad", 543: "Real Betis", 77: "Athletic Bilbao",
  // Serie A
  99: "Juventus", 108: "Inter", 98: "AC Milan", 113: "Napoli",
  100: "Roma", 111: "Lazio", 109: "Fiorentina", 112: "Atalanta",
  // Bundesliga
  157: "Bayern Munich", 4: "Borussia Dortmund", 3: "Bayer Leverkusen",
  721: "RB Leipzig", 10: "Eintracht Frankfurt", 11: "Wolfsburg",
  18: "Borussia Mönchengladbach", 16: "Stuttgart",
  // Ligue 1
  524: "PSG", 516: "Marseille", 522: "Lyon", 548: "Monaco",
  521: "Lille", 526: "Nice", 529: "Rennes",
};

interface ProcessedMatch {
  date: string;
  opponent: string;
  gf: number;
  ga: number;
  venue: "home" | "away";
  result: "W" | "D" | "L";
}

interface TeamResult {
  team: string;
  matchesAnalyzed: number;
  avgGoalsFor: number;
  avgGoalsAgainst: number;
  matches: ProcessedMatch[];
}

async function getCachedResult(teamName: string, allowStale = false): Promise<TeamResult | null> {
  let query = supabase
    .from("match_cache")
    .select("match_data, expires_at")
    .eq("team_name", teamName)
    .maybeSingle();

  if (!allowStale) {
    query = query.gte("expires_at", new Date().toISOString());
  }

  const { data, error } = await query;
  if (error || !data) return null;
  return data.match_data as TeamResult;
}

async function setCachedResult(teamName: string, result: TeamResult): Promise<void> {
  // Delete any existing cache entry, then insert fresh.
  // expires_at uses the column default (now() + 24h) so we don't set it manually.
  await supabase
    .from("match_cache")
    .delete()
    .eq("team_name", teamName);

  const { error } = await supabase
    .from("match_cache")
    .insert({ team_name: teamName, match_data: result });

  if (error) {
    console.error("Cache write error:", error.message);
  }
}

function currentSeasonYear(): number {
  const now = new Date();
  // European seasons start in July/August. If we're past July, the
  // current season starts this year; otherwise it started last year.
  return now.getUTCMonth() >= 6 ? now.getUTCFullYear() : now.getUTCFullYear() - 1;
}

async function fetchFromApi(teamId: number, limit: number): Promise<TeamResult> {
  const seasons = [currentSeasonYear(), currentSeasonYear() - 1, currentSeasonYear() - 2];
  let processedMatches: ProcessedMatch[] = [];
  let lastError = "";

  for (const season of seasons) {
    const apiUrl = `https://api.football-data.org/v4/teams/${teamId}/matches?season=${season}&limit=${limit}`;
    const response = await fetch(apiUrl, {
      headers: { "X-Auth-Token": FOOTBALL_DATA_API_KEY },
    });

    if (response.status === 429) {
      throw new Error("API rate limit exceeded. Please try again in a minute.");
    }

    if (!response.ok) {
      lastError = `API error: ${response.status}`;
      continue;
    }

    const data = await response.json();
    const rawMatches: any[] = data.matches || [];

    const seasonProcessed: ProcessedMatch[] = rawMatches
      .map((m: any) => {
        const isHome = m.homeTeam?.id === teamId;
        const goalsFor = isHome ? m.score?.fullTime?.home : m.score?.fullTime?.away;
        const goalsAgainst = isHome ? m.score?.fullTime?.away : m.score?.fullTime?.home;

        if (goalsFor === null || goalsFor === undefined || goalsAgainst === null || goalsAgainst === undefined) {
          return null;
        }

        return {
          date: m.utcDate ?? "",
          opponent: isHome ? m.awayTeam?.name : m.homeTeam?.name,
          gf: goalsFor,
          ga: goalsAgainst,
          venue: (isHome ? "home" : "away") as "home" | "away",
          result: (goalsFor > goalsAgainst
            ? "W"
            : goalsFor === goalsAgainst
            ? "D"
            : "L") as "W" | "D" | "L",
        };
      })
      .filter((m: ProcessedMatch | null): m is ProcessedMatch => m !== null);

    processedMatches = processedMatches.concat(seasonProcessed);

    if (processedMatches.length >= limit) break;
  }

  if (processedMatches.length === 0) {
    throw new Error(lastError || "No finished matches found for this team in recent seasons");
  }

  // Sort by date descending (most recent first) and trim to limit
  processedMatches.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  processedMatches = processedMatches.slice(0, limit);

  const avgGoalsFor =
    processedMatches.reduce((s, m) => s + m.gf, 0) / processedMatches.length;
  const avgGoalsAgainst =
    processedMatches.reduce((s, m) => s + m.ga, 0) / processedMatches.length;

  return {
    team: TEAM_DISPLAY_NAME[teamId] || `Team ${teamId}`,
    matchesAnalyzed: processedMatches.length,
    avgGoalsFor: parseFloat(avgGoalsFor.toFixed(2)),
    avgGoalsAgainst: parseFloat(avgGoalsAgainst.toFixed(2)),
    matches: processedMatches,
  };
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const teamParam = url.searchParams.get("team");
    const limit = parseInt(url.searchParams.get("limit") || "50");
    const force = url.searchParams.get("force") === "true";

    if (!teamParam) {
      return new Response(
        JSON.stringify({ error: "Team parameter required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!FOOTBALL_DATA_API_KEY) {
      return new Response(
        JSON.stringify({ error: "API key not configured on the server" }),
        { status: 503, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const normalizedInput = teamParam.toLowerCase().trim();
    const teamId = TEAM_ID_MAP[normalizedInput];

    if (!teamId) {
      return new Response(
        JSON.stringify({ error: `Team "${teamParam}" not recognized. Supported: Premier League, La Liga, Serie A, Bundesliga, and Ligue 1 teams.` }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const displayName = TEAM_DISPLAY_NAME[teamId] || teamParam;

    if (!force) {
      const cached = await getCachedResult(displayName);
      if (cached) {
        return new Response(
          JSON.stringify({ ...cached, source: "cache" }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    }

    try {
      const result = await fetchFromApi(teamId, limit);
      await setCachedResult(displayName, result);

      return new Response(
        JSON.stringify({ ...result, source: "api" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    } catch (apiError) {
      // API failed — try serving stale cache as a fallback
      const stale = await getCachedResult(displayName, true);
      if (stale) {
        return new Response(
          JSON.stringify({ ...stale, source: "stale-cache", warning: apiError.message }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      throw apiError;
    }
  } catch (error) {
    console.error("Edge function error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Failed to fetch match data" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
