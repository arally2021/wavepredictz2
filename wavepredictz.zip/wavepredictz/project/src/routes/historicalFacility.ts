import { Router } from 'express';
import { getHistoricalFacility } from '../analysis/historicalFacility.controller';

const router = Router();

router.get('/historical-facility', getHistoricalFacility);

export default router;
