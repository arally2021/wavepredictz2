import { Router } from 'express';
import { getScoringProfile } from '../controllers/scoringController';

const router = Router();

// Get scoring profile by team
router.get('/:teamId', getScoringProfile);

export default router;
