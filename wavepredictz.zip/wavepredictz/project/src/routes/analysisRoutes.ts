import { Router } from 'express';
import { handleHistoricalAnalysis, handleGenerateAnalysis } from '../controllers/analysisController';


const router = Router();

router.post('/analysis', analyzeTeam);

// Return historical facility + analyses
router.get('/historical', handleHistoricalAnalysis);

// Generate a new analysis for a team
router.post('/generate', handleGenerateAnalysis);

export default router;
