import { Router } from 'express';
import { handlePatternAnalysis } from '../controllers/patternController';

const router = Router();

router.post('/analyze', handlePatternAnalysis);

router.post('/analyze', handlePatternAnalysis);
export default router;
