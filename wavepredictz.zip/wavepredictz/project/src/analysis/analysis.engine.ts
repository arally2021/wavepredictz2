// analysis.engine.ts
import type { AnalysisInput, WaveAnalysis } from '../types/wavepredictz';
import { computeWeightedStats } from '../lib/timeDecay';

const BANNED_KEYWORDS = ['bet', 'wager', 'odds', 'stake', 'fixed match', 'sure bet', 'gambling', 'bookmaker'];

function sanitizeAnalysisInput(input: AnalysisInput): AnalysisInput {
  const sanitized = { ...input };
  if (sanitized.notes && BANNED_KEYWORDS.some(kw => sanitized.notes!.toLowerCase().includes(kw))) {
    sanitized.notes = '[Content filtered for safety]';
  }
  if (sanitized.team && BANNED_KEYWORDS.some(kw => sanitized.team.toLowerCase().includes(kw))) {
    throw new Error('Request contains prohibited gambling-related content');
  }
  return sanitized;
}

export function generateWaveAnalysis(input: AnalysisInput): WaveAnalysis {
  const sanitized = sanitizeAnalysisInput(input);
  const matches = sanitized.recent_matches || [];
  const hasData = matches.length > 0;

  const stats = computeWeightedStats(matches);

  const avgGF = stats.avgGoalsFor;
  const avgGA = stats.avgGoalsAgainst;
  const avgXg = stats.avgXg;
  const avgXga = stats.avgXga;
  const stability = stats.stabilityIndex;
  const volatility = stats.volatilityIndex;
  const dualScoreRate = stats.dualScoreRate;
  const formTrend = stats.formTrend;
  const recentPct = stats.totalWeight > 0 ? (stats.recentWeight / stats.totalWeight) * 100 : 0;

  const analysis: WaveAnalysis = {
    team_evaluated: sanitized.team,

    scoring_tendency_profile: {
      first_half_behavior: !hasData
        ? 'No data available - fetch match history to populate'
        : avgGF < 0.8
        ? 'Low early-phase attacking engagement — conservative buildup and compact defensive blocks'
        : 'Active early-phase progression — proactive attacking phases from the start',

      burst_scoring_pattern: !hasData
        ? 'No data available'
        : stats.burstRate > 0.25
        ? 'Explosive scoring phases detected — consistent with transition-heavy counter-pressing style'
        : stats.burstRate > 0.1
        ? 'Moderate burst-scoring phases — periodic multi-goal surges'
        : 'Controlled scoring distribution — gradual buildup reliance',

      dual_offense_activation: !hasData
        ? 'No data available'
        : dualScoreRate > 0.6
        ? 'High mutual attacking exposure — both teams regularly create scoring phases'
        : dualScoreRate > 0.3
        ? 'Balanced offensive engagement'
        : 'Defensive match structures — one-sided or low-scoring patterns',

      low_output_signature: !hasData
        ? 'No data loaded - fetch match history to generate tactical profile'
        : avgGF >= 2 && avgGA < 1.2
        ? 'Elite Output Profile — high-volume attacking phases with disciplined defensive structure, sustained control in the final third'
        : avgGF >= 2 && avgGA >= 1.5
        ? 'High-Output Transition Profile — aggressive attack paired with defensive leak, producing open volatile matches'
        : avgGF >= 1.5 && avgGA < 1
        ? 'Strong Output Profile — consistent goal-scoring with organized defensive structure'
        : avgGF >= 1.5
        ? 'Balanced Output Profile — moderate attacking output with reasonable defensive coverage'
        : avgGF >= 1
        ? 'Conservative Output Pattern — measured offensive approach with emphasis on defensive structure'
        : 'Limited Output Signature — restricted creative output, reliance on set pieces or counter-attacks',
    },

    consistency_matrix: {
      stability_index: stability,
      volatility_index: volatility,
      inner_strength_rating: formTrend,
      required_value_metric: Math.max(0.3, stability * 0.7 + formTrend * 0.3),
      instability_factors: !hasData
        ? ['No match data loaded']
        : volatility > 0.5
        ? ['High goal variance', 'Inconsistent performance levels', 'Form fluctuations']
        : ['Minor variance in output', 'Generally stable patterns'],
    },

    statistical_overview: {
      avg_goals_for: avgGF,
      avg_goals_against: avgGA,
      avg_xg: avgXg,
      avg_xga: avgXga,
      clean_sheet_rate_last10: stats.cleanSheetRateLast10,
      xg_trends: !hasData
        ? 'No xG data - fetch match history'
        : avgXg > 1.8
        ? `High xG generation (${avgXg.toFixed(2)} per match)`
        : avgXg > 1.2
        ? `Moderate xG (${avgXg.toFixed(2)} per match)`
        : `Low xG output (${avgXg.toFixed(2)} per match)`,
      momentum_notes: !hasData
        ? 'No data - fetch match history'
        : formTrend > 0.6
        ? 'Positive momentum (recent-weighted)'
        : formTrend > 0.4
        ? 'Neutral momentum (recent-weighted)'
        : 'Negative momentum (recent-weighted)',
    },

    historical_trends: hasData ? [
      `Time-decay weighted average: ${avgGF.toFixed(2)} goals scored per match`,
      `Time-decay weighted average: ${avgGA.toFixed(2)} goals conceded per match`,
      `Weighted xG: ${avgXg.toFixed(2)} | xGA: ${avgXga.toFixed(2)} per match`,
      `Clean sheet rate (last 10): ${(stats.cleanSheetRateLast10 * 100).toFixed(0)}%`,
      `Recency signal: ${recentPct.toFixed(0)}% of statistical weight from last 60 days across ${stats.matchCount} matches`,
      stability > 0.7 ? 'High consistency in current tactical era' : stability > 0.5 ? 'Moderate consistency' : 'Variable performance patterns',
      dualScoreRate > 0.5 ? 'Open matches with both-sided scoring' : 'Defensively structured matches',
    ] : [
      'No match data loaded - fetch match history to populate analysis',
      'Use the auto-fetch button or add matches manually to generate a tactical profile',
    ],

    safe_insight_summary: !hasData
      ? `${sanitized.team}: No match data was loaded. The analysis cannot generate a tactical profile without match history. Use the fetch button to load real data, or add matches manually.`
      : `${sanitized.team} demonstrates ${stability > 0.6 ? 'consistent' : 'variable'} performance patterns with ${avgGF > 1.5 ? 'strong' : avgGF > 1 ? 'moderate' : 'limited'} offensive output across ${stats.matchCount} matches. Weighted xG of ${avgXg.toFixed(2)} vs xGA of ${avgXga.toFixed(2)} per match, with a ${(stats.cleanSheetRateLast10 * 100).toFixed(0)}% clean sheet rate over the last 10. ${recentPct.toFixed(0)}% of the statistical signal comes from the last 60 days, preventing stale historical eras from distorting the active tactical profile. The team shows ${volatility > 0.5 ? 'variable' : 'predictable'} match outcomes.`,

    interactive_steps: [
      'Review the consistency matrix to understand current-era performance stability',
      'Examine scoring tendency profile for active tactical patterns',
      'Analyze historical trends for recency-weighted behavior',
      'Compare statistical overview with league averages',
      'Monitor recent form trends for momentum shifts',
    ],
  };

  return analysis;
}
