import { Request, Response } from 'express';
import { supabase } from '../lib/supabase';

export const getHistoricalFacility = async (req: Request, res: Response) => {
  const { team_id } = req.query;

  let analysesQuery = supabase
    .from('analyses')
    .select('*')
    .order('created_at', { ascending: false });

  if (team_id) {
    analysesQuery = analysesQuery.eq('team_id', team_id);
  }

  const { data: analyses, error: analysesError } = await analysesQuery;

  if (analysesError) {
    return res.status(500).json({ error: analysesError.message });
  }

  const { data: patterns, error: patternsError } = await supabase
    .from('semantic_patterns')
    .select('*')
    .order('usefulness_score', { ascending: false });

  if (patternsError) {
    return res.status(500).json({ error: patternsError.message });
  }

  const summary = analyses.length === 0
    ? 'No historical analyses available.'
    : `Stored ${analyses.length} analyses across historical evaluations.`;

  res.json({
    summary,
    analyses,
    patterns
  });
};
