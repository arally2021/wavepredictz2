// analysis.repository.ts
import { supabase } from '../lib/supabase';
import type {
  AnalysisInput,
  WaveAnalysis,
  HistoricalFacilityResponse
} from '../types/wavepredictz';
import { extractPatternsFromAnalysis } from '../memory/memory.engine';

export async function saveAnalysisRecord(
  input: AnalysisInput,
  output: WaveAnalysis,
  userId?: string
): Promise<string | null> {
  const { data, error } = await supabase
    .from('analyses')
    .insert({ user_id: userId || null, input, output })
    .select('id')
    .maybeSingle();

  if (error) {
    console.error('Analysis persistence error:', error);
    return null;
  }

  await extractPatternsFromAnalysis(output, input.team);
  return data?.id ?? null;
}

export async function fetchHistoricalFacility(
  team_id?: string
): Promise<HistoricalFacilityResponse> {
  let query = supabase
    .from('analyses')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(50);

  if (team_id) {
    query = query.or(
      `input->team.eq.${team_id},output->team_evaluated.eq.${team_id}`
    );
  }

  const { data } = await query;

  return {
    team_id,
    analyses: data || [],
    patterns: [],
    summary: `Retrieved ${(data || []).length} historical analyses${
      team_id ? ` for ${team_id}` : ''
    }.`
  };
}
