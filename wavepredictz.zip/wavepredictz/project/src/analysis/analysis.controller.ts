import { Request, Response } from 'express';
import { AnalysisInput, AnalysisResult } from '../types/analysis.types';

export const analyzeTeam = (req: Request, res: Response) => {
  const input = req.body as AnalysisInput;

  if (!input.team) {
    return res.status(400).json({ error: 'Team name is required' });
  }

  const matches = input.recent_matches || [];

  if (matches.length === 0) {
    const result: AnalysisResult = {
      team: input.team,
      league: input.league,
      matchesAnalyzed: 0,
      avgGoalsFor: 0,
      avgGoalsAgainst: 0,
      formScore: 0.5,
      confidence: 0.3,
      insight: 'No recent match data provided. Analysis is limited.'
    };

    return res.json(result);
  }

  const totalGF = matches.reduce((sum, m) => sum + m.gf, 0);
  const totalGA = matches.reduce((sum, m) => sum + m.ga, 0);

  const wins = matches.filter(m => m.gf > m.ga).length;
  const draws = matches.filter(m => m.gf === m.ga).length;

  const formScore =
    (wins * 1 + draws * 0.5) / matches.length;

  const avgGoalsFor = totalGF / matches.length;
  const avgGoalsAgainst = totalGA / matches.length;

  const confidence = Math.min(
    0.9,
    0.4 + formScore * 0.5
  );

  const insight =
    formScore > 0.65
      ? 'Strong recent form with positive goal differential.'
      : formScore > 0.45
      ? 'Mixed form; performance fluctuates.'
      : 'Weak recent form; defensive or attacking issues detected.';

  const result: AnalysisResult = {
    team: input.team,
    league: input.league,
    matchesAnalyzed: matches.length,
    avgGoalsFor: Number(avgGoalsFor.toFixed(2)),
    avgGoalsAgainst: Number(avgGoalsAgainst.toFixed(2)),
    formScore: Number(formScore.toFixed(2)),
    confidence: Number(confidence.toFixed(2)),
    insight
  };

  res.json(result);
};
