import { supabase } from '../lib/supabase';
import { STRIPE_PRICING_MAP } from '../config/stripePrices';
import type { CheckoutRequest, CheckoutResponse } from '../types/subscription';

const FUNCTION_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/stripe-checkout`;
const ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;

export async function createCheckoutSession(req: CheckoutRequest): Promise<CheckoutResponse> {
  const { data: { session } } = await supabase.auth.getSession();

  if (!session?.access_token) {
    throw new Error('AUTH_REQUIRED');
  }

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'apikey': ANON_KEY,
    'Authorization': `Bearer ${session.access_token}`,
  };

  const res = await fetch(FUNCTION_URL, {
    method: 'POST',
    headers,
    body: JSON.stringify(req),
  });

  if (!res.ok) {
    const body = await res.json().catch(() => null);
    throw new Error(body?.error || `Checkout failed (${res.status})`);
  }

  return res.json();
}

export async function startCheckout(
  tier: string,
  cycle: 'monthly' | 'annual'
): Promise<void> {
  // Look up the real Stripe Price ID from the config map
  const priceId = STRIPE_PRICING_MAP[tier]?.[cycle];

  if (!priceId || priceId.includes('YOUR_')) {
    throw new Error(
      `Stripe pricing for "${tier} ${cycle}" is not configured yet. Please add the Price ID in src/config/stripePrices.ts`
    );
  }

  const { url } = await createCheckoutSession({
    priceId,
    tier: tier as CheckoutRequest['tier'],
    cycle,
  });
  if (url) {
    window.location.href = url;
  }
}
