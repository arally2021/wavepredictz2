import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { getProductByPriceId } from '../stripe-config';

export interface SubscriptionInfo {
  isActive: boolean;
  planName: string | null;
  status: string | null;
  priceId: string | null;
}

export function useSubscription(userId: string | undefined) {
  const [subscription, setSubscription] = useState<SubscriptionInfo>({
    isActive: false,
    planName: null,
    status: null,
    priceId: null,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!userId) {
      setLoading(false);
      return;
    }

    const fetchSubscription = async () => {
      try {
        const { data, error } = await supabase
          .from('stripe_user_subscriptions')
          .select('subscription_status, price_id')
          .maybeSingle();

        if (error || !data) {
          setSubscription({ isActive: false, planName: null, status: null, priceId: null });
          return;
        }

        const activeStatuses = ['active', 'trialing'];
        const isActive = activeStatuses.includes(data.subscription_status ?? '');
        const product = data.price_id ? getProductByPriceId(data.price_id) : undefined;

        setSubscription({
          isActive,
          planName: product?.name ?? null,
          status: data.subscription_status ?? null,
          priceId: data.price_id ?? null,
        });
      } catch {
        setSubscription({ isActive: false, planName: null, status: null, priceId: null });
      } finally {
        setLoading(false);
      }
    };

    fetchSubscription();
  }, [userId]);

  return { subscription, loading };
}