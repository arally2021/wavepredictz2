import { useState, useEffect, useCallback } from 'react';
import { calculateTeamStats, validateStatsIntegrity, type TeamStats } from '../lib/footballDataService';

interface UseTeamStatsOptions {
  teamName: string;
  autoRefresh?: boolean;
  refreshInterval?: number;
}

interface UseTeamStatsReturn {
  stats: TeamStats | null;
  loading: boolean;
  error: string | null;
  refresh: () => Promise<void>;
  isValid: boolean;
}

export function useTeamStats({
  teamName,
  autoRefresh = true,
  refreshInterval = 30000
}: UseTeamStatsOptions): UseTeamStatsReturn {
  const [stats, setStats] = useState<TeamStats | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isValid, setIsValid] = useState(false);

  const fetchStats = useCallback(async () => {
    if (!teamName.trim()) {
      setError('Team name is required');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const fetchedStats = await calculateTeamStats(teamName);

      if (!fetchedStats) {
        throw new Error(`No data found for team: ${teamName}`);
      }

      const valid = validateStatsIntegrity(fetchedStats);
      if (!valid) {
        throw new Error('Retrieved data failed validation checks');
      }

      setStats(fetchedStats);
      setIsValid(true);
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : 'Unknown error';
      setError(errorMsg);
      setIsValid(false);
      setStats(null);
    } finally {
      setLoading(false);
    }
  }, [teamName]);

  useEffect(() => {
    if (!autoRefresh) return;

    fetchStats();

    const interval = setInterval(fetchStats, refreshInterval);
    return () => clearInterval(interval);
  }, [teamName, autoRefresh, refreshInterval, fetchStats]);

  return {
    stats,
    loading,
    error,
    refresh: fetchStats,
    isValid
  };
}

export function usePipelineHealth() {
  const [health, setHealth] = useState({
    apiConnected: false,
    dataFlowing: false,
    stateUpdating: false,
    lastUpdate: null as Date | null,
    errorCount: 0
  });

  const recordSuccess = useCallback(() => {
    setHealth(prev => ({
      ...prev,
      apiConnected: true,
      dataFlowing: true,
      stateUpdating: true,
      lastUpdate: new Date(),
      errorCount: Math.max(0, prev.errorCount - 1)
    }));
  }, []);

  const recordError = useCallback(() => {
    setHealth(prev => ({
      ...prev,
      errorCount: prev.errorCount + 1,
      dataFlowing: prev.errorCount < 3
    }));
  }, []);

  return { health, recordSuccess, recordError };
}
