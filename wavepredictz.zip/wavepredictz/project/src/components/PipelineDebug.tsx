import { useState } from 'react';
import { Activity, AlertTriangle, CheckCircle, Zap } from 'lucide-react';
import { calculateTeamStats, validateStatsIntegrity } from '../lib/footballDataService';

interface PipelineDebugProps {
  teamName?: string;
}

/**
 * Pipeline Diagnostic Tool
 * Tests each stage of data flow: API → Calculation → Validation → State
 */
export default function PipelineDebug({ teamName = 'Barcelona' }: PipelineDebugProps) {
  const [teamInput, setTeamInput] = useState(teamName);
  const [results, setResults] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [stages, setStages] = useState<Record<string, { status: 'pending' | 'success' | 'error'; message: string }>>({
    'API Fetch': { status: 'pending', message: 'Waiting to start...' },
    'Data Calculation': { status: 'pending', message: 'Waiting for API response...' },
    'Integrity Check': { status: 'pending', message: 'Waiting for calculation...' },
    'State Update': { status: 'pending', message: 'Waiting for validation...' }
  });

  const runDiagnostics = async () => {
    setLoading(true);
    setResults(null);

    const updateStage = (stage: string, status: 'pending' | 'success' | 'error', message: string) => {
      setStages(prev => ({
        ...prev,
        [stage]: { status, message }
      }));
    };

    try {
      // Stage 1: API Fetch
      updateStage('API Fetch', 'pending', 'Fetching data from football-data.org with cache-busting...');
      console.log(`🔄 [Stage 1] Fetching ${teamInput}...`);

      const stats = await calculateTeamStats(teamInput, '');
      if (!stats) throw new Error('API returned null');

      updateStage('API Fetch', 'success', `✅ Retrieved ${stats.matchesAnalyzed} matches from API`);
      console.log('✅ [Stage 1] API data received:', stats);

      // Stage 2: Data Calculation
      updateStage('Data Calculation', 'pending', 'Verifying calculations...');
      console.log('🔄 [Stage 2] Validating calculations...');

      const hasValidNumbers =
        stats.avgGoalsFor > 0 ||
        stats.avgGoalsFor === 0 && stats.matchesAnalyzed > 0;

      if (!hasValidNumbers && stats.matchesAnalyzed > 0) {
        throw new Error('Calculated metrics are invalid (all zeros)');
      }

      updateStage('Data Calculation', 'success', `✅ Metrics calculated: ${stats.avgGoalsFor} avg goals for, ${stats.avgGoalsAgainst} against`);
      console.log('✅ [Stage 2] Calculations verified:', {
        avgGoalsFor: stats.avgGoalsFor,
        avgGoalsAgainst: stats.avgGoalsAgainst,
        stability: stats.stability
      });

      // Stage 3: Integrity Check
      updateStage('Integrity Check', 'pending', 'Running validation suite...');
      console.log('🔄 [Stage 3] Running integrity checks...');

      const isValid = validateStatsIntegrity(stats);
      if (!isValid) throw new Error('Data integrity validation failed');

      updateStage('Integrity Check', 'success', '✅ All validation checks passed');
      console.log('✅ [Stage 3] Integrity checks passed');

      // Stage 4: State Update
      updateStage('State Update', 'pending', 'Updating React state...');
      console.log('🔄 [Stage 4] Updating state...');

      setResults(stats);
      updateStage('State Update', 'success', '✅ React state updated successfully');
      console.log('✅ [Stage 4] State updated:', stats);

      console.log('🎉 PIPELINE DIAGNOSTIC COMPLETE - All systems operational');
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Unknown error';
      console.error('❌ Pipeline diagnostic failed:', errorMsg);

      if (!results) {
        updateStage('API Fetch', 'error', `❌ ${errorMsg}`);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white rounded-lg shadow-md">
      <div className="flex items-center gap-3 mb-6">
        <Zap className="w-6 h-6 text-yellow-600" />
        <h2 className="text-2xl font-bold text-gray-900">Pipeline Diagnostics</h2>
      </div>

      <p className="text-gray-600 mb-4">
        Test the complete data flow from football-data.org API through to React state updates.
      </p>

      <div className="flex gap-4 mb-6">
        <input
          type="text"
          value={teamInput}
          onChange={(e) => setTeamInput(e.target.value)}
          placeholder="Team name (e.g., Barcelona, Bayern)"
          className="flex-1 px-4 py-2 border border-gray-300 rounded-lg"
          disabled={loading}
        />
        <button
          onClick={runDiagnostics}
          disabled={loading || !teamInput.trim()}
          className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 font-semibold"
        >
          {loading ? 'Testing...' : 'Run Diagnostics'}
        </button>
      </div>

      {/* Stage Progress */}
      <div className="space-y-3">
        {Object.entries(stages).map(([stage, { status, message }]) => (
          <div key={stage} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
            <div className="flex-shrink-0 mt-1">
              {status === 'pending' && (
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-600"></div>
              )}
              {status === 'success' && (
                <CheckCircle className="w-5 h-5 text-green-600" />
              )}
              {status === 'error' && (
                <AlertTriangle className="w-5 h-5 text-red-600" />
              )}
            </div>
            <div className="flex-1">
              <p className="font-medium text-gray-900">{stage}</p>
              <p className={`text-sm ${
                status === 'success' ? 'text-green-700' :
                status === 'error' ? 'text-red-700' :
                'text-gray-600'
              }`}>
                {message}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Results Display */}
      {results && (
        <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
          <p className="font-bold text-green-900 mb-3">✅ Data Successfully Loaded</p>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-gray-600">Team:</span>
              <p className="font-bold text-gray-900">{results.teamName}</p>
            </div>
            <div>
              <span className="text-gray-600">Matches:</span>
              <p className="font-bold text-gray-900">{results.matchesAnalyzed}</p>
            </div>
            <div>
              <span className="text-gray-600">Avg Goals For:</span>
              <p className="font-bold text-green-700">{results.avgGoalsFor.toFixed(2)}</p>
            </div>
            <div>
              <span className="text-gray-600">Avg Goals Against:</span>
              <p className="font-bold text-gray-900">{results.avgGoalsAgainst.toFixed(2)}</p>
            </div>
            <div>
              <span className="text-gray-600">Stability:</span>
              <p className="font-bold text-gray-900">{(results.stability * 100).toFixed(1)}%</p>
            </div>
            <div>
              <span className="text-gray-600">Win Rate:</span>
              <p className="font-bold text-gray-900">{results.winRate.toFixed(1)}%</p>
            </div>
          </div>
        </div>
      )}

      {/* Console Log Output */}
      <div className="mt-6 p-4 bg-gray-900 text-green-400 rounded-lg font-mono text-xs max-h-48 overflow-y-auto">
        <p>📝 Check browser console (F12) for detailed pipeline logs</p>
        <p className="text-gray-500 mt-2">All diagnostic stages will log to console for deep inspection</p>
      </div>
    </div>
  );
}
