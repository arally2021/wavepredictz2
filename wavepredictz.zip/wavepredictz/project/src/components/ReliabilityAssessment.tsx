import { Activity, BarChart3, Heart, AlertTriangle } from 'lucide-react';
import { useState } from 'react';

interface ReliabilityData {
  id: string;
  team_evaluated: string;
  historical_trustworthiness: number;
  outcome_repetition: number;
  context_alignment: number;
  absence_of_hype: number;
  reliability_score: number;
  patience_score: number;
  support_consistency: number;
  value_alignment: number;
  outcome_discipline: number;
  never_settle_trait: boolean;
  impulsiveness_level: number;
  created_at: string;
}

interface ReliabilityAssessmentProps {
  data: ReliabilityData;
}

export default function ReliabilityAssessment({ data }: ReliabilityAssessmentProps) {
  const [expandedSection, setExpandedSection] = useState<string | null>(null);

  const getScoreColor = (score: number) => {
    if (score >= 0.8) return 'bg-green-500';
    if (score >= 0.6) return 'bg-blue-500';
    if (score >= 0.4) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const getScoreLabel = (score: number) => {
    if (score >= 0.8) return 'Excellent';
    if (score >= 0.6) return 'Good';
    if (score >= 0.4) return 'Fair';
    return 'Poor';
  };

  const ScoreMetric = ({ label, value, description }: { label: string; value: number; description?: string }) => (
    <div className="mb-4">
      <div className="flex justify-between items-center mb-2">
        <label className="text-sm font-medium text-gray-700">{label}</label>
        <span className="text-sm font-bold text-gray-900">{(value * 100).toFixed(0)}%</span>
      </div>
      <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
        <div className={`h-full rounded-full transition-all ${getScoreColor(value)}`} style={{ width: `${value * 100}%` }} />
      </div>
      {description && <p className="text-xs text-gray-600 mt-1">{description}</p>}
    </div>
  );

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-purple-500">
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-gray-800 mb-2">{data.team_evaluated}</h2>
            <p className="text-gray-600 text-sm">Reliability Assessment & Human Factor Analysis</p>
          </div>
          <div className="text-right">
            <div className="text-sm font-medium text-gray-600 mb-1">Overall Reliability</div>
            <div className="text-3xl font-bold text-purple-600">{(data.reliability_score * 100).toFixed(0)}%</div>
            <div className="text-xs text-gray-600 mt-1">{getScoreLabel(data.reliability_score)}</div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center gap-3 mb-4">
            <BarChart3 className="w-6 h-6 text-blue-600" />
            <h3 className="text-xl font-semibold text-gray-800">Reliability Metrics</h3>
          </div>
          <div className="space-y-1">
            <ScoreMetric
              label="Historical Trustworthiness"
              value={data.historical_trustworthiness}
              description="Trust based on past accuracy"
            />
            <ScoreMetric
              label="Outcome Repetition"
              value={data.outcome_repetition}
              description="Consistency of pattern recurrence"
            />
            <ScoreMetric
              label="Context Alignment"
              value={data.context_alignment}
              description="Alignment with current circumstances"
            />
            <ScoreMetric label="Absence of Hype" value={data.absence_of_hype} description="Freedom from exaggeration" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center gap-3 mb-4">
            <Heart className="w-6 h-6 text-red-600" />
            <h3 className="text-xl font-semibold text-gray-800">Human Factor Scores</h3>
          </div>
          <div className="space-y-1">
            <ScoreMetric label="Patience Score" value={data.patience_score} description="Capacity to wait for outcomes" />
            <ScoreMetric
              label="Support Consistency"
              value={data.support_consistency}
              description="Steadiness of backing decisions"
            />
            <ScoreMetric label="Value Alignment" value={data.value_alignment} description="Alignment with core values" />
            <ScoreMetric
              label="Outcome Discipline"
              value={data.outcome_discipline}
              description="Adherence to decision framework"
            />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <button
            onClick={() => setExpandedSection(expandedSection === 'reliability' ? null : 'reliability')}
            className="w-full flex items-center justify-between hover:bg-gray-50 p-2 rounded transition"
          >
            <div className="flex items-center gap-3">
              <Activity className="w-5 h-5 text-teal-600" />
              <h3 className="font-semibold text-gray-800">Reliability Insights</h3>
            </div>
            <span className="text-gray-600">
              {expandedSection === 'reliability' ? '−' : '+'}
            </span>
          </button>

          {expandedSection === 'reliability' && (
            <div className="mt-4 pt-4 border-t border-gray-200 space-y-3">
              <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                <p className="text-sm text-blue-900">
                  <span className="font-semibold">Trustworthiness:</span> Historical data shows{' '}
                  {data.historical_trustworthiness > 0.7 ? 'strong' : 'moderate'} reliability in similar situations.
                </p>
              </div>
              <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                <p className="text-sm text-green-900">
                  <span className="font-semibold">Pattern Recurrence:</span> Expected outcome patterns show{' '}
                  {data.outcome_repetition > 0.7 ? 'high' : 'moderate'} repetition frequency.
                </p>
              </div>
              <div className="p-3 bg-teal-50 rounded-lg border border-teal-200">
                <p className="text-sm text-teal-900">
                  <span className="font-semibold">Context Match:</span> Current context is{' '}
                  {data.context_alignment > 0.7 ? 'well-aligned' : 'moderately-aligned'} with historical patterns.
                </p>
              </div>
            </div>
          )}
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <button
            onClick={() => setExpandedSection(expandedSection === 'human' ? null : 'human')}
            className="w-full flex items-center justify-between hover:bg-gray-50 p-2 rounded transition"
          >
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-5 h-5 text-orange-600" />
              <h3 className="font-semibold text-gray-800">Human Factors</h3>
            </div>
            <span className="text-gray-600">
              {expandedSection === 'human' ? '−' : '+'}
            </span>
          </button>

          {expandedSection === 'human' && (
            <div className="mt-4 pt-4 border-t border-gray-200 space-y-3">
              <div className="p-3 bg-purple-50 rounded-lg border border-purple-200">
                <p className="text-sm text-purple-900">
                  <span className="font-semibold">Patience:</span> Decision-maker shows{' '}
                  {data.patience_score > 0.7 ? 'strong ability' : 'moderate capacity'} to wait for outcomes.
                </p>
              </div>
              <div className="p-3 bg-pink-50 rounded-lg border border-pink-200">
                <p className="text-sm text-pink-900">
                  <span className="font-semibold">Consistency:</span> Support for decisions remains{' '}
                  {data.support_consistency > 0.7 ? 'very consistent' : 'reasonably consistent'} under pressure.
                </p>
              </div>
              <div className="p-3 bg-indigo-50 rounded-lg border border-indigo-200">
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-semibold text-indigo-900">Never Settle Trait:</span>
                  <span className={`text-xs font-bold ${data.never_settle_trait ? 'text-green-600' : 'text-gray-600'}`}>
                    {data.never_settle_trait ? 'Present' : 'Not Present'}
                  </span>
                </div>
                <p className="text-sm text-indigo-900">
                  This trait {data.never_settle_trait ? 'drives continuous improvement mindset' : 'allows contentment with progress'}.
                </p>
              </div>
              <div className="p-3 bg-orange-50 rounded-lg border border-orange-200">
                <p className="text-sm text-orange-900">
                  <span className="font-semibold">Impulsiveness:</span> Current impulsiveness level at{' '}
                  <span className="font-bold">{(data.impulsiveness_level * 100).toFixed(0)}%</span> -{' '}
                  {data.impulsiveness_level > 0.6 ? 'caution advised' : 'manageable level'}.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg shadow-md p-6 border-l-4 border-purple-500">
        <h3 className="text-lg font-semibold text-gray-800 mb-3">Assessment Summary</h3>
        <div className="space-y-2 text-sm text-gray-700">
          <p>
            Reliability assessment indicates{' '}
            <span className="font-semibold">
              {data.reliability_score > 0.7 ? 'strong' : data.reliability_score > 0.5 ? 'moderate' : 'limited'}{' '}
              confidence
            </span>{' '}
            in predicted outcomes based on historical data and current context alignment.
          </p>
          <p>
            Human factor evaluation shows{' '}
            <span className="font-semibold">
              {data.outcome_discipline > 0.7 ? 'strong' : 'moderate'} discipline
            </span>{' '}
            with{' '}
            <span className="font-semibold">
              {data.impulsiveness_level < 0.4 ? 'controlled' : data.impulsiveness_level < 0.6 ? 'moderate' : 'elevated'}
            </span>{' '}
            impulsiveness levels.
          </p>
        </div>
        <div className="mt-4 text-xs text-gray-600">
          <p>Assessment ID: {data.id}</p>
          <p>Generated: {new Date(data.created_at).toLocaleString()}</p>
        </div>
      </div>
    </div>
  );
}
