import { useState } from 'react';
import { Sparkles, TrendingUp, TrendingDown, Search } from 'lucide-react';
import { analyzePatterns } from '../lib/analysisService';
import type { PatternAnalysisResult } from '../types/wavepredictz';

export default function PatternAnalysis() {
  const [teamId, setTeamId] = useState('');
  const [result, setResult] = useState<PatternAnalysisResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!teamId.trim()) {
      setError('Please enter a team name');
      return;
    }

    setLoading(true);
    try {
      const analysisResult = await analyzePatterns(teamId.trim());
      setResult(analysisResult);
    } catch (err) {
      setError('Failed to analyze patterns. Please try again.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-purple-500">
        <div className="flex items-center gap-3 mb-2">
          <Sparkles className="w-8 h-8 text-purple-600" />
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">Pattern Analysis</h1>
        </div>
        <p className="text-gray-600">
          Evaluate episodic memory patterns and identify candidates for semantic promotion
        </p>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <form onSubmit={handleAnalyze} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Team Name</label>
            <div className="flex gap-3">
              <input
                type="text"
                value={teamId}
                onChange={(e) => setTeamId(e.target.value)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="Enter team name to analyze..."
                disabled={loading}
              />
              <button
                type="submit"
                disabled={loading}
                className="px-6 py-2 bg-purple-600 text-white font-semibold rounded-lg hover:bg-purple-700 disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {loading ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Search className="w-5 h-5" />
                    Analyze
                  </>
                )}
              </button>
            </div>
          </div>

          {error && (
            <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-red-700 text-sm">{error}</p>
            </div>
          )}
        </form>
      </div>

      {result && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-5 h-5 text-green-600" />
                <h3 className="text-lg font-semibold text-gray-800">Promotions</h3>
              </div>
              <div className="text-3xl font-bold text-green-600 mb-1">
                {result.promotions.filter((p) => p.promoted).length}
              </div>
              <p className="text-sm text-gray-600">Patterns promoted to semantic memory</p>
            </div>

            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center gap-2 mb-2">
                <TrendingDown className="w-5 h-5 text-orange-600" />
                <h3 className="text-lg font-semibold text-gray-800">Demotions</h3>
              </div>
              <div className="text-3xl font-bold text-orange-600 mb-1">{result.demotions.length}</div>
              <p className="text-sm text-gray-600">Low-value patterns demoted</p>
            </div>

            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center gap-2 mb-2">
                <Sparkles className="w-5 h-5 text-purple-600" />
                <h3 className="text-lg font-semibold text-gray-800">Total Patterns</h3>
              </div>
              <div className="text-3xl font-bold text-purple-600 mb-1">{result.promotions.length}</div>
              <p className="text-sm text-gray-600">Patterns evaluated</p>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center gap-3 mb-4">
              <TrendingUp className="w-6 h-6 text-green-600" />
              <h2 className="text-xl font-semibold text-gray-800">Promotion Candidates</h2>
            </div>

            {result.promotions.length === 0 ? (
              <p className="text-gray-600 text-center py-8">No patterns found for analysis</p>
            ) : (
              <div className="space-y-3">
                {result.promotions.map((promotion, index) => (
                  <div
                    key={index}
                    className={`p-4 rounded-lg border-2 ${
                      promotion.promoted
                        ? 'border-green-300 bg-green-50'
                        : 'border-gray-200 bg-white'
                    }`}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-semibold text-gray-800 flex-1 mr-4">
                        {promotion.pattern_key}
                      </h3>
                      {promotion.promoted && (
                        <span className="px-3 py-1 bg-green-500 text-white text-xs font-semibold rounded-full">
                          PROMOTED
                        </span>
                      )}
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-gray-600">Occurrences:</span>
                        <span className="ml-2 font-semibold text-gray-800">
                          {promotion.occurrences}
                        </span>
                      </div>
                      <div>
                        <span className="text-gray-600">Avg Confidence:</span>
                        <span className="ml-2 font-semibold text-gray-800">
                          {promotion.avg_confidence.toFixed(2)}
                        </span>
                      </div>
                    </div>
                    <div className="mt-2">
                      <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${
                            promotion.promoted ? 'bg-green-500' : 'bg-gray-400'
                          }`}
                          style={{ width: `${promotion.avg_confidence * 100}%` }}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {result.demotions.length > 0 && (
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center gap-3 mb-4">
                <TrendingDown className="w-6 h-6 text-orange-600" />
                <h2 className="text-xl font-semibold text-gray-800">Demoted Patterns</h2>
              </div>
              <div className="space-y-3">
                {result.demotions.map((demotion, index) => (
                  <div key={index} className="p-4 border-2 border-orange-200 bg-orange-50 rounded-lg">
                    <h3 className="font-semibold text-gray-800 mb-1">{demotion.pattern_key}</h3>
                    <p className="text-sm text-gray-600">{demotion.reason}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg shadow-md p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Analysis Summary</h3>
            <ul className="space-y-2">
              {result.suggestions.map((suggestion, index) => (
                <li key={index} className="flex items-start gap-2 text-gray-700">
                  <span className="text-purple-500 mt-1">•</span>
                  <span>{suggestion}</span>
                </li>
              ))}
            </ul>
          </div>
        </>
      )}
    </div>
  );
}
