import { useState } from 'react';
import { Search, AlertCircle, CheckCircle, RefreshCw, TrendingUp, TrendingDown } from 'lucide-react';
import { useTeamStats } from '../hooks/useTeamStats';

export default function LiveStatsDisplay() {
  const [teamInput, setTeamInput] = useState('');
  const [submitTeam, setSubmitTeam] = useState('');

  const { stats, loading, error, refresh, isValid } = useTeamStats({
    teamName: submitTeam,
    autoRefresh: !!submitTeam,
    refreshInterval: 30000
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (teamInput.trim()) {
      setSubmitTeam(teamInput.trim());
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Search & Configuration Panel */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl sm:text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
          <Search className="w-6 h-6 text-blue-600" />
          Live Football Analytics
        </h2>

        <form onSubmit={handleSearch} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Team Name</label>
            <input
              type="text"
              value={teamInput}
              onChange={(e) => setTeamInput(e.target.value)}
              placeholder="e.g., Barcelona, Manchester United, Bayern Munich"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              disabled={loading}
            />
            <p className="text-xs text-gray-500 mt-1">Supports misspellings (bacelona → Barcelona)</p>
          </div>

          <div className="flex gap-3">
            <button
              type="submit"
              disabled={loading || !teamInput.trim()}
              className="px-6 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center gap-2"
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  Loading...
                </>
              ) : (
                <>
                  <Search className="w-4 h-4" />
                  Search
                </>
              )}
            </button>

            {stats && (
              <button
                onClick={refresh}
                disabled={loading}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:bg-gray-400 flex items-center gap-2"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                Refresh
              </button>
            )}
          </div>
        </form>
      </div>

      {/* Error Display */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-red-900">Error</p>
            <p className="text-red-700 text-sm">{error}</p>
          </div>
        </div>
      )}

      {/* Success Status */}
      {stats && isValid && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-start gap-3">
          <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-green-900">Data Pipeline Active</p>
            <p className="text-green-700 text-sm">
              Real-time data flowing for {stats.teamName} ({stats.matchesAnalyzed} matches analyzed)
            </p>
          </div>
        </div>
      )}

      {/* Statistics Display */}
      {stats && (
        <div className="space-y-6">
          {/* Key Metrics Grid */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <StatCard
              label="Avg Goals For"
              value={stats.avgGoalsFor.toFixed(2)}
              unit="per match"
              icon={TrendingUp}
              status={stats.avgGoalsFor > 1.5 ? 'excellent' : stats.avgGoalsFor > 1 ? 'good' : 'warning'}
            />
            <StatCard
              label="Avg Goals Against"
              value={stats.avgGoalsAgainst.toFixed(2)}
              unit="per match"
              icon={TrendingDown}
              status={stats.avgGoalsAgainst < 1 ? 'excellent' : stats.avgGoalsAgainst < 1.5 ? 'good' : 'warning'}
            />
            <StatCard
              label="Stability Index"
              value={(stats.stability * 100).toFixed(0)}
              unit="%"
              status={stats.stability > 0.7 ? 'excellent' : stats.stability > 0.5 ? 'good' : 'warning'}
            />
            <StatCard
              label="Win Rate"
              value={stats.winRate.toFixed(1)}
              unit="%"
              status={stats.winRate > 50 ? 'excellent' : stats.winRate > 40 ? 'good' : 'warning'}
            />
          </div>

          {/* Detailed Statistics */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Performance Analysis */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Performance Analysis</h3>
              <div className="space-y-3">
                <StatRow
                  label="Home Performance"
                  value={stats.homePerformance.toFixed(2)}
                  comparison={stats.awayPerformance.toFixed(2)}
                  comparisonLabel="Away"
                />
                <StatRow
                  label="Matches Analyzed"
                  value={stats.matchesAnalyzed}
                  unit="total"
                />
                <StatRow
                  label="First Half Goals"
                  value={stats.firstHalfGoals}
                  comparison={stats.secondHalfGoals}
                  comparisonLabel="Second Half"
                />
                <StatRow
                  label="Volatility Index"
                  value={(stats.volatility * 100).toFixed(1)}
                  unit="%"
                  warning={stats.volatility > 0.5}
                />
              </div>
            </div>

            {/* Win/Draw/Loss Distribution */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Results Distribution</h3>
              <div className="space-y-3">
                <ProgressBar
                  label="Wins"
                  value={stats.winRate}
                  color="bg-green-500"
                />
                <ProgressBar
                  label="Draws"
                  value={stats.drawRate}
                  color="bg-blue-500"
                />
                <ProgressBar
                  label="Losses"
                  value={stats.lossRate}
                  color="bg-red-500"
                />
              </div>
            </div>
          </div>

          {/* Recent Form */}
          {stats.matchHistory.length > 0 && (
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Matches</h3>
              <div className="space-y-2">
                {stats.matchHistory.slice(0, 10).map((match, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition"
                  >
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">{match.date}</p>
                      <p className="text-sm text-gray-600">vs {match.opponent}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-lg">{match.goalsFor} - {match.goalsAgainst}</p>
                      <p className={`text-sm font-semibold ${
                        match.result === 'W' ? 'text-green-600' :
                        match.result === 'D' ? 'text-blue-600' :
                        'text-red-600'
                      }`}>
                        {match.result === 'W' ? 'Win' : match.result === 'D' ? 'Draw' : 'Loss'}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Loading State */}
      {loading && !stats && (
        <div className="bg-white rounded-lg shadow-md p-12 text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Fetching real-time data for {teamInput}...</p>
        </div>
      )}

      {/* Empty State */}
      {!stats && !error && !loading && (
        <div className="bg-blue-50 rounded-lg shadow-md p-8 text-center border border-blue-200">
          <Search className="w-12 h-12 text-blue-400 mx-auto mb-4" />
          <p className="text-gray-600">Enter a team name to load live statistics</p>
          <p className="text-sm text-gray-500 mt-2">Try: Barcelona, Bayern Munich, Liverpool, Real Madrid...</p>
        </div>
      )}
    </div>
  );
}

interface StatCardProps {
  label: string;
  value: string | number;
  unit?: string;
  icon?: React.ComponentType<{ className: string }>;
  status?: 'excellent' | 'good' | 'warning';
}

function StatCard({ label, value, unit, icon: Icon, status = 'good' }: StatCardProps) {
  const bgColor = {
    excellent: 'bg-green-50 border-green-200',
    good: 'bg-blue-50 border-blue-200',
    warning: 'bg-amber-50 border-amber-200'
  }[status];

  const textColor = {
    excellent: 'text-green-700',
    good: 'text-blue-700',
    warning: 'text-amber-700'
  }[status];

  return (
    <div className={`rounded-lg shadow-md p-4 border ${bgColor}`}>
      <p className="text-sm text-gray-600 mb-2">{label}</p>
      <p className={`text-3xl font-bold ${textColor}`}>{value}</p>
      {unit && <p className="text-xs text-gray-500 mt-1">{unit}</p>}
    </div>
  );
}

interface StatRowProps {
  label: string;
  value: string | number;
  comparison?: string | number;
  comparisonLabel?: string;
  unit?: string;
  warning?: boolean;
}

function StatRow({ label, value, comparison, comparisonLabel, unit, warning }: StatRowProps) {
  return (
    <div className="flex items-center justify-between">
      <span className={`text-sm font-medium flex-shrink-0 ${warning ? 'text-amber-700' : 'text-gray-700'}`}>
        {label}
      </span>
      <div className="text-right ml-2">
        <span className="font-bold text-gray-900">
          {value}{unit ? ` ${unit}` : ''}
        </span>
        {comparison !== undefined && (
          <span className="text-xs text-gray-600 ml-2 block sm:inline">
            vs {comparisonLabel}: {comparison}
          </span>
        )}
      </div>
    </div>
  );
}

interface ProgressBarProps {
  label: string;
  value: number;
  color: string;
}

function ProgressBar({ label, value, color }: ProgressBarProps) {
  return (
    <div>
      <div className="flex justify-between items-center mb-1">
        <span className="text-sm font-medium text-gray-700">{label}</span>
        <span className="text-sm font-bold text-gray-900">{value.toFixed(1)}%</span>
      </div>
      <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
        <div
          className={`h-full ${color} transition-all duration-300`}
          style={{ width: `${Math.min(100, value)}%` }}
        />
      </div>
    </div>
  );
}
