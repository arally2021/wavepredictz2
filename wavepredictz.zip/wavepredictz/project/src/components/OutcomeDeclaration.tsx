import { CheckCircle, AlertCircle, TrendingUp, Shield } from 'lucide-react';

interface OutcomeData {
  id: string;
  team_evaluated: string;
  final_status: 'DECLARATION' | 'RESTRICTION' | 'FAST_RESTRICTION' | 'TRIANGULATION_REQUIRED' | 'RESTRICTED_STABLE';
  consistency_score: number;
  inconsistency_score: number;
  primary_probability: number;
  secondary_probability: number;
  triangulation_score: number;
  eligible_for_declaration: boolean;
  reasoning: string;
  created_at: string;
}

interface OutcomeDeclarationProps {
  data: OutcomeData;
}

export default function OutcomeDeclaration({ data }: OutcomeDeclarationProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'DECLARATION':
        return 'bg-green-50 border-green-500 text-green-900';
      case 'RESTRICTION':
        return 'bg-red-50 border-red-500 text-red-900';
      case 'FAST_RESTRICTION':
        return 'bg-red-100 border-red-600 text-red-900';
      case 'TRIANGULATION_REQUIRED':
        return 'bg-yellow-50 border-yellow-500 text-yellow-900';
      case 'RESTRICTED_STABLE':
        return 'bg-blue-50 border-blue-500 text-blue-900';
      default:
        return 'bg-gray-50 border-gray-500 text-gray-900';
    }
  };

  const getStatusIcon = (status: string) => {
    if (status === 'DECLARATION') {
      return <CheckCircle className="w-6 h-6 text-green-600" />;
    }
    return <AlertCircle className="w-6 h-6 text-orange-600" />;
  };

  const getStatusLabel = (status: string) => {
    return status.replace(/_/g, ' ');
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className={`rounded-lg shadow-md p-6 border-l-4 ${getStatusColor(data.final_status)}`}>
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
          <div className="flex items-start gap-4">
            {getStatusIcon(data.final_status)}
            <div>
              <h2 className="text-xl sm:text-2xl font-bold mb-2">{data.team_evaluated}</h2>
              <p className="text-sm opacity-75">Outcome Declaration Analysis</p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-sm font-medium opacity-75 mb-1">Final Status</div>
            <div className="text-lg font-bold">{getStatusLabel(data.final_status)}</div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center gap-3 mb-4">
            <TrendingUp className="w-6 h-6 text-blue-600" />
            <h3 className="text-xl font-semibold text-gray-800">Consistency Metrics</h3>
          </div>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-gray-700 font-medium text-sm">Consistency Score</span>
                <span className="font-bold text-gray-900">{(data.consistency_score * 100).toFixed(1)}%</span>
              </div>
              <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-green-500 rounded-full transition-all"
                  style={{ width: `${data.consistency_score * 100}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-gray-700 font-medium text-sm">Inconsistency Score</span>
                <span className="font-bold text-gray-900">{(data.inconsistency_score * 100).toFixed(1)}%</span>
              </div>
              <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-orange-500 rounded-full transition-all"
                  style={{ width: `${data.inconsistency_score * 100}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center gap-3 mb-4">
            <Shield className="w-6 h-6 text-purple-600" />
            <h3 className="text-xl font-semibold text-gray-800">Probability Metrics</h3>
          </div>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-gray-700 font-medium text-sm">Primary Probability</span>
                <span className="font-bold text-gray-900">{(data.primary_probability * 100).toFixed(1)}%</span>
              </div>
              <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-blue-500 rounded-full transition-all"
                  style={{ width: `${data.primary_probability * 100}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-gray-700 font-medium text-sm">Secondary Probability</span>
                <span className="font-bold text-gray-900">{(data.secondary_probability * 100).toFixed(1)}%</span>
              </div>
              <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-teal-500 rounded-full transition-all"
                  style={{ width: `${data.secondary_probability * 100}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center gap-3 mb-4">
          <TrendingUp className="w-6 h-6 text-teal-600" />
          <h3 className="text-xl font-semibold text-gray-800">Triangulation Analysis</h3>
        </div>
        <div>
          <div className="flex justify-between items-center mb-2">
            <span className="text-gray-700 font-medium">Triangulation Score</span>
            <span className="text-2xl font-bold text-teal-700">{(data.triangulation_score * 100).toFixed(1)}%</span>
          </div>
          <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
            <div
              className="h-full bg-teal-600 rounded-full transition-all"
              style={{ width: `${data.triangulation_score * 100}%` }}
            />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center gap-3 mb-4">
          <Shield className="w-6 h-6 text-gray-600" />
          <h3 className="text-xl font-semibold text-gray-800">Declaration Eligibility</h3>
        </div>
        <div className="p-4 bg-gray-50 rounded-lg border border-gray-200">
          <div className="flex items-center gap-3">
            <div className={`w-4 h-4 rounded-full ${data.eligible_for_declaration ? 'bg-green-500' : 'bg-red-500'}`} />
            <div>
              <p className="font-semibold text-gray-900">
                {data.eligible_for_declaration ? 'Eligible for Declaration' : 'Not Eligible for Declaration'}
              </p>
              <p className="text-sm text-gray-600 mt-1">{data.reasoning}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-gradient-to-r from-blue-50 to-teal-50 rounded-lg shadow-md p-6 border-l-4 border-teal-500">
        <h3 className="text-lg font-semibold text-gray-800 mb-3">Analysis Summary</h3>
        <p className="text-gray-700 leading-relaxed">{data.reasoning}</p>
        <div className="mt-4 text-xs text-gray-600">
          <p>Analysis ID: {data.id}</p>
          <p>Generated: {new Date(data.created_at).toLocaleString()}</p>
        </div>
      </div>
    </div>
  );
}
