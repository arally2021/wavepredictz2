import { useState, type ReactNode } from 'react';
import { Lock, ArrowUp, X, Loader2 } from 'lucide-react';
import type { SubscriptionTier } from '../types/subscription';
import { useSubscription, tierMeets } from '../context/SubscriptionContext';

interface PaywallGateProps {
  tierRequired: SubscriptionTier;
  children: ReactNode;
  featureName?: string;
  onUpgrade?: () => void;
}

const TIER_LABELS: Record<SubscriptionTier, string> = {
  free: 'Free',
  casual: 'Casual',
  pro: 'Professional',
  b2b: 'B2B API',
  elite: 'Elite',
};

export default function PaywallGate({ tierRequired, children, featureName, onUpgrade }: PaywallGateProps) {
  const { tier, isLoading } = useSubscription();
  const [hovered, setHovered] = useState(false);

  if (isLoading) {
    return <div className="min-h-[200px] animate-pulse bg-slate-800/50 rounded-xl" />;
  }

  const hasAccess = tierMeets(tier, tierRequired);

  if (hasAccess) {
    return <>{children}</>;
  }

  return (
    <div
      className="relative rounded-xl overflow-hidden"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {/* Blurred content */}
      <div className="filter blur-md pointer-events-none select-none opacity-50">
        {children}
      </div>

      {/* Overlay */}
      <div className="absolute inset-0 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm rounded-xl">
        <div className="max-w-sm w-full mx-4 p-6 rounded-2xl bg-slate-800/95 border border-cyan-500/30 shadow-2xl shadow-cyan-500/10 text-center">
          {/* Lock icon */}
          <div className="w-14 h-14 rounded-2xl bg-cyan-500/15 flex items-center justify-center mx-auto mb-4">
            <Lock className="w-7 h-7 text-cyan-400" />
          </div>

          {/* Title */}
          <h3 className="text-white font-bold text-lg mb-2">
            {featureName ? `Unlock ${featureName}` : 'Upgrade to Unlock'}
          </h3>

          {/* Description */}
          <p className="text-sm text-slate-400 mb-1">
            This feature requires the
          </p>
          <p className="text-cyan-400 font-semibold mb-4">
            {TIER_LABELS[tierRequired]} tier or higher
          </p>

          {/* Current tier indicator */}
          <div className="flex items-center justify-center gap-2 mb-5 text-xs text-slate-500">
            <span>Your plan: {TIER_LABELS[tier]}</span>
            <ArrowUp className="w-3 h-3 text-cyan-400" />
            <span className="text-cyan-400">{TIER_LABELS[tierRequired]}</span>
          </div>

          {/* CTA */}
          <button
            onClick={onUpgrade}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-emerald-500 text-white font-semibold text-sm hover:shadow-lg hover:shadow-cyan-500/30 transition-all"
          >
            Upgrade Subscription
          </button>
        </div>
      </div>
    </div>
  );
}
