import { useState } from 'react';
import { Search, Zap, Loader2, Radar, Sparkles } from 'lucide-react';
import { fetchRealMatchData } from '../lib/analysisService';
import { computeWeightedStats } from '../lib/timeDecay';
import { generateMatchPredictions, type TeamProfile } from '../lib/predictionEngine';
import { normalizeTeamName } from '../lib/footballDataService';
import MatchPredictionPanel from './MatchPredictionPanel';
import type { MatchPredictionSet } from '../types/prediction';

const TEAM_SUGGESTIONS = [
  'Arsenal', 'Chelsea', 'Liverpool', 'Manchester City', 'Manchester United',
  'Tottenham', 'Newcastle', 'Aston Villa', 'Brighton', 'West Ham',
  'Everton', 'Fulham', 'Wolverhampton', 'Brentford', 'Crystal Palace',
  'Leicester City', 'Nottingham Forest', 'AFC Bournemouth',
];

const LEAGUE_OPTIONS = [
  'Premier League', 'La Liga', 'Serie A', 'Bundesliga', 'Ligue 1',
];

export default function MatchPredictionView() {
  const [homeTeam, setHomeTeam] = useState('');
  const [awayTeam, setAwayTeam] = useState('');
  const [league, setLeague] = useState('Premier League');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [prediction, setPrediction] = useState<MatchPredictionSet | null>(null);
  const [fetchStage, setFetchStage] = useState('');

  const handlePredict = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!homeTeam.trim() || !awayTeam.trim()) {
      setError('Please enter both teams');
      return;
    }
    if (homeTeam.trim().toLowerCase() === awayTeam.trim().toLowerCase()) {
      setError('Home and away teams must be different');
      return;
    }

    setLoading(true);
    setError('');
    setPrediction(null);

    try {
      setFetchStage('Fetching home team data...');
      const homeMatches = await fetchRealMatchData(homeTeam.trim());
      if (homeMatches.length === 0) {
        throw new Error(`No match data found for ${normalizeTeamName(homeTeam.trim())}`);
      }

      setFetchStage('Fetching away team data...');
      const awayMatches = await fetchRealMatchData(awayTeam.trim());
      if (awayMatches.length === 0) {
        throw new Error(`No match data found for ${normalizeTeamName(awayTeam.trim())}`);
      }

      setFetchStage('Computing tactical profiles...');
      const homeStats = computeWeightedStats(homeMatches);
      const awayStats = computeWeightedStats(awayMatches);

      const homeProfile: TeamProfile = {
        name: normalizeTeamName(homeTeam.trim()),
        stats: homeStats,
        isHome: true,
      };
      const awayProfile: TeamProfile = {
        name: normalizeTeamName(awayTeam.trim()),
        stats: awayStats,
        isHome: false,
      };

      setFetchStage('Generating predictions...');
      const result = generateMatchPredictions({
        home: homeProfile,
        away: awayProfile,
        league,
      });

      setPrediction(result);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to generate predictions';
      setError(msg);
    } finally {
      setLoading(false);
      setFetchStage('');
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* ── Terminal-style search panel ── */}
      <div className="rounded-2xl bg-gradient-to-br from-slate-800/80 to-slate-900/80 border border-white/5 glow-soft overflow-hidden">
        {/* Header bar */}
        <div className="flex items-center gap-2 px-5 py-3 border-b border-white/5 bg-slate-900/60">
          <div className="flex gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-red-500/60" />
            <div className="w-2.5 h-2.5 rounded-full bg-amber-500/60" />
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/60" />
          </div>
          <div className="flex items-center gap-2 ml-2">
            <Radar className="w-4 h-4 text-emerald-400" />
            <span className="text-xs font-mono text-slate-400">prediction_engine.terminal</span>
          </div>
        </div>

        {/* Body */}
        <div className="p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="bg-gradient-to-br from-emerald-500/20 to-cyan-500/20 p-3 rounded-xl border border-white/10">
              <Zap className="w-6 h-6 text-emerald-400" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-white">Match Prediction Engine</h2>
              <p className="text-xs text-slate-400">Select two teams to generate tactical trigger predictions</p>
            </div>
          </div>

          <form onSubmit={handlePredict} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {/* Home team */}
              <div>
                <label className="block text-[10px] font-bold tracking-widest text-emerald-400 mb-1.5">HOME TEAM</label>
                <input
                  type="text"
                  value={homeTeam}
                  onChange={(e) => setHomeTeam(e.target.value)}
                  placeholder="e.g., Arsenal"
                  className="w-full px-4 py-2.5 bg-slate-900/60 border border-white/10 rounded-lg text-white text-sm placeholder:text-slate-600 focus:ring-2 focus:ring-emerald-500/40 focus:border-emerald-500/30 transition"
                  disabled={loading}
                  list="team-suggestions"
                />
                <datalist id="team-suggestions">
                  {TEAM_SUGGESTIONS.map(t => <option key={t} value={t} />)}
                </datalist>
              </div>

              {/* Away team */}
              <div>
                <label className="block text-[10px] font-bold tracking-widest text-cyan-400 mb-1.5">AWAY TEAM</label>
                <input
                  type="text"
                  value={awayTeam}
                  onChange={(e) => setAwayTeam(e.target.value)}
                  placeholder="e.g., Chelsea"
                  className="w-full px-4 py-2.5 bg-slate-900/60 border border-white/10 rounded-lg text-white text-sm placeholder:text-slate-600 focus:ring-2 focus:ring-cyan-500/40 focus:border-cyan-500/30 transition"
                  disabled={loading}
                  list="team-suggestions"
                />
              </div>

              {/* League */}
              <div>
                <label className="block text-[10px] font-bold tracking-widest text-slate-400 mb-1.5">LEAGUE</label>
                <select
                  value={league}
                  onChange={(e) => setLeague(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-900/60 border border-white/10 rounded-lg text-white text-sm focus:ring-2 focus:ring-slate-400/40 focus:border-slate-400/30 transition"
                  disabled={loading}
                >
                  {LEAGUE_OPTIONS.map(l => <option key={l} value={l}>{l}</option>)}
                </select>
              </div>
            </div>

            {/* Quick-pick chips */}
            <div className="flex flex-wrap gap-1.5">
              <span className="text-[10px] text-slate-600 font-bold tracking-wider flex items-center mr-1">
                <Sparkles className="w-3 h-3 mr-1" />
                QUICK PICK
              </span>
              {TEAM_SUGGESTIONS.slice(0, 10).map(t => (
                <button
                  key={t}
                  type="button"
                  onClick={() => {
                    if (!homeTeam.trim()) setHomeTeam(t);
                    else if (!awayTeam.trim() && t !== homeTeam) setAwayTeam(t);
                    else setHomeTeam(t);
                  }}
                  className="px-2.5 py-1 text-xs bg-slate-800/60 text-slate-400 rounded-full border border-white/5 hover:bg-emerald-500/10 hover:text-emerald-300 hover:border-emerald-500/20 transition"
                >
                  {t}
                </button>
              ))}
            </div>

            {error && (
              <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
                <p className="text-red-300 text-sm">{error}</p>
              </div>
            )}

            {/* Submit */}
            <button
              type="submit"
              disabled={loading || !homeTeam.trim() || !awayTeam.trim()}
              className="px-6 py-3 bg-gradient-to-r from-emerald-600 to-cyan-600 text-white font-bold rounded-lg hover:from-emerald-500 hover:to-cyan-500 disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-2 transition glow-green"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span className="text-sm">{fetchStage || 'Processing...'}</span>
                </>
              ) : (
                <>
                  <Search className="w-5 h-5" />
                  <span className="text-sm">Generate Predictions</span>
                </>
              )}
            </button>
          </form>
        </div>
      </div>

      {/* Loading skeleton */}
      {loading && (
        <div className="rounded-xl bg-slate-800/40 border border-white/5 p-8 text-center animate-pulse">
          <div className="flex items-center justify-center gap-3 mb-3">
            <Radar className="w-6 h-6 text-emerald-400 animate-spin" style={{ animationDuration: '2s' }} />
            <span className="text-sm text-slate-400">Analyzing tactical patterns...</span>
          </div>
          <div className="flex justify-center gap-1.5">
            {[0, 1, 2].map(i => (
              <div
                key={i}
                className="w-2 h-2 rounded-full bg-emerald-500/60"
                style={{ animation: `fireFlicker 1s ease-in-out ${i * 0.15}s infinite` }}
              />
            ))}
          </div>
        </div>
      )}

      {/* Prediction results */}
      {prediction && !loading && <MatchPredictionPanel data={prediction} />}
    </div>
  );
}
