import { useState } from 'react';
import { supabase } from '../lib/supabase';
import { forcedFreshFetch, type ForcedFetchResult, type TacticalPattern } from '../lib/analysisService';
import {
  Search, RefreshCw, AlertCircle, CheckCircle, Database,
  Target, Shield, MapPin, Activity, Gauge, Layers,
  Server, Zap, FileText, TrendingUp, TrendingDown,
} from 'lucide-react';
import type { TimezoneMode } from '../lib/timezone';
import { formatDateTime } from '../lib/timezone';

const TEAM_SUGGESTIONS = [
  'Arsenal', 'Chelsea', 'Liverpool', 'Real Madrid', 'Barcelona',
  'Bayern Munich', 'PSG', 'Inter', 'Juventus', 'Napoli',
];

const CATEGORY_ICONS: Record<string, React.ComponentType<{ className: string }>> = {
  scoring: Target,
  defensive: Shield,
  tempo: Gauge,
  venue: MapPin,
  form: Activity,
};

const CATEGORY_COLORS: Record<string, string> = {
  scoring: 'bg-blue-50 border-blue-200 text-blue-700',
  defensive: 'bg-green-50 border-green-200 text-green-700',
  tempo: 'bg-amber-50 border-amber-200 text-amber-700',
  venue: 'bg-purple-50 border-purple-200 text-purple-700',
  form: 'bg-cyan-50 border-cyan-200 text-cyan-700',
};

type PipelineStage = 'idle' | 'fetching' | 'analyzing' | 'extracting' | 'storing' | 'complete' | 'error';

export default function FreshFetch({ tzMode = 'local' }: { tzMode?: TimezoneMode } = {}) {
  const [teamInput, setTeamInput] = useState('');
  const [matchLimit, setMatchLimit] = useState(50);
  const [result, setResult] = useState<ForcedFetchResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [stage, setStage] = useState<PipelineStage>('idle');
  const [error, setError] = useState('');
  const [existingBaseline, setExistingBaseline] = useState<number | null>(null);

  const checkBaseline = async () => {
    const { data, error: queryError } = await supabase
      .from('memory_semantic')
      .select('pattern_key, pattern_doc, usefulness_score, provenance, created_at')
      .order('usefulness_score', { ascending: false });

    if (queryError || !data) {
      setExistingBaseline(0);
      return;
    }

    const baselinePatterns = data.filter(
      (p: any) => p.provenance?.source === 'forced-fresh-fetch' || p.provenance?.source === 'forced-fresh-fetch-baseline'
    );
    setExistingBaseline(baselinePatterns.length);
  };

  const handleFetch = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!teamInput.trim()) return;

    setLoading(true);
    setError('');
    setResult(null);
    setStage('fetching');

    try {
      setStage('fetching');
      const fetchResult = await forcedFreshFetch(teamInput.trim(), matchLimit);

      setStage('analyzing');
      await new Promise(r => setTimeout(r, 200));

      setStage('extracting');
      await new Promise(r => setTimeout(r, 200));

      setStage('storing');
      await new Promise(r => setTimeout(r, 200));

      setResult(fetchResult);
      setStage('complete');
      await checkBaseline();
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to complete forced fetch pipeline';
      setError(msg);
      setStage('error');
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (iso: string) => formatDateTime(iso, tzMode);

  const stages = [
    { id: 'fetching', label: 'Fresh Server Fetch', icon: Server, desc: 'Bypassing cache, fetching from football-data.org' },
    { id: 'analyzing', label: 'Analytics Processing', icon: Activity, desc: 'Computing scoring, consistency, and form metrics' },
    { id: 'extracting', label: 'Pattern Extraction', icon: Layers, desc: 'Extracting tactical semantic patterns from match data' },
    { id: 'storing', label: 'Baseline Storage', icon: Database, desc: 'Writing new "All Teams" historical baseline to database' },
  ];

  const currentStageIndex = stages.findIndex(s => s.id === stage);

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
        <div className="flex items-center gap-3 mb-2">
          <div className="bg-gradient-to-br from-orange-500 to-red-600 p-3 rounded-xl">
            <Zap className="w-7 h-7 text-white" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-gray-900">Fresh Data Pipeline</h2>
            <p className="text-sm text-gray-600">Forces a live server-side fetch bypassing all caches, extracts tactical patterns, and builds a new historical baseline</p>
          </div>
        </div>

        {existingBaseline !== null && existingBaseline > 0 && !loading && (
          <div className="mt-3 flex items-center gap-2 text-sm text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
            <Database className="w-4 h-4" />
            <span>Current baseline contains {existingBaseline} stored patterns. A new fetch will overwrite existing patterns for the same team.</span>
          </div>
        )}
      </div>

      {/* Form */}
      <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
        <form onSubmit={handleFetch} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">Team Name</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  value={teamInput}
                  onChange={(e) => setTeamInput(e.target.value)}
                  placeholder="e.g., Arsenal, Chelsea, Liverpool..."
                  className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  disabled={loading}
                />
              </div>
              <div className="flex flex-wrap gap-1.5 mt-2">
                {TEAM_SUGGESTIONS.map(t => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setTeamInput(t)}
                    className="px-3 py-2 text-xs bg-gray-100 text-gray-600 rounded-full hover:bg-orange-100 hover:text-orange-700 transition"
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Match Limit</label>
              <select
                value={matchLimit}
                onChange={(e) => setMatchLimit(parseInt(e.target.value))}
                className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                disabled={loading}
              >
                <option value={5}>Last 5 matches</option>
                <option value={10}>Last 10 matches</option>
                <option value={20}>Last 20 matches</option>
                <option value={38}>Last 38 (full season)</option>
                <option value={50}>Last 50 matches</option>
              </select>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading || !teamInput.trim()}
            className="px-6 py-2.5 bg-gradient-to-r from-orange-600 to-red-600 text-white font-semibold rounded-lg hover:from-orange-700 hover:to-red-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 transition"
          >
            {loading ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
                Processing Pipeline...
              </>
            ) : (
              <>
                <RefreshCw className="w-4 h-4" />
                Force Fresh Fetch
              </>
            )}
          </button>
        </form>
      </div>

      {/* Pipeline Progress */}
      {loading && (
        <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
          <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
            <Activity className="w-5 h-5 text-orange-600" />
            Pipeline Progress
          </h3>
          <div className="space-y-3">
            {stages.map((s, i) => {
              const Icon = s.icon;
              const isComplete = i < currentStageIndex;
              const isCurrent = i === currentStageIndex;
              const isPending = i > currentStageIndex;

              return (
                <div
                  key={s.id}
                  className={`flex items-center gap-4 p-3 rounded-lg border transition-all ${
                    isComplete ? 'bg-green-50 border-green-200' :
                    isCurrent ? 'bg-orange-50 border-orange-300 shadow-sm' :
                    'bg-gray-50 border-gray-200 opacity-50'
                  }`}
                >
                  <div className={`flex-shrink-0 w-10 h-10 flex items-center justify-center rounded-lg ${
                    isComplete ? 'bg-green-500' :
                    isCurrent ? 'bg-orange-500' :
                    'bg-gray-300'
                  }`}>
                    {isComplete ? (
                      <CheckCircle className="w-5 h-5 text-white" />
                    ) : isCurrent ? (
                      <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent" />
                    ) : (
                      <Icon className="w-5 h-5 text-white" />
                    )}
                  </div>
                  <div className="flex-1">
                    <p className={`font-semibold ${isComplete ? 'text-green-800' : isCurrent ? 'text-orange-800' : 'text-gray-500'}`}>
                      {s.label}
                    </p>
                    <p className={`text-sm ${isComplete ? 'text-green-600' : isCurrent ? 'text-orange-600' : 'text-gray-400'}`}>
                      {s.desc}
                    </p>
                  </div>
                  <div className="text-xs font-mono text-gray-400">
                    {i + 1}/{stages.length}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Error */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-red-900">Pipeline Failed</p>
            <p className="text-red-700 text-sm">{error}</p>
          </div>
        </div>
      )}

      {/* Results */}
      {result && stage === 'complete' && (
        <div className="space-y-6">
          {/* Success Banner */}
          <div className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-xl p-5 flex items-start gap-3">
            <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-green-900 text-lg">Pipeline Complete</p>
              <p className="text-green-700">{result.summary}</p>
            </div>
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <SummaryCard
              icon={Server}
              label="Matches Fetched"
              value={result.matchesFetched}
              color="bg-blue-50 border-blue-200 text-blue-700"
            />
            <SummaryCard
              icon={Layers}
              label="Patterns Extracted"
              value={result.tacticalPatterns.length}
              color="bg-orange-50 border-orange-200 text-orange-700"
            />
            <SummaryCard
              icon={Database}
              label="Patterns Stored"
              value={result.patternsStored}
              color="bg-green-50 border-green-200 text-green-700"
            />
            <SummaryCard
              icon={FileText}
              label="Analysis Saved"
              value={result.baselineStored ? 'Yes' : 'No'}
              color="bg-purple-50 border-purple-200 text-purple-700"
            />
          </div>

          {/* Analysis Summary */}
          <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
            <div className="flex items-center gap-2 mb-4">
              <Activity className="w-5 h-5 text-blue-600" />
              <h3 className="text-lg font-bold text-gray-900">Analysis Summary — {result.team}</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 mb-1">Scoring Profile</p>
                <p className="text-sm font-medium text-gray-800">{result.analysis.scoring_tendency_profile.burst_scoring_pattern}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 mb-1">Dual Offense</p>
                <p className="text-sm font-medium text-gray-800">{result.analysis.scoring_tendency_profile.dual_offense_activation}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 mb-1">Stability Index</p>
                <p className="text-sm font-medium text-gray-800">{(result.analysis.consistency_matrix.stability_index * 100).toFixed(0)}% — {result.analysis.consistency_matrix.stability_index > 0.7 ? 'High consistency' : 'Moderate consistency'}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 mb-1">Avg Goals (For/Against)</p>
                <p className="text-sm font-medium text-gray-800">{result.analysis.statistical_overview.avg_goals_for?.toFixed(2)} / {result.analysis.statistical_overview.avg_goals_against?.toFixed(2)}</p>
              </div>
            </div>
            <div className="mt-4 p-4 bg-blue-50 rounded-lg">
              <p className="text-sm text-blue-900">{result.analysis.safe_insight_summary}</p>
            </div>
          </div>

          {/* Tactical Patterns */}
          <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
            <div className="flex items-center gap-2 mb-4">
              <Layers className="w-5 h-5 text-orange-600" />
              <h3 className="text-lg font-bold text-gray-900">Extracted Tactical Patterns</h3>
              <span className="text-xs text-gray-400 ml-auto">{result.tacticalPatterns.length} patterns extracted</span>
            </div>
            <div className="space-y-4">
              {result.tacticalPatterns.map((pattern, i) => {
                const Icon = CATEGORY_ICONS[pattern.category] || Target;
                const colorClass = CATEGORY_COLORS[pattern.category] || 'bg-gray-50 border-gray-200 text-gray-700';

                return (
                  <div key={i} className={`rounded-lg border p-5 ${colorClass}`}>
                    <div className="flex items-start gap-3">
                      <div className="bg-white rounded-lg p-2 flex-shrink-0">
                        <Icon className="w-5 h-5" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-bold text-gray-900">{pattern.title}</h4>
                          <span className="text-xs uppercase tracking-wide bg-white/60 px-2 py-0.5 rounded-full font-medium">
                            {pattern.category}
                          </span>
                        </div>
                        <p className="text-sm text-gray-700 mb-3">{pattern.description}</p>
                        <div className="space-y-1">
                          <p className="text-xs font-semibold text-gray-500 uppercase">Evidence</p>
                          {pattern.evidence.map((ev, j) => (
                            <div key={j} className="flex items-center gap-2 text-xs text-gray-600">
                              <span className="w-1 h-1 bg-gray-400 rounded-full" />
                              <span>{ev}</span>
                            </div>
                          ))}
                        </div>
                        <div className="mt-3 flex items-center gap-2">
                          <span className="text-xs text-gray-500">Confidence:</span>
                          <div className="flex-1 max-w-[100px] h-2 bg-white/60 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-current rounded-full"
                              style={{ width: `${pattern.confidence * 100}%` }}
                            />
                          </div>
                          <span className="text-xs font-bold">{(pattern.confidence * 100).toFixed(0)}%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Database confirmation */}
          <div className="bg-gray-900 rounded-xl shadow-md p-5 text-white">
            <div className="flex items-center gap-3">
              <Database className="w-5 h-5 text-green-400" />
              <div>
                <p className="font-semibold text-sm">New historical baseline stored</p>
                <p className="text-xs text-gray-400 mt-0.5">
                  {result.patternsStored} patterns written to the semantic memory store under the "All Teams" baseline.
                  Existing patterns for {result.team} were updated with fresh evidence from the live API.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Empty state */}
      {!result && !error && !loading && (
        <div className="bg-gradient-to-br from-orange-50 to-red-50 rounded-xl shadow-md p-12 text-center border border-orange-100">
          <Zap className="w-16 h-16 text-orange-300 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-gray-800 mb-2">Fresh Data Pipeline</h3>
          <p className="text-gray-600 max-w-lg mx-auto">
            This tool bypasses all caches and forces a live fetch from football-data.org, then processes the raw
            fixture history to extract tactical semantic patterns and build a new "All Teams" historical baseline.
          </p>
          <div className="flex flex-wrap justify-center gap-2 mt-6">
            {TEAM_SUGGESTIONS.slice(0, 6).map(t => (
              <button
                key={t}
                onClick={() => setTeamInput(t)}
                className="px-3 py-2.5 bg-white text-gray-700 text-sm rounded-lg border border-gray-200 hover:border-orange-400 hover:text-orange-600 transition"
              >
                {t}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function SummaryCard({
  icon: Icon, label, value, color,
}: {
  icon: React.ComponentType<{ className: string }>;
  label: string;
  value: string | number;
  color: string;
}) {
  return (
    <div className={`rounded-lg border p-4 ${color}`}>
      <div className="flex items-center gap-2 mb-2">
        <Icon className="w-4 h-4" />
        <span className="text-xs font-medium uppercase tracking-wide">{label}</span>
      </div>
      <p className="text-2xl font-bold">{value}</p>
    </div>
  );
}
