import { TrendingUp, Activity, Target, Shield } from 'lucide-react';
import type { WaveAnalysis } from '../types/wavepredictz';

interface ScoringProfileProps {
  data: WaveAnalysis;
}

export default function ScoringProfile({ data }: ScoringProfileProps) {
  const profile = data.scoring_tendency_profile;
  const cons = data.consistency_matrix;
  const stats = data.statistical_overview;

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-blue-500">
        <h2 className="text-xl sm:text-2xl font-bold text-gray-800 mb-2">{data.team_evaluated}</h2>
        <p className="text-gray-600 text-sm">Comprehensive Tactical Analysis</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center gap-3 mb-4">
            <Target className="w-6 h-6 text-blue-600" />
            <h3 className="text-xl font-semibold text-gray-800">Scoring Tendency Profile</h3>
          </div>
          <div className="space-y-4">
            <div>
              <h4 className="font-medium text-gray-700 text-sm mb-1">First-Half Behavior</h4>
              <p className="text-gray-600 text-sm leading-relaxed">{profile.first_half_behavior}</p>
            </div>
            <div>
              <h4 className="font-medium text-gray-700 text-sm mb-1">Burst Scoring Pattern</h4>
              <p className="text-gray-600 text-sm leading-relaxed">{profile.burst_scoring_pattern}</p>
            </div>
            <div>
              <h4 className="font-medium text-gray-700 text-sm mb-1">Dual-Offense Activation</h4>
              <p className="text-gray-600 text-sm leading-relaxed">{profile.dual_offense_activation}</p>
            </div>
            <div>
              <h4 className="font-medium text-gray-700 text-sm mb-1">Low-Output Signature</h4>
              <p className="text-gray-600 text-sm leading-relaxed">{profile.low_output_signature}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center gap-3 mb-4">
            <Activity className="w-6 h-6 text-green-600" />
            <h3 className="text-xl font-semibold text-gray-800">Consistency Matrix</h3>
          </div>
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:justify-between items-start gap-1 sm:gap-2">
              <span className="text-gray-700 font-medium min-w-0">Stability Index</span>
              <div className="flex items-center gap-2">
                <div className="w-32 h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-green-500 rounded-full"
                    style={{ width: `${cons.stability_index * 100}%` }}
                  />
                </div>
                <span className="text-sm font-semibold text-gray-800 w-12 text-right">
                  {cons.stability_index.toFixed(2)}
                </span>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row sm:justify-between items-start gap-1 sm:gap-2">
              <span className="text-gray-700 font-medium min-w-0">Volatility Index</span>
              <div className="flex items-center gap-2">
                <div className="w-32 h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-orange-500 rounded-full"
                    style={{ width: `${cons.volatility_index * 100}%` }}
                  />
                </div>
                <span className="text-sm font-semibold text-gray-800 w-12 text-right">
                  {cons.volatility_index.toFixed(2)}
                </span>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row sm:justify-between items-start gap-1 sm:gap-2">
              <span className="text-gray-700 font-medium min-w-0">Inner Strength</span>
              <div className="flex items-center gap-2">
                <div className="w-32 h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-blue-500 rounded-full"
                    style={{ width: `${cons.inner_strength_rating * 100}%` }}
                  />
                </div>
                <span className="text-sm font-semibold text-gray-800 w-12 text-right">
                  {cons.inner_strength_rating.toFixed(2)}
                </span>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row sm:justify-between items-start gap-1 sm:gap-2">
              <span className="text-gray-700 font-medium min-w-0">Required Value</span>
              <div className="flex items-center gap-2">
                <div className="w-32 h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-purple-500 rounded-full"
                    style={{ width: `${cons.required_value_metric * 100}%` }}
                  />
                </div>
                <span className="text-sm font-semibold text-gray-800 w-12 text-right">
                  {cons.required_value_metric.toFixed(2)}
                </span>
              </div>
            </div>
            {cons.instability_factors && cons.instability_factors.length > 0 && (
              <div className="mt-4 pt-4 border-t border-gray-200">
                <h4 className="text-sm font-medium text-gray-700 mb-2">Instability Factors</h4>
                <ul className="space-y-1">
                  {cons.instability_factors.map((factor, i) => (
                    <li key={i} className="text-sm text-gray-600 flex items-start gap-2">
                      <span className="text-orange-500 mt-1">•</span>
                      <span>{factor}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
      </div>

      {stats && (
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center gap-3 mb-4">
            <TrendingUp className="w-6 h-6 text-teal-600" />
            <h3 className="text-xl font-semibold text-gray-800">Statistical Overview</h3>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {stats.avg_goals_for !== undefined && (
              <div className="text-center p-4 bg-teal-50 rounded-lg">
                <div className="text-2xl font-bold text-teal-700">{stats.avg_goals_for.toFixed(2)}</div>
                <div className="text-sm text-gray-600 mt-1">Avg Goals For</div>
              </div>
            )}
            {stats.avg_goals_against !== undefined && (
              <div className="text-center p-4 bg-red-50 rounded-lg">
                <div className="text-2xl font-bold text-red-700">{stats.avg_goals_against.toFixed(2)}</div>
                <div className="text-sm text-gray-600 mt-1">Avg Goals Against</div>
              </div>
            )}
            {stats.xg_trends && (
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <div className="text-sm font-semibold text-blue-700">{stats.xg_trends}</div>
                <div className="text-sm text-gray-600 mt-1">xG Trend</div>
              </div>
            )}
            {stats.momentum_notes && (
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <div className="text-sm font-semibold text-green-700">{stats.momentum_notes}</div>
                <div className="text-sm text-gray-600 mt-1">Momentum</div>
              </div>
            )}
          </div>
        </div>
      )}

      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center gap-3 mb-4">
          <Shield className="w-6 h-6 text-gray-600" />
          <h3 className="text-xl font-semibold text-gray-800">Historical Trends</h3>
        </div>
        <ol className="space-y-2">
          {data.historical_trends.map((trend, i) => (
            <li key={i} className="flex items-start gap-3 text-gray-700">
              <span className="flex-shrink-0 w-6 h-6 bg-gray-200 rounded-full flex items-center justify-center text-xs font-semibold text-gray-600">
                {i + 1}
              </span>
              <span className="text-sm leading-relaxed">{trend}</span>
            </li>
          ))}
        </ol>
      </div>

      <div className="bg-gradient-to-r from-blue-50 to-teal-50 rounded-lg shadow-md p-6 border-l-4 border-teal-500">
        <h3 className="text-lg font-semibold text-gray-800 mb-3">Safe Insight Summary</h3>
        <p className="text-gray-700 leading-relaxed">{data.safe_insight_summary}</p>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Interactive Steps</h3>
        <ol className="space-y-3">
          {data.interactive_steps.map((step, i) => (
            <li key={i} className="flex items-start gap-3">
              <span className="flex-shrink-0 w-8 h-8 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-bold">
                {i + 1}
              </span>
              <span className="text-gray-700 leading-relaxed pt-1">{step}</span>
            </li>
          ))}
        </ol>
      </div>
    </div>
  );
}
