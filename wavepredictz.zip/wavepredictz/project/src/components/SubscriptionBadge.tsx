import React from 'react';
import { Sparkles } from 'lucide-react';
import { useSubscription } from '../hooks/useSubscription';

interface SubscriptionBadgeProps {
  userId: string | undefined;
  className?: string;
}

export default function SubscriptionBadge({ userId, className = '' }: SubscriptionBadgeProps) {
  const { subscription, loading } = useSubscription(userId);

  if (loading || !subscription.isActive || !subscription.planName) return null;

  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-medium ${className}`}
    >
      <Sparkles className="w-3 h-3" />
      {subscription.planName}
    </span>
  );
}