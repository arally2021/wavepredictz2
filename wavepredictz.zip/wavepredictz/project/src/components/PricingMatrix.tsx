import { useState, useRef } from 'react';
import { Check, Zap, Star, Code, Crown, Loader2 } from 'lucide-react';
import { PRICING_TIERS, formatPrice } from '../config/pricing';
import type { BillingCycle, SubscriptionTier } from '../types/subscription';
import { useSubscription } from '../context/SubscriptionContext';
import { startCheckout } from '../hooks/useStripeCheckout';
import ContactSalesModal from './ContactSalesModal';
import AuthModal from './AuthModal';

const TIER_ICONS: Record<SubscriptionTier, typeof Zap> = {
  casual: Zap,
  pro: Star,
  b2b: Code,
  elite: Crown,
  free: Zap,
};

// Map our internal tier IDs to the Stripe pricing config keys
const TIER_STRIPE_KEY: Record<SubscriptionTier, string> = {
  casual: 'casual',
  pro: 'professional',
  b2b: 'b2b',
  elite: 'elite',
  free: 'casual',
};

export default function PricingMatrix() {
  const [cycle, setCycle] = useState<BillingCycle>('monthly');
  const [loadingTier, setLoadingTier] = useState<SubscriptionTier | null>(null);
  const [error, setError] = useState('');
  const [showContactModal, setShowContactModal] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const pendingTierRef = useRef<SubscriptionTier | null>(null);
  const { tier: currentTier, isAuthenticated } = useSubscription();

  const handleSubscribe = async (tierId: SubscriptionTier) => {
    if (tierId === 'elite') {
      setShowContactModal(true);
      return;
    }

    // If not signed in, show the auth modal first and remember the tier
    if (!isAuthenticated) {
      pendingTierRef.current = tierId;
      setShowAuthModal(true);
      return;
    }

    await proceedToCheckout(tierId);
  };

  const proceedToCheckout = async (tierId: SubscriptionTier) => {
    setError('');
    setLoadingTier(tierId);

    try {
      const stripeKey = TIER_STRIPE_KEY[tierId];
      await startCheckout(stripeKey, cycle);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Checkout failed. Please try again.';
      if (msg === 'AUTH_REQUIRED') {
        pendingTierRef.current = tierId;
        setShowAuthModal(true);
      } else {
        setError(msg);
      }
      setLoadingTier(null);
    }
  };

  const handleAuthSuccess = async () => {
    setShowAuthModal(false);
    const pendingTier = pendingTierRef.current;
    pendingTierRef.current = null;
    if (pendingTier) {
      // Brief delay to let the auth state propagate
      await new Promise(r => setTimeout(r, 300));
      await proceedToCheckout(pendingTier);
    }
  };

  return (
    <section id="pricing" className="relative bg-slate-900 py-16 md:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-extrabold text-white mb-4">
            Choose Your <span className="text-cyan-400">Edge</span>
          </h2>
          <p className="text-lg text-slate-400 max-w-2xl mx-auto">
            From casual fans to elite teams — unlock the analytics tier that matches your ambition.
          </p>
        </div>

        {/* Billing toggle */}
        <div className="flex items-center justify-center gap-4 mb-12">
          <span className={`text-sm font-medium ${cycle === 'monthly' ? 'text-white' : 'text-slate-500'}`}>
            Monthly
          </span>
          <button
            onClick={() => setCycle(cycle === 'monthly' ? 'annual' : 'monthly')}
            className="relative w-14 h-7 rounded-full bg-slate-700 transition-colors"
            role="switch"
            aria-checked={cycle === 'annual'}
          >
            <span
              className={`absolute top-1 left-1 w-5 h-5 rounded-full bg-cyan-400 transition-transform ${
                cycle === 'annual' ? 'translate-x-7' : ''
              }`}
            />
          </button>
          <span className={`text-sm font-medium ${cycle === 'annual' ? 'text-white' : 'text-slate-500'}`}>
            Annual
          </span>
          <span className="px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-xs font-semibold text-emerald-400">
            Save 20%
          </span>
        </div>

        {error && (
          <div className="max-w-md mx-auto mb-8 p-4 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-sm text-center">
            {error}
          </div>
        )}

        {/* Pricing cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {PRICING_TIERS.map((tier) => {
            const Icon = TIER_ICONS[tier.id];
            const isCurrent = currentTier === tier.id;
            const isLoading = loadingTier === tier.id;
            const popular = tier.popular;

            return (
              <div
                key={tier.id}
                className={`relative rounded-2xl p-6 flex flex-col transition-all duration-200 ${
                  popular
                    ? 'bg-slate-800/80 border-2 border-cyan-400 shadow-xl shadow-cyan-500/10 lg:scale-105'
                    : 'bg-slate-800/50 border border-slate-700 hover:border-slate-600'
                }`}
              >
                {tier.badge && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <span className="px-4 py-1 rounded-full bg-gradient-to-r from-cyan-500 to-emerald-500 text-white text-xs font-bold tracking-wide shadow-lg">
                      {tier.badge}
                    </span>
                  </div>
                )}

                {/* Icon */}
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 ${
                  popular ? 'bg-cyan-500/20' : 'bg-slate-700/50'
                }`}>
                  <Icon className={`w-6 h-6 ${popular ? 'text-cyan-400' : 'text-slate-400'}`} />
                </div>

                {/* Name */}
                <h3 className="text-white font-bold text-lg mb-1">{tier.name}</h3>
                <p className="text-sm text-slate-400 mb-5 min-h-[2.5rem]">{tier.tagline}</p>

                {/* Price */}
                <div className="mb-5">
                  <div className="flex items-baseline gap-1">
                    <span className="text-4xl font-extrabold text-white">
                      {formatPrice(tier.monthlyPrice, cycle)}
                    </span>
                    <span className="text-slate-500 text-sm">/mo</span>
                  </div>
                  {cycle === 'annual' && (
                    <p className="text-xs text-emerald-400 mt-1">
                      ${(tier.annualPrice).toFixed(0)} billed annually
                    </p>
                  )}
                </div>

                {/* CTA button */}
                <button
                  onClick={() => handleSubscribe(tier.id)}
                  disabled={isLoading || isCurrent}
                  className={`w-full py-3 rounded-xl font-semibold text-sm transition-all duration-200 mb-5 ${
                    isCurrent
                      ? 'bg-slate-700 text-slate-400 cursor-default'
                      : tier.ctaStyle === 'neon'
                      ? 'bg-gradient-to-r from-cyan-500 to-emerald-500 text-white hover:shadow-lg hover:shadow-cyan-500/30'
                      : tier.ctaStyle === 'contact'
                      ? 'bg-slate-700 text-white border border-slate-600 hover:border-cyan-500/50'
                      : tier.ctaStyle === 'outline'
                      ? 'bg-transparent border-2 border-slate-600 text-white hover:border-cyan-500/50'
                      : 'bg-cyan-500 text-white hover:bg-cyan-400'
                  }`}
                >
                  {isLoading ? (
                    <span className="inline-flex items-center gap-2">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Redirecting...
                    </span>
                  ) : isCurrent ? (
                    'Current Plan'
                  ) : (
                    tier.ctaLabel
                  )}
                </button>

                {/* Features */}
                <ul className="space-y-3 flex-1">
                  {tier.features.map((feature, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-slate-300">
                      <Check className={`w-4 h-4 mt-0.5 flex-shrink-0 ${
                        popular ? 'text-cyan-400' : 'text-emerald-500'
                      }`} />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>

                {isCurrent && (
                  <div className="mt-4 text-center">
                    <span className="inline-flex items-center gap-1 text-xs text-cyan-400 font-medium">
                      <Check className="w-3 h-3" /> Active subscription
                    </span>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Free tier note */}
        <div className="mt-10 text-center">
          <p className="text-sm text-slate-500">
            All plans include access to the free tier with 3 predictions per day.
            {!isAuthenticated && ' Sign up to get started — no credit card required.'}
          </p>
        </div>
      </div>

      <AuthModal
        isOpen={showAuthModal}
        onClose={() => {
          setShowAuthModal(false);
          pendingTierRef.current = null;
          setLoadingTier(null);
        }}
        onSuccess={handleAuthSuccess}
      />

      <ContactSalesModal
        isOpen={showContactModal}
        onClose={() => setShowContactModal(false)}
      />
    </section>
  );
}
