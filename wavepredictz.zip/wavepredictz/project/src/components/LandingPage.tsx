import Hero from './Hero';
import PricingMatrix from './PricingMatrix';

interface LandingPageProps {
  onGetStarted: () => void;
}

export default function LandingPage({ onGetStarted }: LandingPageProps) {
  return (
    <div className="bg-slate-900">
      <Hero
        onGetStarted={onGetStarted}
        onViewPricing={() => {
          document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' });
        }}
      />
      <PricingMatrix />
    </div>
  );
}
