import { useState, useEffect } from 'react';
import { Database, Clock, TrendingUp } from 'lucide-react';
import ScoringProfile from './ScoringProfile';
import { getHistoricalFacility } from '../lib/analysisService';
import type { HistoricalFacilityResponse } from '../types/wavepredictz';

interface HistoricalFacilityProps {
  teamId?: string;
}

export default function HistoricalFacility({ teamId }: HistoricalFacilityProps) {
  const [data, setData] = useState<HistoricalFacilityResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [selectedAnalysisId, setSelectedAnalysisId] = useState<string | null>(null);

  useEffect(() => {
    async function load() {
      setLoading(true);
      try {
        const result = await getHistoricalFacility({ team_id: teamId });
        setData(result);
        if (result.analyses.length > 0) {
          setSelectedAnalysisId(result.analyses[0].id || null);
        }
      } catch (error) {
        console.error('Error loading historical facility:', error);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [teamId]);

  if (loading) {
    return (
      <div className="max-w-6xl mx-auto p-6">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="max-w-6xl mx-auto p-6">
        <div className="bg-white rounded-lg shadow-md p-12 text-center">
          <Database className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600">No historical data available</p>
        </div>
      </div>
    );
  }

  const selectedAnalysis = data.analyses.find(a => a.id === selectedAnalysisId);

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-teal-500">
        <div className="flex items-center gap-3 mb-2">
          <Database className="w-8 h-8 text-teal-600" />
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">Historical Facility</h1>
        </div>
        <p className="text-gray-600">{data.summary}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center gap-2 mb-2">
            <Clock className="w-5 h-5 text-blue-600" />
            <h3 className="text-lg font-semibold text-gray-800">Analyses</h3>
          </div>
          <div className="text-3xl font-bold text-blue-600 mb-1">{data.analyses.length}</div>
          <p className="text-sm text-gray-600">Total historical analyses</p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-5 h-5 text-green-600" />
            <h3 className="text-lg font-semibold text-gray-800">Patterns</h3>
          </div>
          <div className="text-3xl font-bold text-green-600 mb-1">{data.patterns.length}</div>
          <p className="text-sm text-gray-600">Semantic patterns identified</p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center gap-2 mb-2">
            <Database className="w-5 h-5 text-teal-600" />
            <h3 className="text-lg font-semibold text-gray-800">Team Focus</h3>
          </div>
          <div className="text-lg font-bold text-teal-600 mb-1">{teamId || 'All Teams'}</div>
          <p className="text-sm text-gray-600">Current filter</p>
        </div>
      </div>

      {data.analyses.length > 0 && (
        <>
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Analysis Timeline</h3>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {data.analyses.map((analysis) => (
                <button
                  key={analysis.id}
                  onClick={() => setSelectedAnalysisId(analysis.id || null)}
                  className={`w-full text-left p-4 rounded-lg border-2 transition-all ${
                    selectedAnalysisId === analysis.id
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300 bg-white'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="font-semibold text-gray-800">
                        {analysis.output.team_evaluated || analysis.input.team}
                      </div>
                      <div className="text-sm text-gray-600">
                        {analysis.input.league && `${analysis.input.league} • `}
                        {analysis.input.recent_matches?.length || 0} matches analyzed
                      </div>
                    </div>
                    <div className="text-xs text-gray-500">
                      {analysis.created_at && new Date(analysis.created_at).toLocaleDateString()}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {selectedAnalysis && (
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-gray-800 mb-4">Selected Analysis</h2>
              <ScoringProfile data={selectedAnalysis.output} />
            </div>
          )}
        </>
      )}

      {data.patterns.length > 0 && (
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Semantic Patterns</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {data.patterns.map((pattern) => (
              <div
                key={pattern.id}
                className="p-4 border border-gray-200 rounded-lg hover:border-teal-300 transition-colors"
              >
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-semibold text-gray-800">{pattern.pattern_key}</h4>
                  <span
                    className={`text-xs px-2 py-1 rounded-full ${
                      pattern.safety_review
                        ? 'bg-green-100 text-green-700'
                        : 'bg-yellow-100 text-yellow-700'
                    }`}
                  >
                    {pattern.safety_review ? 'Reviewed' : 'Pending'}
                  </span>
                </div>
                <div className="text-sm text-gray-600 mb-2">
                  Usefulness: {pattern.usefulness_score.toFixed(2)}
                </div>
                {pattern.provenance && (
                  <div className="text-xs text-gray-500">
                    Source: {pattern.provenance.source || 'Unknown'}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
