import { useState } from 'react';
import {
  Zap, Shield, Target, ChevronDown, Activity, Radio, Layers,
  Lock, Flame, Bookmark, BookmarkCheck, TrendingUp, AlertTriangle,
  ArrowUpRight, ArrowDownRight, Gauge,
} from 'lucide-react';
import type { MatchPredictionSet, MatchPrediction, TriggerType, SecondaryMarket } from '../types/prediction';

// ── Design tokens ──
const TRIGGER_THEME: Record<TriggerType, {
  accent: string; glow: string; bg: string; border: string; text: string; iconBg: string;
  icon: typeof Zap; label: string;
}> = {
  home_or_gg_alignment: {
    accent: '#00E676', glow: 'glow-green', bg: 'bg-slate-800/60', border: 'border-emerald-500/30',
    text: 'text-emerald-400', iconBg: 'bg-emerald-500/10', icon: ArrowUpRight, label: 'HOME MOMENTUM',
  },
  away_or_gg_alignment: {
    accent: '#00E5FF', glow: 'glow-cyan', bg: 'bg-slate-800/60', border: 'border-cyan-500/30',
    text: 'text-cyan-400', iconBg: 'bg-cyan-500/10', icon: ArrowDownRight, label: 'AWAY MOMENTUM',
  },
  gg_activated_over_1_5: {
    accent: '#FF9100', glow: 'glow-amber', bg: 'bg-slate-800/60', border: 'border-amber-500/30',
    text: 'text-amber-400', iconBg: 'bg-amber-500/10', icon: Zap, label: 'GG ACTIVATED',
  },
  draw_or_under_2_5_buffer: {
    accent: '#FFAB40', glow: 'glow-amber', bg: 'bg-slate-800/60', border: 'border-orange-500/30',
    text: 'text-orange-400', iconBg: 'bg-orange-500/10', icon: Shield, label: 'DEFENSIVE BUFFER',
  },
  under_3_5_baseline_lock: {
    accent: '#AA82FF', glow: 'glow-purple', bg: 'bg-slate-800/60', border: 'border-purple-500/30',
    text: 'text-purple-400', iconBg: 'bg-purple-500/10', icon: Lock, label: 'BASELINE LOCK',
  },
  over_0_5_acceleration: {
    accent: '#FF5252', glow: 'glow-amber', bg: 'bg-slate-800/60', border: 'border-red-500/30',
    text: 'text-red-400', iconBg: 'bg-red-500/10', icon: Flame, label: 'EXPLOSIVE',
  },
};

function confidenceColor(pct: number): string {
  if (pct >= 70) return '#00E676';
  if (pct >= 55) return '#00E5FF';
  if (pct >= 40) return '#FF9100';
  return '#64748B';
}

function isHotStreak(pred: MatchPrediction): boolean {
  return pred.confidence >= 70;
}

function isLockedPick(pred: MatchPrediction): boolean {
  return pred.confidence >= 65 && (pred.trigger === 'under_3_5_baseline_lock' || pred.trigger === 'draw_or_under_2_5_buffer');
}

// ── Radial Progress Ring ──
function ProgressRing({ pct, size = 56, stroke = 4 }: { pct: number; size?: number; stroke?: number }) {
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (pct / 100) * circumference;
  const color = confidenceColor(pct);

  return (
    <div className="relative flex-shrink-0" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="transform -rotate-90">
        <circle
          cx={size / 2} cy={size / 2} r={radius}
          strokeWidth={stroke} fill="none"
          className="ring-track"
        />
        <circle
          cx={size / 2} cy={size / 2} r={radius}
          strokeWidth={stroke} fill="none"
          stroke={color}
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          className="ring-progress"
          style={{ filter: `drop-shadow(0 0 4px ${color}66)` }}
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-sm font-black" style={{ color }}>{pct}</span>
      </div>
    </div>
  );
}

// ── Momentum Wave SVG ──
function MomentumWave({ type, color }: { type: TriggerType; color: string }) {
  if (type === 'home_or_gg_alignment' || type === 'away_or_gg_alignment') {
    return (
      <svg width="36" height="16" viewBox="0 0 36 16" className="flex-shrink-0">
        <path d="M2 12 Q8 2, 14 8 T26 6 T34 10" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" opacity="0.8" />
        <circle cx="34" cy="10" r="2.5" fill={color} />
      </svg>
    );
  }
  if (type === 'gg_activated_over_1_5' || type === 'over_0_5_acceleration') {
    return (
      <svg width="36" height="16" viewBox="0 0 36 16" className="flex-shrink-0">
        <path d="M2 14 L8 8 L14 12 L20 4 L26 10 L34 2" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" opacity="0.8" />
        <circle cx="34" cy="2" r="2.5" fill={color} />
      </svg>
    );
  }
  return (
    <svg width="36" height="16" viewBox="0 0 36 16" className="flex-shrink-0">
      <path d="M2 8 L8 8 L14 6 L20 10 L26 8 L34 8" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" opacity="0.6" />
    </svg>
  );
}

// ── Prediction Card ──
function PredictionCard({
  prediction, isBest, index, isWatched, onToggleWatch,
}: {
  prediction: MatchPrediction; isBest: boolean; index: number;
  isWatched: boolean; onToggleWatch: () => void;
}) {
  const [expanded, setExpanded] = useState(isBest);
  const [lockHover, setLockHover] = useState(false);
  const theme = TRIGGER_THEME[prediction.trigger];
  const ThemeIcon = theme.icon;
  const hot = isHotStreak(prediction);
  const locked = isLockedPick(prediction);

  return (
    <div
      className={`animate-slide-up rounded-xl border ${theme.border} ${theme.bg} backdrop-blur-sm card-lift overflow-hidden`}
      style={{ animationDelay: `${index * 60}ms` }}
    >
      {/* Card header */}
      <div className="p-4 flex items-start justify-between gap-3">
        <button
          onClick={() => setExpanded(!expanded)}
          className="flex items-start gap-3 flex-1 min-w-0 text-left group"
        >
          {/* Trigger icon badge */}
          <div className={`w-9 h-9 rounded-lg ${theme.iconBg} flex items-center justify-center flex-shrink-0`}>
            <ThemeIcon className="w-4.5 h-4.5" style={{ color: theme.accent }} />
          </div>

          {/* Trigger label + momentum wave */}
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <span className={`text-[10px] font-bold tracking-widest ${theme.text}`}>{theme.label}</span>
              <MomentumWave type={prediction.trigger} color={theme.accent} />
              {hot && (
                <span className="flex items-center gap-0.5 text-[10px] font-bold text-orange-400">
                  <Flame className="w-3 h-3 animate-fire" />
                  HOT
                </span>
              )}
              {locked && (
                <div
                  onMouseEnter={() => setLockHover(true)}
                  onMouseLeave={() => setLockHover(false)}
                  className={`flex items-center gap-0.5 text-[10px] font-bold text-purple-400 transition-all ${lockHover ? 'animate-none' : 'animate-lock-pulse'}`}
                >
                  <Lock className="w-3 h-3" style={{ transform: lockHover ? 'rotate(-12deg) scale(1.1)' : 'none', transition: 'transform 0.3s ease' }} />
                  LOCK
                </div>
              )}
              {isBest && (
                <span className="px-1.5 py-0.5 bg-emerald-500/20 text-emerald-300 text-[9px] font-bold rounded-full border border-emerald-500/30">
                  TOP
                </span>
              )}
            </div>
            <p className="text-sm text-slate-300 mt-1.5 font-medium leading-snug">
              {prediction.primaryPick}
            </p>
            <p className="text-xs text-slate-500 mt-0.5">
              Safety: <span className="text-slate-400">{prediction.safetyPick}</span>
            </p>
          </div>
        </button>

        {/* Right: progress ring + watchlist + expand */}
        <div className="flex flex-col items-end gap-2 flex-shrink-0">
          <div className="flex items-center gap-2">
            <ProgressRing pct={prediction.confidence} size={48} stroke={3.5} />
            <button
              onClick={onToggleWatch}
              className={`p-1.5 rounded-lg transition-all ${
                isWatched
                  ? 'bg-emerald-500/15 text-emerald-400'
                  : 'bg-slate-700/40 text-slate-500 hover:text-emerald-400 hover:bg-emerald-500/10'
              }`}
              title={isWatched ? 'Remove from watchlist' : 'Add to watchlist'}
            >
              {isWatched ? <BookmarkCheck className="w-4 h-4" /> : <Bookmark className="w-4 h-4" />}
            </button>
            <ChevronDown
              className={`w-4 h-4 text-slate-500 transition-transform cursor-pointer ${expanded ? 'rotate-180' : ''}`}
              onClick={() => setExpanded(!expanded)}
            />
          </div>
        </div>
      </div>

      {/* Expanded detail */}
      {expanded && (
        <div className="px-4 pb-4 space-y-3 border-t border-white/5 pt-3">
          {/* Primary + Safety picks */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <div className="bg-slate-900/50 rounded-lg p-3 border border-white/5">
              <div className="flex items-center gap-1.5 mb-1">
                <Target className="w-3.5 h-3.5" style={{ color: theme.accent }} />
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Primary</span>
              </div>
              <p className="text-sm font-semibold text-slate-200">{prediction.primaryPick}</p>
            </div>
            <div className="bg-slate-900/50 rounded-lg p-3 border border-white/5">
              <div className="flex items-center gap-1.5 mb-1">
                <Shield className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Safety</span>
              </div>
              <p className="text-sm font-semibold text-slate-200">{prediction.safetyPick}</p>
            </div>
          </div>

          {/* Strategy text */}
          <div className="bg-slate-900/40 rounded-lg p-3 border border-white/5">
            <p className="text-xs text-slate-400 leading-relaxed">{prediction.strategy}</p>
          </div>

          {/* Live strategy */}
          {prediction.liveStrategy && (
            <div className="bg-red-500/5 rounded-lg p-3 border border-red-500/15">
              <div className="flex items-center gap-1.5 mb-1">
                <Radio className="w-3.5 h-3.5 text-red-400" />
                <span className="text-[10px] font-bold text-red-400 uppercase tracking-wider">Live Strategy</span>
              </div>
              <p className="text-xs text-red-300/90 leading-relaxed">{prediction.liveStrategy}</p>
            </div>
          )}

          {/* Secondary markets */}
          {prediction.secondaryMarkets.length > 0 && (
            <div className="bg-slate-900/40 rounded-lg p-3 border border-white/5">
              <div className="flex items-center gap-1.5 mb-2.5">
                <Layers className="w-3.5 h-3.5 text-purple-400" />
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Secondary Markets</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {prediction.secondaryMarkets.map((m, i) => (
                  <SecondaryMarketPill key={i} market={m} />
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function SecondaryMarketPill({ market }: { market: SecondaryMarket }) {
  const color = confidenceColor(market.confidence);
  return (
    <div className="text-center p-2 bg-slate-800/60 rounded-lg border border-white/5 transition-all hover:border-white/10">
      <div className="text-base font-black" style={{ color }}>{market.confidence}%</div>
      <div className="text-[10px] text-slate-500 mt-0.5 leading-tight">{market.label}</div>
    </div>
  );
}

// ── Main Panel ──
export type MarketFilter = 'all' | 'over' | 'under' | 'gg' | 'double_chance' | 'explosive';

const FILTER_LABELS: { key: MarketFilter; label: string }[] = [
  { key: 'all', label: 'All Markets' },
  { key: 'over', label: 'Over Goals' },
  { key: 'under', label: 'Under Goals' },
  { key: 'gg', label: 'GG / BTTS' },
  { key: 'double_chance', label: 'Double Chance' },
  { key: 'explosive', label: 'Explosive' },
];

function matchesFilter(pred: MatchPrediction, filter: MarketFilter): boolean {
  if (filter === 'all') return true;
  const p = pred.primaryPick.toLowerCase();
  const s = pred.safetyPick.toLowerCase();
  switch (filter) {
    case 'over': return p.includes('over') || s.includes('over');
    case 'under': return p.includes('under') || s.includes('under');
    case 'gg': return p.includes('btts') || p.includes('gg') || s.includes('btts') || s.includes('gg');
    case 'double_chance': return p.includes('double chance') || s.includes('double chance');
    case 'explosive': return pred.trigger === 'over_0_5_acceleration';
    default: return true;
  }
}

interface MatchPredictionPanelProps {
  data: MatchPredictionSet;
}

export default function MatchPredictionPanel({ data }: MatchPredictionPanelProps) {
  const [filter, setFilter] = useState<MarketFilter>('all');
  const [watchlist, setWatchlist] = useState<Set<number>>(new Set());

  const toggleWatch = (idx: number) => {
    setWatchlist(prev => {
      const next = new Set(prev);
      if (next.has(idx)) next.delete(idx);
      else next.add(idx);
      return next;
    });
  };

  const filtered = data.predictions
    .map((pred, originalIdx) => ({ pred, originalIdx }))
    .filter(({ pred }) => matchesFilter(pred, filter));

  const watchedCount = watchlist.size;
  const avgConfidence = Math.round(
    data.predictions.reduce((s, p) => s + p.confidence, 0) / data.predictions.length
  );

  return (
    <div className="space-y-5">
      {/* ── Match header — dark terminal style ── */}
      <div className="relative rounded-2xl overflow-hidden glow-soft">
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900" />
        <div className="absolute inset-0 opacity-30" style={{
          background: 'radial-gradient(circle at 20% 50%, rgba(0,230,118,0.12), transparent 50%), radial-gradient(circle at 80% 50%, rgba(0,229,255,0.10), transparent 50%)',
        }} />
        <div className="relative p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500/20 to-cyan-500/20 border border-white/10 flex items-center justify-center">
              <Activity className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-white">Tactical Prediction Terminal</h2>
              <p className="text-xs text-slate-400">Advanced trigger-based match analysis</p>
            </div>
          </div>

          {/* Fixture */}
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-3 sm:gap-5">
              <div className="text-center">
                <div className="text-base sm:text-xl font-black text-white">{data.homeTeam}</div>
                <div className="text-[10px] text-emerald-400 font-bold tracking-wider mt-0.5">HOME</div>
              </div>
              <div className="flex flex-col items-center">
                <div className="text-[10px] text-slate-600 font-bold">VS</div>
                <div className="w-8 h-px bg-gradient-to-r from-emerald-500/40 via-slate-600 to-cyan-500/40" />
              </div>
              <div className="text-center">
                <div className="text-base sm:text-xl font-black text-white">{data.awayTeam}</div>
                <div className="text-[10px] text-cyan-400 font-bold tracking-wider mt-0.5">AWAY</div>
              </div>
            </div>
            {data.league && (
              <div className="text-xs text-slate-400 bg-white/5 px-3 py-1 rounded-lg border border-white/10">
                {data.league}
              </div>
            )}
          </div>

          {/* Stats bar */}
          <div className="flex items-center gap-4 mt-4 pt-4 border-t border-white/5">
            <div className="flex items-center gap-1.5">
              <Gauge className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-xs text-slate-400">Avg Confidence</span>
              <span className="text-sm font-bold text-emerald-400">{avgConfidence}%</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-xs text-slate-400">Triggers</span>
              <span className="text-sm font-bold text-amber-400">{data.predictions.length}</span>
            </div>
            {watchedCount > 0 && (
              <div className="flex items-center gap-1.5">
                <BookmarkCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-xs text-slate-400">Watchlist</span>
                <span className="text-sm font-bold text-emerald-400">{watchedCount}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ── Best pick spotlight ── */}
      <div className="rounded-xl bg-gradient-to-br from-slate-800/80 to-slate-900/80 border border-emerald-500/20 p-5 card-lift">
        <div className="flex items-center gap-2 mb-3">
          <div className="w-6 h-6 rounded-lg bg-emerald-500/15 flex items-center justify-center">
            <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <h3 className="text-sm font-bold text-slate-200">Top Prediction</h3>
          {isHotStreak(data.bestPick) && (
            <span className="flex items-center gap-0.5 text-[10px] font-bold text-orange-400 ml-auto">
              <Flame className="w-3 h-3 animate-fire" />
              HOT STREAK
            </span>
          )}
        </div>
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div className="flex-1 min-w-0">
            <p className="text-lg font-bold text-white">{data.bestPick.primaryPick}</p>
            <p className="text-xs text-slate-500 mt-1">Safety: {data.bestPick.safetyPick}</p>
          </div>
          <ProgressRing pct={data.bestPick.confidence} size={64} stroke={5} />
        </div>
        <div className="mt-3 p-3 bg-slate-900/50 rounded-lg border border-white/5">
          <p className="text-xs text-slate-400 leading-relaxed">{data.bestPick.strategy}</p>
        </div>
      </div>

      {/* ── Market filter toggle ── */}
      <div className="flex items-center gap-2 flex-wrap">
        {FILTER_LABELS.map(f => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold tracking-wide transition-all ${
              filter === f.key
                ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 glow-green'
                : 'bg-slate-800/50 text-slate-500 border border-white/5 hover:border-white/10 hover:text-slate-300'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* ── Prediction cards ── */}
      {filtered.length > 0 ? (
        <div className="space-y-3">
          {filtered.map(({ pred, originalIdx }, displayIdx) => (
            <PredictionCard
              key={originalIdx}
              prediction={pred}
              isBest={originalIdx === 0 && filter === 'all'}
              index={displayIdx}
              isWatched={watchlist.has(originalIdx)}
              onToggleWatch={() => toggleWatch(originalIdx)}
            />
          ))}
        </div>
      ) : (
        <div className="rounded-xl bg-slate-800/40 border border-white/5 p-8 text-center">
          <AlertTriangle className="w-8 h-8 text-slate-600 mx-auto mb-2" />
          <p className="text-sm text-slate-500">No triggers match this market filter</p>
        </div>
      )}

      {/* ── Engine summary ── */}
      <div className="rounded-xl bg-gradient-to-r from-slate-800/60 to-slate-900/60 border-l-2 border-emerald-500/40 p-4">
        <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">Engine Summary</h3>
        <p className="text-sm text-slate-400 leading-relaxed">{data.summary}</p>
      </div>
    </div>
  );
}
