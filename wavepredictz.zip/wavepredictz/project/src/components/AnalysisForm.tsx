import { useState } from 'react';
import { Search, Plus, Trash2, AlertCircle, Download, CheckCircle } from 'lucide-react';
import { fetchRealMatchData } from '../lib/analysisService';
import type { AnalysisInput, MatchData } from '../types/wavepredictz';

interface AnalysisFormProps {
  onSubmit: (input: AnalysisInput) => void;
  loading?: boolean;
}

export default function AnalysisForm({ onSubmit, loading }: AnalysisFormProps) {
  const [team, setTeam] = useState('');
  const [league, setLeague] = useState('');
  const [notes, setNotes] = useState('');
  const [matches, setMatches] = useState<MatchData[]>([]);
  const [error, setError] = useState('');
  const [fetchingData, setFetchingData] = useState(false);
  const [dataFetched, setDataFetched] = useState(false);

  const [newMatch, setNewMatch] = useState<MatchData>({
    date: '',
    opponent: '',
    gf: 0,
    ga: 0,
    venue: 'home'
  });

  const handleFetchRealData = async () => {
    if (!team.trim()) {
      setError('Please enter a team name first');
      return;
    }

    setFetchingData(true);
    setError('');
    setDataFetched(false);

    try {
      const realMatches = await fetchRealMatchData(team.trim());
      if (realMatches.length > 0) {
        setMatches(realMatches);
        setDataFetched(true);
      } else {
        setError('No match data found for this team. Try a Premier League, La Liga, Serie A, Bundesliga, or Ligue 1 team, or add matches manually below.');
      }
    } catch (err) {
      setError('Failed to fetch real data. Please add matches manually.');
      console.error(err);
    } finally {
      setFetchingData(false);
    }
  };

  const addMatch = () => {
    if (!newMatch.date) {
      setError('Please enter a match date');
      return;
    }
    setMatches([...matches, newMatch]);
    setNewMatch({
      date: '',
      opponent: '',
      gf: 0,
      ga: 0,
      venue: 'home'
    });
    setError('');
  };

  const removeMatch = (index: number) => {
    setMatches(matches.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!team.trim()) {
      setError('Please enter a team name');
      return;
    }

    const input: AnalysisInput = {
      team: team.trim(),
      league: league.trim() || undefined,
      notes: notes.trim() || undefined,
      recent_matches: matches.length > 0 ? matches : undefined
    };

    onSubmit(input);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center gap-3 mb-6">
          <Search className="w-8 h-8 text-blue-600" />
          <h2 className="text-xl sm:text-2xl font-bold text-gray-800">New Team Analysis</h2>
        </div>

        {error && (
          <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <p className="text-red-700 text-sm">{error}</p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Team Name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={team}
                onChange={(e) => setTeam(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="e.g., Manchester United"
                disabled={loading}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">League</label>
              <select
                value={league}
                onChange={(e) => setLeague(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                disabled={loading}
              >
                <option value="">Select a league</option>
                <option value="Premier League">Premier League (England)</option>
                <option value="La Liga">La Liga (Spain)</option>
                <option value="Serie A">Serie A (Italy)</option>
                <option value="Bundesliga">Bundesliga (Germany)</option>
                <option value="Ligue 1">Ligue 1 (France)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Notes</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Additional context about tactics, injuries, or recent changes..."
              disabled={loading}
            />
          </div>

          <div className="bg-gradient-to-r from-green-50 to-teal-50 border border-green-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <Download className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <h4 className="font-semibold text-green-900 mb-1">Auto-Fetch Real Data</h4>
                <p className="text-sm text-green-700 mb-3">
                  Fetch real match history from football-data.org API
                </p>
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={handleFetchRealData}
                    disabled={fetchingData || loading || !team.trim()}
                    className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center gap-2 text-sm font-medium"
                  >
                    {fetchingData ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                        Fetching...
                      </>
                    ) : (
                      <>
                        <Download className="w-4 h-4" />
                        Fetch Real Matches
                      </>
                    )}
                  </button>
                  {dataFetched && (
                    <div className="flex items-center gap-2 text-green-700 text-sm">
                      <CheckCircle className="w-4 h-4" />
                      <span>{matches.length} matches loaded</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="border-t pt-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Recent Matches</h3>

            <div className="bg-gray-50 rounded-lg p-4 mb-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Date</label>
                  <input
                    type="date"
                    value={newMatch.date}
                    onChange={(e) => setNewMatch({ ...newMatch, date: e.target.value })}
                    className="w-full px-3 py-2 text-sm border border-gray-300 rounded"
                    disabled={loading}
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Opponent</label>
                  <input
                    type="text"
                    value={newMatch.opponent}
                    onChange={(e) => setNewMatch({ ...newMatch, opponent: e.target.value })}
                    className="w-full px-3 py-2 text-sm border border-gray-300 rounded"
                    placeholder="Team name"
                    disabled={loading}
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Goals For</label>
                  <input
                    type="number"
                    min="0"
                    value={newMatch.gf}
                    onChange={(e) => setNewMatch({ ...newMatch, gf: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 text-sm border border-gray-300 rounded"
                    disabled={loading}
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Goals Against</label>
                  <input
                    type="number"
                    min="0"
                    value={newMatch.ga}
                    onChange={(e) => setNewMatch({ ...newMatch, ga: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 text-sm border border-gray-300 rounded"
                    disabled={loading}
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Venue</label>
                  <select
                    value={newMatch.venue}
                    onChange={(e) => setNewMatch({ ...newMatch, venue: e.target.value as 'home' | 'away' })}
                    className="w-full px-3 py-2 text-sm border border-gray-300 rounded"
                    disabled={loading}
                  >
                    <option value="home">Home</option>
                    <option value="away">Away</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">&nbsp;</label>
                  <button
                    type="button"
                    onClick={addMatch}
                    className="w-full px-3 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 flex items-center justify-center gap-2"
                    disabled={loading}
                  >
                    <Plus className="w-4 h-4" />
                    Add
                  </button>
                </div>
              </div>
            </div>

            {matches.length > 0 && (
              <div className="space-y-2">
                {matches.map((match, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 bg-white border border-gray-200 rounded-lg"
                  >
                    <div className="flex flex-wrap items-center gap-2 sm:gap-4 text-sm flex-1 min-w-0">
                      <span className="text-gray-600 whitespace-nowrap">{match.date}</span>
                      {match.opponent && (
                        <span className="font-medium text-gray-800 truncate">vs {match.opponent}</span>
                      )}
                      <span className="font-bold text-gray-900 whitespace-nowrap">
                        {match.gf} - {match.ga}
                      </span>
                      <span
                        className={`px-2 py-1 rounded text-xs whitespace-nowrap ${
                          match.venue === 'home'
                            ? 'bg-green-100 text-green-700'
                            : 'bg-blue-100 text-blue-700'
                        }`}
                      >
                        {match.venue === 'home' ? 'Home' : 'Away'}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => removeMatch(index)}
                      className="p-2 -m-2 text-red-600 hover:text-red-700 flex-shrink-0"
                      disabled={loading}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="flex justify-end pt-4 border-t">
            <button
              type="submit"
              disabled={loading}
              className="px-6 py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center gap-2"
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  Analyzing...
                </>
              ) : (
                <>
                  <Search className="w-5 h-5" />
                  Generate Analysis
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
