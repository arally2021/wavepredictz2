import { useState, useCallback } from 'react';
import {
  Search, Radio, Calendar, Trophy, Users, MapPin, Clock,
  TrendingUp, TrendingDown, Activity, ChevronRight, Globe,
  RefreshCw, AlertCircle, BarChart3, Flag, Target,
} from 'lucide-react';
import type { TimezoneMode } from '../lib/timezone';
import { formatDate as fmtDate, formatTimeWithTz, getTimezoneLabel } from '../lib/timezone';

interface TeamInfo {
  name: string;
  shortName: string;
  tla: string;
  venue: string;
  founded: number | null;
  colors: string;
  website: string;
}

interface MatchInfo {
  date: string;
  competition: string;
  homeTeam: string;
  awayTeam: string;
  homeId: number | null;
  awayId: number | null;
  status: string;
  statusDetail: string;
  matchday: number | null;
  stage: string | null;
  fullTimeHome: number | null;
  fullTimeAway: number | null;
  halfTimeHome: number | null;
  halfTimeAway: number | null;
  isHome: boolean;
}

interface StandingRow {
  position: number;
  team: string;
  teamId: number | null;
  played: number;
  won: number;
  drawn: number;
  lost: number;
  goalsFor: number;
  goalsAgainst: number;
  goalDifference: number;
  points: number;
  form: string | null;
}

interface ScorerInfo {
  name: string;
  team: string;
  goals: number;
  assists: number | null;
  penalties: number | null;
}

interface LiveAnalysisResponse {
  team: TeamInfo;
  leagueCode: string;
  leagueName: string;
  liveMatch: MatchInfo | null;
  recentMatches: MatchInfo[];
  upcomingMatch: MatchInfo | null;
  standing: StandingRow | null;
  topScorers: ScorerInfo[];
  note: string;
  error?: string;
  warning?: string;
}

const TEAM_SUGGESTIONS = [
  'Arsenal', 'Chelsea', 'Liverpool', 'Manchester City', 'Manchester United',
  'Tottenham', 'Newcastle', 'Aston Villa', 'Brighton', 'West Ham',
  'Barcelona', 'Real Madrid', 'Atletico Madrid', 'Juventus', 'Inter',
  'AC Milan', 'Napoli', 'Bayern Munich', 'Borussia Dortmund', 'PSG',
];

const LEAGUE_OPTIONS = [
  { label: 'Premier League', value: 'Premier League' },
  { label: 'La Liga', value: 'La Liga' },
  { label: 'Serie A', value: 'Serie A' },
  { label: 'Bundesliga', value: 'Bundesliga' },
  { label: 'Ligue 1', value: 'Ligue 1' },
  { label: 'Champions League', value: 'Champions League' },
];

export default function LiveAnalyst({ tzMode = 'local' }: { tzMode?: TimezoneMode } = {}) {
  const [teamInput, setTeamInput] = useState('');
  const [league, setLeague] = useState('Premier League');
  const [data, setData] = useState<LiveAnalysisResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSearch = useCallback(async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!teamInput.trim()) return;

    setLoading(true);
    setError('');
    setData(null);

    try {
      const fnUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/live-analysis?team=${encodeURIComponent(teamInput.trim())}&league=${encodeURIComponent(league)}`;
      const fnRes = await fetch(fnUrl, {
        headers: {
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
      });

      const result = await fnRes.json().catch(() => null) as LiveAnalysisResponse | null;

      if (!fnRes.ok || !result) {
        const msg = result?.error || `Request failed (${fnRes.status})`;
        throw new Error(msg);
      }

      if (result.error) {
        throw new Error(result.error);
      }

      setData(result);
    } catch (err) {
      const raw = err instanceof Error ? err.message : 'Failed to fetch live analysis data';
      const friendly = raw.includes('rate limit')
        ? 'The football data service rate limit was reached. Please wait a minute and try again.'
        : raw.includes('not recognized')
        ? raw
        : raw.includes('Could not fetch') || raw.includes('No match data')
        ? 'Live data is temporarily unavailable. The service may be rate-limited or the season data is not yet ready. Please try again shortly.'
        : raw;
      setError(friendly);
    } finally {
      setLoading(false);
    }
  }, [teamInput, league]);

  const handleRefresh = () => handleSearch();

  const formatDate = (iso: string) => fmtDate(iso, tzMode);
  const formatTime = (iso: string) => formatTimeWithTz(iso, tzMode);

  const getResultBadge = (m: MatchInfo) => {
    if (m.fullTimeHome === null || m.fullTimeAway === null) return null;
    // Use the isHome flag already bound by the edge function's parseMatch,
    // which maps homeTeam/awayTeam identities directly from the API response.
    // Do NOT re-derive isHome from standings teamId — that breaks when
    // standings are unavailable (null teamId → false → inverted result).
    const gf = m.isHome ? m.fullTimeHome : m.fullTimeAway;
    const ga = m.isHome ? m.fullTimeAway : m.fullTimeHome;
    if (gf > ga) return { label: 'W', color: 'bg-green-100 text-green-700 border-green-300' };
    if (gf === ga) return { label: 'D', color: 'bg-blue-100 text-blue-700 border-blue-300' };
    return { label: 'L', color: 'bg-red-100 text-red-700 border-red-300' };
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
        <div className="flex items-center gap-3 mb-6">
          <div className="bg-gradient-to-br from-blue-500 to-cyan-600 p-3 rounded-xl">
            <Radio className="w-7 h-7 text-white" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-gray-900">Live Football Analyst</h2>
            <p className="text-sm text-gray-600">Real-time match data, statistics, and tactical insights from football-data.org</p>
          </div>
        </div>

        <form onSubmit={handleSearch} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">Team Name</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  value={teamInput}
                  onChange={(e) => setTeamInput(e.target.value)}
                  placeholder="e.g., Arsenal, Chelsea, Liverpool..."
                  className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  disabled={loading}
                />
              </div>
              <div className="flex flex-wrap gap-1.5 mt-2">
                {TEAM_SUGGESTIONS.slice(0, 8).map(t => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setTeamInput(t)}
                    className="px-3 py-2 text-xs bg-gray-100 text-gray-600 rounded-full hover:bg-blue-100 hover:text-blue-700 transition"
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">League</label>
              <select
                value={league}
                onChange={(e) => setLeague(e.target.value)}
                className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                disabled={loading}
              >
                {LEAGUE_OPTIONS.map(opt => (
                  <option key={opt.value} value={opt.value}>{opt.label}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex gap-3">
            <button
              type="submit"
              disabled={loading || !teamInput.trim()}
              className="px-6 py-2.5 bg-gradient-to-r from-blue-600 to-cyan-600 text-white font-semibold rounded-lg hover:from-blue-700 hover:to-cyan-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 transition"
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Search className="w-4 h-4" />
                  Fetch Live Data
                </>
              )}
            </button>
            {data && (
              <button
                type="button"
                onClick={handleRefresh}
                disabled={loading}
                className="px-4 py-2.5 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 disabled:opacity-50 flex items-center gap-2 transition"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                Refresh
              </button>
            )}
          </div>
        </form>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-red-900">Error</p>
            <p className="text-red-700 text-sm">{error}</p>
          </div>
        </div>
      )}

      {loading && !data && (
        <div className="bg-white rounded-xl shadow-md p-16 text-center">
          <div className="animate-spin rounded-full h-14 w-14 border-4 border-blue-200 border-t-blue-600 mx-auto mb-4" />
          <p className="text-gray-700 font-medium">Fetching live analysis for {teamInput}...</p>
          <p className="text-sm text-gray-500 mt-1">Connecting to football-data.org API</p>
        </div>
      )}

      {data && (
        <div className="space-y-6">
          {/* Team Profile Banner */}
          <div className="bg-gradient-to-r from-gray-900 via-blue-900 to-cyan-900 rounded-xl shadow-xl p-6 text-white relative overflow-hidden">
            <div className="absolute right-0 top-0 w-64 h-64 bg-white opacity-5 rounded-full -mr-32 -mt-32" />
            <div className="absolute left-0 bottom-0 w-48 h-48 bg-cyan-400 opacity-10 rounded-full -ml-24 -mb-24" />
            <div className="relative flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="bg-white/20 backdrop-blur px-5 py-3 rounded-xl border border-white/20">
                  <span className="text-3xl font-black tracking-tight">{data.team.tla}</span>
                </div>
                <div>
                  <h3 className="text-2xl font-bold">{data.team.name}</h3>
                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-blue-200 mt-1">
                    {data.team.venue && (
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5" /> {data.team.venue}
                      </span>
                    )}
                    {data.team.founded && (
                      <span className="flex items-center gap-1">
                        <Flag className="w-3.5 h-3.5" /> Est. {data.team.founded}
                      </span>
                    )}
                    {data.team.colors && (
                      <span className="flex items-center gap-1">
                        <Activity className="w-3.5 h-3.5" /> {data.team.colors}
                      </span>
                    )}
                    {data.team.website && (
                      <a
                        href={data.team.website}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-1 text-cyan-300 hover:text-cyan-200 transition"
                      >
                        <Globe className="w-3.5 h-3.5" /> Website
                      </a>
                    )}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2 bg-white/10 backdrop-blur px-4 py-2 rounded-lg border border-white/20">
                <Trophy className="w-5 h-5 text-amber-300" />
                <span className="text-sm font-medium">{data.leagueName}</span>
              </div>
            </div>
          </div>

          {/* Note banner */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 flex items-center gap-2 text-sm text-blue-800">
            <Radio className="w-4 h-4 flex-shrink-0" />
            <span>{data.note}</span>
          </div>

          {/* Stale cache warning */}
          {data.warning && (
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 flex items-center gap-2 text-sm text-amber-800">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>Showing cached data — live API is temporarily unavailable ({data.warning}).</span>
            </div>
          )}

          {/* Live Match / Most Recent */}
          {data.liveMatch && (
            <div className="bg-white rounded-xl shadow-lg overflow-hidden border-2 border-red-400">
              <div className="bg-red-500 text-white px-5 py-2.5 flex items-center gap-2">
                <span className="relative flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75" />
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-white" />
                </span>
                <span className="font-bold text-sm uppercase tracking-wide">Live Match</span>
                <span className="text-red-100 text-sm ml-auto">{data.liveMatch.competition}</span>
              </div>
              <MatchCard match={data.liveMatch} teamId={data.standing?.teamId ?? null} isLive tzMode={tzMode} />
            </div>
          )}

          {/* Most Recent Match (if no live match) */}
          {!data.liveMatch && data.recentMatches.length > 0 && (
            <div className="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-200">
              <div className="bg-gray-800 text-white px-5 py-2.5 flex items-center gap-2">
                <Clock className="w-4 h-4" />
                <span className="font-bold text-sm uppercase tracking-wide">Most Recent Fixture</span>
                <span className="text-gray-300 text-sm ml-auto">{data.recentMatches[0].competition}</span>
              </div>
              <MatchCard match={data.recentMatches[0]} teamId={data.standing?.teamId ?? null} tzMode={tzMode} />
            </div>
          )}

          {/* League Standing & Upcoming Match */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {data.standing && (
              <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
                <div className="flex items-center gap-2 mb-4">
                  <BarChart3 className="w-5 h-5 text-blue-600" />
                  <h3 className="text-lg font-bold text-gray-900">League Standing</h3>
                </div>
                <div className="space-y-4">
                  <div className="flex items-baseline gap-3">
                    <span className="text-5xl font-black text-gray-900">{data.standing.position}</span>
                    <span className="text-gray-500 text-sm">position in {data.leagueName}</span>
                  </div>
                  <div className="grid grid-cols-3 gap-2 sm:gap-3">
                    <div className="text-center bg-gray-50 rounded-lg py-2">
                      <p className="text-2xl font-bold text-gray-900">{data.standing.points}</p>
                      <p className="text-xs text-gray-500">Points</p>
                    </div>
                    <div className="text-center bg-gray-50 rounded-lg py-2">
                      <p className="text-2xl font-bold text-gray-900">{data.standing.played}</p>
                      <p className="text-xs text-gray-500">Played</p>
                    </div>
                    <div className="text-center bg-gray-50 rounded-lg py-2">
                      <p className={`text-2xl font-bold ${data.standing.goalDifference >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {data.standing.goalDifference > 0 ? '+' : ''}{data.standing.goalDifference}
                      </p>
                      <p className="text-xs text-gray-500">Goal Diff</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-4 gap-2 text-center">
                    <div>
                      <p className="text-xl font-bold text-green-600">{data.standing.won}</p>
                      <p className="text-xs text-gray-500">Won</p>
                    </div>
                    <div>
                      <p className="text-xl font-bold text-blue-600">{data.standing.drawn}</p>
                      <p className="text-xs text-gray-500">Drawn</p>
                    </div>
                    <div>
                      <p className="text-xl font-bold text-red-600">{data.standing.lost}</p>
                      <p className="text-xs text-gray-500">Lost</p>
                    </div>
                    <div>
                      <p className="text-xl font-bold text-gray-900">{data.standing.goalsFor}</p>
                      <p className="text-xs text-gray-500">GF</p>
                    </div>
                  </div>
                  {data.standing.form && (
                    <div>
                      <p className="text-xs text-gray-500 mb-2">Recent Form (last 5)</p>
                      <div className="flex gap-1.5">
                        {data.standing.form.split(',').slice(-5).map((r, i) => (
                          <span
                            key={i}
                            className={`w-8 h-8 flex items-center justify-center rounded text-sm font-bold ${
                              r === 'W' ? 'bg-green-500 text-white' :
                              r === 'D' ? 'bg-blue-500 text-white' :
                              'bg-red-500 text-white'
                            }`}
                          >
                            {r}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Upcoming Match */}
            {data.upcomingMatch ? (
              <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
                <div className="flex items-center gap-2 mb-4">
                  <Calendar className="w-5 h-5 text-blue-600" />
                  <h3 className="text-lg font-bold text-gray-900">Next Fixture</h3>
                </div>
                <div className="space-y-3">
                  <div className="bg-blue-50 rounded-lg p-3 text-center">
                    <p className="text-2xl font-bold text-blue-900">{formatDate(data.upcomingMatch.date)}</p>
                    <p className="text-sm text-blue-600">{formatTime(data.upcomingMatch.date)}</p>
                    <p className="text-xs text-gray-400 mt-0.5">{tzMode === 'local' ? 'Local' : 'Stadium/UK'} time ({getTimezoneLabel(tzMode)})</p>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <span className="font-semibold text-gray-800">{data.upcomingMatch.homeTeam}</span>
                      {data.upcomingMatch.isHome && <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-medium">Home</span>}
                    </div>
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <span className="font-semibold text-gray-800">{data.upcomingMatch.awayTeam}</span>
                      {!data.upcomingMatch.isHome && <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full font-medium">Away</span>}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Trophy className="w-4 h-4 text-gray-400" />
                    <span>{data.upcomingMatch.competition}</span>
                    {data.upcomingMatch.matchday && (
                      <span className="text-gray-400">· Matchday {data.upcomingMatch.matchday}</span>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
                <div className="flex items-center gap-2 mb-4">
                  <Calendar className="w-5 h-5 text-gray-400" />
                  <h3 className="text-lg font-bold text-gray-900">Next Fixture</h3>
                </div>
                <p className="text-gray-500 text-sm text-center py-8">No upcoming scheduled matches.</p>
              </div>
            )}

            {/* Top Scorers */}
            {data.topScorers.length > 0 && (
              <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
                <div className="flex items-center gap-2 mb-4">
                  <Target className="w-5 h-5 text-blue-600" />
                  <h3 className="text-lg font-bold text-gray-900">Top Scorers</h3>
                  <span className="text-xs text-gray-400 ml-auto">{data.leagueName}</span>
                </div>
                <div className="space-y-2.5">
                  {data.topScorers.slice(0, 8).map((s, i) => (
                    <div key={i} className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 transition">
                      <span className={`w-6 h-6 flex items-center justify-center rounded text-xs font-bold ${
                        i < 3 ? 'bg-amber-100 text-amber-700' : 'bg-gray-100 text-gray-500'
                      }`}>
                        {i + 1}
                      </span>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-900 truncate">{s.name}</p>
                        <p className="text-xs text-gray-500 truncate">{s.team}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-lg font-bold text-gray-900">{s.goals}</p>
                        <p className="text-xs text-gray-400">goals</p>
                      </div>
                      {s.assists !== null && (
                        <div className="text-right border-l pl-3">
                          <p className="text-lg font-bold text-blue-600">{s.assists}</p>
                          <p className="text-xs text-gray-400">assists</p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Recent Results */}
          {data.recentMatches.length > 0 && (
            <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
              <div className="flex items-center gap-2 mb-4">
                <Activity className="w-5 h-5 text-blue-600" />
                <h3 className="text-lg font-bold text-gray-900">Recent Results</h3>
                <span className="text-xs text-gray-400 ml-auto">Last {data.recentMatches.length} matches</span>
              </div>
              <div className="space-y-2">
                {data.recentMatches.map((m, i) => {
                  const badge = getResultBadge(m);
                  return (
                    <div
                      key={i}
                      className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition"
                    >
                      {badge && (
                        <span className={`w-8 h-8 flex items-center justify-center rounded border text-sm font-bold ${badge.color}`}>
                          {badge.label}
                        </span>
                      )}
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-900">
                          {m.homeTeam} <span className="text-gray-400">vs</span> {m.awayTeam}
                        </p>
                        <p className="text-xs text-gray-500">
                          {formatDate(m.date)} · {m.competition}
                          {m.matchday && ` · MD${m.matchday}`}
                        </p>
                      </div>
                      <div className="text-right">
                        {m.fullTimeHome !== null && m.fullTimeAway !== null ? (
                          <>
                            <p className="text-xl font-bold text-gray-900">
                              {m.fullTimeHome} - {m.fullTimeAway}
                            </p>
                            <p className="text-xs text-gray-400">
                              HT: {m.halfTimeHome ?? '-'} - {m.halfTimeAway ?? '-'}
                            </p>
                          </>
                        ) : (
                          <p className="text-sm text-gray-400">{m.statusDetail}</p>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Empty state */}
      {!data && !error && !loading && (
        <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl shadow-md p-12 text-center border border-blue-100">
          <Radio className="w-16 h-16 text-blue-300 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-gray-800 mb-2">Live Football Analysis</h3>
          <p className="text-gray-600 max-w-md mx-auto">
            Enter any team name to retrieve real-time match data, league standings, recent results, upcoming fixtures, and top scorers.
          </p>
          <div className="flex flex-wrap justify-center gap-2 mt-6">
            {TEAM_SUGGESTIONS.slice(0, 6).map(t => (
              <button
                key={t}
                onClick={() => { setTeamInput(t); }}
                className="px-3 py-2.5 bg-white text-gray-700 text-sm rounded-lg border border-gray-200 hover:border-blue-400 hover:text-blue-600 transition"
              >
                {t}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function MatchCard({ match, teamId, isLive, tzMode = 'local' }: { match: MatchInfo; teamId: number | null; isLive?: boolean; tzMode?: TimezoneMode }) {
  const formatDate = (iso: string) => fmtDate(iso, tzMode);

  return (
    <div className="p-6">
      <div className="grid grid-cols-3 items-center gap-2 sm:gap-4">
        {/* Home team */}
        <div className="text-center">
          <div className="bg-gray-100 rounded-xl p-4 mb-2">
            <p className="font-bold text-gray-900 text-sm md:text-base">{match.homeTeam}</p>
          </div>
          {match.isHome && <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-medium">Your Team</span>}
        </div>

        {/* Score / Status */}
        <div className="text-center">
          {match.fullTimeHome !== null && match.fullTimeAway !== null ? (
            <div>
              <p className={`text-3xl sm:text-4xl md:text-5xl font-black ${isLive ? 'text-red-600' : 'text-gray-900'}`}>
                {match.fullTimeHome} <span className="text-gray-300 text-xl sm:text-2xl md:text-3xl">-</span> {match.fullTimeAway}
              </p>
              <p className="text-xs text-gray-500 mt-1">
                {match.statusDetail}
                {match.halfTimeHome !== null && ` · HT: ${match.halfTimeHome}-${match.halfTimeAway}`}
              </p>
            </div>
          ) : (
            <div>
              <p className="text-2xl font-bold text-gray-400">{match.statusDetail}</p>
              <p className="text-xs text-gray-500 mt-1">{formatDate(match.date)}</p>
            </div>
          )}
        </div>

        {/* Away team */}
        <div className="text-center">
          <div className="bg-gray-100 rounded-xl p-4 mb-2">
            <p className="font-bold text-gray-900 text-sm md:text-base">{match.awayTeam}</p>
          </div>
          {!match.isHome && <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full font-medium">Your Team</span>}
        </div>
      </div>

      {/* Match meta */}
      <div className="flex flex-wrap items-center justify-center gap-3 mt-4 pt-4 border-t border-gray-100 text-sm text-gray-500">
        {match.matchday && <span className="flex items-center gap-1"><ChevronRight className="w-3.5 h-3.5" /> Matchday {match.matchday}</span>}
        {match.stage && match.stage !== 'REGULAR_SEASON' && <span className="flex items-center gap-1"><Trophy className="w-3.5 h-3.5" /> {match.stage}</span>}
        <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" /> {formatDate(match.date)}</span>
      </div>
    </div>
  );
}
