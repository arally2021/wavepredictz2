import type { MatchData } from '../types/wavepredictz';

const MS_PER_DAY = 86_400_000;
const RECENT_WINDOW_DAYS = 60;
const RECENT_BOOST = 3;
const DECAY_INTERVAL_DAYS = 183; // ~6 months
const DECAY_FACTOR = 0.85;

/**
 * Returns a dimensionless weight for a match based on how long ago it was played.
 *
 * 1. Matches within the last 60 days get a 3x boost so the rolling archetype
 *    tracks current tactical style rather than career-long averages.
 * 2. Every 6 months beyond the recent window, the weight decays by 15% —
 *    preventing stale defensive-era results from diluting a modern
 *    high-press profile.
 */
function estimateXg(goals: number): number {
  if (goals <= 0) return 0.35;
  if (goals === 1) return 1.1;
  if (goals === 2) return 1.85;
  if (goals === 3) return 2.5;
  return 2.5 + (goals - 3) * 0.6;
}

export function matchWeight(matchDate: string, now: Date = new Date()): number {
  const matchTime = new Date(matchDate).getTime();
  if (Number.isNaN(matchTime)) return 1;

  const ageDays = (now.getTime() - matchTime) / MS_PER_DAY;

  if (ageDays <= RECENT_WINDOW_DAYS) {
    return RECENT_BOOST;
  }

  const monthsBeyond = ageDays - RECENT_WINDOW_DAYS;
  const decayIntervals = monthsBeyond / DECAY_INTERVAL_DAYS;
  return RECENT_BOOST * Math.pow(DECAY_FACTOR, decayIntervals);
}

export interface WeightedStats {
  avgGoalsFor: number;
  avgGoalsAgainst: number;
  avgXg: number;
  avgXga: number;
  weightedVariance: number;
  stabilityIndex: number;
  volatilityIndex: number;
  dualScoreRate: number;
  formTrend: number;
  homeAvg: number;
  awayAvg: number;
  cleanSheetRate: number;
  cleanSheetRateLast10: number;
  bttsRate: number;
  highScoringRate: number;
  burstRate: number;
  winRate: number;
  drawRate: number;
  lossRate: number;
  matchCount: number;
  totalWeight: number;
  recentWeight: number;
  staleWeight: number;
}

/**
 * Compute rolling-team-archetype statistics using time-decay half-life
 * weighting. Every aggregate (goals, variance, rates) is a weighted
 * average — not a naive arithmetic mean — so the result reflects the
 * *current* tactical era of the team.
 */
export function computeWeightedStats(matches: MatchData[], now: Date = new Date()): WeightedStats {
  if (matches.length === 0) {
    return {
      avgGoalsFor: 0,
      avgGoalsAgainst: 0,
      avgXg: 0,
      avgXga: 0,
      weightedVariance: 0,
      stabilityIndex: 0,
      volatilityIndex: 0,
      dualScoreRate: 0,
      formTrend: 0.5,
      homeAvg: 0,
      awayAvg: 0,
      cleanSheetRate: 0,
      cleanSheetRateLast10: 0,
      bttsRate: 0,
      highScoringRate: 0,
      burstRate: 0,
      winRate: 0,
      drawRate: 0,
      lossRate: 0,
      matchCount: 0,
      totalWeight: 0,
      recentWeight: 0,
      staleWeight: 0,
    };
  }

  const weights = matches.map(m => matchWeight(m.date, now));
  const totalWeight = weights.reduce((s, w) => s + w, 0);

  // Weighted goal averages
  const wGF = matches.reduce((s, m, i) => s + m.gf * weights[i], 0) / totalWeight;
  const wGA = matches.reduce((s, m, i) => s + m.ga * weights[i], 0) / totalWeight;

  // xG / xGA — use actual values if available, otherwise estimate from goals
  const wXg = matches.reduce((s, m, i) => {
    const xg = m.xg ?? estimateXg(m.gf);
    return s + xg * weights[i];
  }, 0) / totalWeight;
  const wXga = matches.reduce((s, m, i) => {
    const xga = m.xga ?? estimateXg(m.ga);
    return s + xga * weights[i];
  }, 0) / totalWeight;

  // Clean sheet rate over last 10 matches (unweighted, simple count)
  const sortedByDate = [...matches].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  const last10 = sortedByDate.slice(0, 10);
  const cleanSheetsLast10 = last10.filter(m => m.ga === 0).length;
  const cleanSheetRateLast10 = last10.length > 0 ? cleanSheetsLast10 / last10.length : 0;

  // Weighted variance (using weighted mean)
  const wVariance =
    matches.reduce((s, m, i) => s + weights[i] * Math.pow(m.gf - wGF, 2), 0) / totalWeight;

  const stabilityIndex = Math.max(0, Math.min(1, 1 - wVariance / 4));
  const volatilityIndex = Math.min(1, wVariance / 2);

  // Weighted rates
  const dualScoreWeight = matches.reduce((s, m, i) => s + (m.gf > 0 && m.ga > 0 ? weights[i] : 0), 0);
  const cleanSheetWeight = matches.reduce((s, m, i) => s + (m.ga === 0 ? weights[i] : 0), 0);
  const highScoringWeight = matches.reduce((s, m, i) => s + (m.gf + m.ga >= 3 ? weights[i] : 0), 0);
  const burstWeight = matches.reduce((s, m, i) => s + (m.gf >= 3 ? weights[i] : 0), 0);

  // Weighted venue splits
  const homeMatches = matches.filter(m => m.venue === 'home');
  const awayMatches = matches.filter(m => m.venue === 'away');
  const homeW = homeMatches.map(m => matchWeight(m.date, now));
  const awayW = awayMatches.map(m => matchWeight(m.date, now));
  const homeTotalW = homeW.reduce((s, w) => s + w, 0);
  const awayTotalW = awayW.reduce((s, w) => s + w, 0);

  const homeAvg = homeTotalW > 0
    ? homeMatches.reduce((s, m, i) => s + m.gf * homeW[i], 0) / homeTotalW
    : wGF;
  const awayAvg = awayTotalW > 0
    ? awayMatches.reduce((s, m, i) => s + m.gf * awayW[i], 0) / awayTotalW
    : wGF;

  // Weighted form trend (last 3 matches by recency)
  const sorted = [...matches].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  const recent3 = sorted.slice(0, 3);
  const recent3Weights = recent3.map(m => matchWeight(m.date, now));
  const recent3TotalW = recent3Weights.reduce((s, w) => s + w, 0);
  const formTrend = recent3TotalW > 0
    ? recent3.reduce((s, m, i) => {
        const v = m.gf > m.ga ? 1 : m.gf === m.ga ? 0.5 : 0;
        return s + v * recent3Weights[i];
      }, 0) / recent3TotalW
    : 0.5;

  // Weighted W/D/L rates
  const winW = matches.reduce((s, m, i) => s + (m.gf > m.ga ? weights[i] : 0), 0);
  const drawW = matches.reduce((s, m, i) => s + (m.gf === m.ga ? weights[i] : 0), 0);
  const lossW = matches.reduce((s, m, i) => s + (m.gf < m.ga ? weights[i] : 0), 0);

  // Recent vs stale weight split for diagnostics
  const recentWeight = matches.reduce((s, m, i) => {
    const ageDays = (now.getTime() - new Date(m.date).getTime()) / MS_PER_DAY;
    return s + (ageDays <= RECENT_WINDOW_DAYS ? weights[i] : 0);
  }, 0);
  const staleWeight = totalWeight - recentWeight;

  return {
    avgGoalsFor: wGF,
    avgGoalsAgainst: wGA,
    weightedVariance: wVariance,
    stabilityIndex,
    volatilityIndex,
    dualScoreRate: dualScoreWeight / totalWeight,
    formTrend,
    homeAvg,
    awayAvg,
    cleanSheetRate: cleanSheetWeight / totalWeight,
    cleanSheetRateLast10,
    bttsRate: dualScoreWeight / totalWeight,
    highScoringRate: highScoringWeight / totalWeight,
    burstRate: burstWeight / totalWeight,
    winRate: winW / totalWeight,
    drawRate: drawW / totalWeight,
    lossRate: lossW / totalWeight,
    matchCount: matches.length,
    avgXg: wXg,
    avgXga: wXga,
    totalWeight,
    recentWeight,
    staleWeight,
  };
}
