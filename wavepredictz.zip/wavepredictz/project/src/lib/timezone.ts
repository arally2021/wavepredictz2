export type TimezoneMode = 'local' | 'stadium';

const STADIUM_TZ = 'Europe/London';

export function getUserTimezone(): string {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || STADIUM_TZ;
  } catch {
    return STADIUM_TZ;
  }
}

function getTimezoneAbbreviation(tz: string): string {
  try {
    const parts = new Intl.DateTimeFormat('en-GB', {
      timeZone: tz,
      timeZoneName: 'short',
    }).formatToParts(new Date());
    const tzPart = parts.find(p => p.type === 'timeZoneName');
    return tzPart?.value || tz;
  } catch {
    return tz;
  }
}

export function formatDate(iso: string, mode: TimezoneMode = 'local'): string {
  if (!iso) return 'TBD';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return 'TBD';
  const tz = mode === 'stadium' ? STADIUM_TZ : getUserTimezone();
  return d.toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    timeZone: tz,
  });
}

export function formatTime(iso: string, mode: TimezoneMode = 'local'): string {
  if (!iso) return '';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return '';
  const tz = mode === 'stadium' ? STADIUM_TZ : getUserTimezone();
  return d.toLocaleTimeString('en-GB', {
    hour: '2-digit',
    minute: '2-digit',
    timeZone: tz,
  });
}

export function formatDateTime(iso: string, mode: TimezoneMode = 'local'): string {
  if (!iso) return 'TBD';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return 'TBD';
  const tz = mode === 'stadium' ? STADIUM_TZ : getUserTimezone();
  return d.toLocaleString('en-GB', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    timeZone: tz,
  });
}

export function formatTimeWithTz(iso: string, mode: TimezoneMode = 'local'): string {
  const time = formatTime(iso, mode);
  if (!time) return '';
  const tz = mode === 'stadium' ? STADIUM_TZ : getUserTimezone();
  const abbr = getTimezoneAbbreviation(tz);
  return `${time} ${abbr}`;
}

export function getTimezoneLabel(mode: TimezoneMode): string {
  const tz = mode === 'stadium' ? STADIUM_TZ : getUserTimezone();
  return getTimezoneAbbreviation(tz);
}
