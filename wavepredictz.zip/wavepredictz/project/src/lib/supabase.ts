import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string;
          email: string | null;
          name: string | null;
          is_premium: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          email?: string | null;
          name?: string | null;
          is_premium?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          email?: string | null;
          name?: string | null;
          is_premium?: boolean;
          created_at?: string;
        };
      };
      analyses: {
        Row: {
          id: string;
          user_id: string | null;
          input: Record<string, any>;
          output: Record<string, any>;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id?: string | null;
          input?: Record<string, any>;
          output?: Record<string, any>;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string | null;
          input?: Record<string, any>;
          output?: Record<string, any>;
          created_at?: string;
        };
      };
      memory_episodes: {
        Row: {
          id: string;
          team_id: string;
          type: string;
          content: Record<string, any>;
          embedding: Record<string, any>;
          confidence: number;
          created_at: string;
        };
        Insert: {
          id?: string;
          team_id: string;
          type?: string;
          content?: Record<string, any>;
          embedding?: Record<string, any>;
          confidence?: number;
          created_at?: string;
        };
        Update: {
          id?: string;
          team_id?: string;
          type?: string;
          content?: Record<string, any>;
          embedding?: Record<string, any>;
          confidence?: number;
          created_at?: string;
        };
      };
      memory_semantic: {
        Row: {
          id: string;
          pattern_key: string;
          pattern_doc: Record<string, any>;
          provenance: Record<string, any>;
          usefulness_score: number;
          safety_review: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          pattern_key: string;
          pattern_doc?: Record<string, any>;
          provenance?: Record<string, any>;
          usefulness_score?: number;
          safety_review?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          pattern_key?: string;
          pattern_doc?: Record<string, any>;
          provenance?: Record<string, any>;
          usefulness_score?: number;
          safety_review?: boolean;
          created_at?: string;
        };
      };
      pattern_suggestions: {
        Row: {
          id: string;
          team_id: string;
          suggestion: Record<string, any>;
          status: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          team_id: string;
          suggestion?: Record<string, any>;
          status?: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          team_id?: string;
          suggestion?: Record<string, any>;
          status?: string;
          created_at?: string;
        };
      };
      event_log: {
        Row: {
          id: string;
          user_id: string | null;
          event_type: string;
          details: Record<string, any>;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id?: string | null;
          event_type: string;
          details?: Record<string, any>;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string | null;
          event_type?: string;
          details?: Record<string, any>;
          created_at?: string;
        };
      };
    };
  };
}
