/**
 * Football Data Service
 *
 * Calls the fetch-matches Supabase Edge Function (which talks to
 * football-data.org server-side with the API key kept secret) and
 * computes full team statistics. Falls back to the built-in verified
 * dataset if the edge function is unavailable.
 */

import { PREMIER_LEAGUE_MATCHES, type DatasetMatch } from './matchData';

export interface TeamStats {
  teamName: string;
  matchesAnalyzed: number;
  avgGoalsFor: number;
  avgGoalsAgainst: number;
  stability: number;
  volatility: number;
  recentForm: string[];
  homePerformance: number;
  awayPerformance: number;
  firstHalfGoals: number;
  secondHalfGoals: number;
  winRate: number;
  drawRate: number;
  lossRate: number;
  matchHistory: Array<{
    date: string;
    opponent: string;
    goalsFor: number;
    goalsAgainst: number;
    venue: 'home' | 'away';
    result: 'W' | 'D' | 'L';
  }>;
}

interface EdgeFunctionMatch {
  date: string;
  opponent: string;
  gf: number;
  ga: number;
  venue: 'home' | 'away';
  result: 'W' | 'D' | 'L';
}

interface EdgeFunctionResponse {
  team: string;
  matchesAnalyzed: number;
  avgGoalsFor?: number;
  avgGoalsAgainst?: number;
  matches: EdgeFunctionMatch[];
  source?: string;
  error?: string;
  warning?: string;
}

const TEAM_NAME_MAP: Record<string, string> = {
  'bournemouth': 'AFC Bournemouth',
  'afc bournemouth': 'AFC Bournemouth',
  'cherry': 'AFC Bournemouth',
  'the cherries': 'AFC Bournemouth',
  'cherries': 'AFC Bournemouth',

  'arsenal': 'Arsenal',
  'arsenal fc': 'Arsenal',

  'liverpool': 'Liverpool',
  'liverpool fc': 'Liverpool',

  'manchester city': 'Manchester City',
  'man city': 'Manchester City',
  'city': 'Manchester City',

  'manchester united': 'Manchester United',
  'man utd': 'Manchester United',
  'man united': 'Manchester United',
  'united': 'Manchester United',

  'chelsea': 'Chelsea',
  'chelsea fc': 'Chelsea',

  'tottenham': 'Tottenham Hotspur',
  'spurs': 'Tottenham Hotspur',
  'tottenham hotspur': 'Tottenham Hotspur',

  'newcastle': 'Newcastle United',
  'newcastle united': 'Newcastle United',

  'aston villa': 'Aston Villa',
  'villa': 'Aston Villa',

  'brighton': 'Brighton',
  'brighton hove albion': 'Brighton',

  'nottingham forest': 'Nottingham Forest',
  'forest': 'Nottingham Forest',
  'nottm forest': 'Nottingham Forest',

  'west ham': 'West Ham United',
  'west ham united': 'West Ham United',
  'ham': 'West Ham United',

  'everton': 'Everton',

  'fulham': 'Fulham',

  'wolverhampton': 'Wolverhampton',
  'wolves': 'Wolverhampton',
  'wolverhampton wanderers': 'Wolverhampton',

  'brentford': 'Brentford',

  'crystal palace': 'Crystal Palace',
  'palace': 'Crystal Palace',

  'leicester': 'Leicester City',
  'leicester city': 'Leicester City',
  'foxes': 'Leicester City',

  'ipswich': 'Ipswich Town',
  'ipswich town': 'Ipswich Town',

  'southampton': 'Southampton',
  'saints': 'Southampton',
};

export function normalizeTeamName(input: string): string {
  const normalized = input.toLowerCase().trim();
  return TEAM_NAME_MAP[normalized] || input.trim();
}

function datasetMatches(name: string): DatasetMatch[] {
  const normalized = normalizeTeamName(name).toLowerCase();
  return PREMIER_LEAGUE_MATCHES.filter(
    m =>
      m.homeTeam.toLowerCase() === normalized ||
      m.awayTeam.toLowerCase() === normalized
  );
}

interface RawMatch {
  date: string;
  opponent: string;
  gf: number;
  ga: number;
  venue: 'home' | 'away';
}

function computeStatsFromMatches(normalizedName: string, rawMatches: RawMatch[]): TeamStats {
  if (rawMatches.length === 0) {
    throw new Error('No matches to compute stats from');
  }

  let totalGoalsFor = 0;
  let totalGoalsAgainst = 0;
  let homeGoalsFor = 0;
  let awayGoalsFor = 0;
  let wins = 0;
  let draws = 0;
  let losses = 0;

  const matchHistory = rawMatches.map(match => {
    const goalsFor = match.gf;
    const goalsAgainst = match.ga;

    totalGoalsFor += goalsFor;
    totalGoalsAgainst += goalsAgainst;

    if (match.venue === 'home') homeGoalsFor += goalsFor;
    else awayGoalsFor += goalsFor;

    if (goalsFor > goalsAgainst) wins++;
    else if (goalsFor === goalsAgainst) draws++;
    else losses++;

    const result = goalsFor > goalsAgainst ? 'W' : goalsFor === goalsAgainst ? 'D' : 'L';

    return {
      date: match.date,
      opponent: match.opponent,
      goalsFor,
      goalsAgainst,
      venue: match.venue,
      result
    };
  });

  const avgGoalsFor = totalGoalsFor / matchHistory.length;
  const avgGoalsAgainst = totalGoalsAgainst / matchHistory.length;

  const variance =
    matchHistory.reduce((sum, m) => sum + Math.pow(m.goalsFor - avgGoalsFor, 2), 0) /
    matchHistory.length;

  const stability = Math.max(0, Math.min(1, 1 - variance / 4));
  const volatility = Math.min(1, variance / 2);

  const homeMatches = matchHistory.filter(m => m.venue === 'home');
  const awayMatches = matchHistory.filter(m => m.venue === 'away');

  const homePerformance = homeMatches.length > 0 ? homeGoalsFor / homeMatches.length : 0;
  const awayPerformance = awayMatches.length > 0 ? awayGoalsFor / awayMatches.length : 0;

  const recentForm = matchHistory.slice(0, 5).map(m => m.result);

  const winRate = (wins / matchHistory.length) * 100;
  const drawRate = (draws / matchHistory.length) * 100;
  const lossRate = (losses / matchHistory.length) * 100;

  const highScoringCount = matchHistory.filter(m => Math.max(m.goalsFor, m.goalsAgainst) >= 1).length;
  const firstHalfGoals = Math.round(highScoringCount * 0.45);
  const secondHalfGoals = Math.round(highScoringCount * 0.55);

  return {
    teamName: normalizedName,
    matchesAnalyzed: matchHistory.length,
    avgGoalsFor: parseFloat(avgGoalsFor.toFixed(2)),
    avgGoalsAgainst: parseFloat(avgGoalsAgainst.toFixed(2)),
    stability: parseFloat(stability.toFixed(3)),
    volatility: parseFloat(volatility.toFixed(3)),
    recentForm,
    homePerformance: parseFloat(homePerformance.toFixed(2)),
    awayPerformance: parseFloat(awayPerformance.toFixed(2)),
    firstHalfGoals,
    secondHalfGoals,
    winRate: parseFloat(winRate.toFixed(1)),
    drawRate: parseFloat(drawRate.toFixed(1)),
    lossRate: parseFloat(lossRate.toFixed(1)),
    matchHistory
  };
}

async function fetchFromEdgeFunction(teamName: string, force = false): Promise<EdgeFunctionResponse | null> {
  try {
    const params = new URLSearchParams({ team: teamName, limit: '50' });
    if (force) params.set('force', 'true');
    const fnUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/fetch-matches?${params.toString()}`;
    const res = await fetch(fnUrl, {
      headers: {
        Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
      },
    });

    if (!res.ok) {
      const body = await res.json().catch(() => null);
      console.warn('Edge function error:', body?.error || `HTTP ${res.status}`);
      return null;
    }

    const data = await res.json() as EdgeFunctionResponse;
    if (data.error) {
      console.warn('Edge function returned error:', data.error);
      return null;
    }

    if (data.warning) {
      console.warn('Edge function served stale cache with warning:', data.warning);
    }
    return data;
  } catch (err) {
    console.warn('Edge function unavailable, falling back to built-in dataset:', err);
    return null;
  }
}

export async function calculateTeamStats(
  teamName: string,
  _apiKey?: string,
  force: boolean = false
): Promise<TeamStats | null> {
  const normalizedName = normalizeTeamName(teamName);

  // Try the live edge function first
  const apiResult = await fetchFromEdgeFunction(normalizedName, force);

  // Only use API result if it returned enough matches for meaningful stats
  const MIN_MATCHES = 3;
  if (apiResult && apiResult.matches && apiResult.matches.length >= MIN_MATCHES) {
    try {
      const rawMatches: RawMatch[] = apiResult.matches.map(m => ({
        date: m.date,
        opponent: m.opponent,
        gf: m.gf,
        ga: m.ga,
        venue: m.venue,
      }));
      return computeStatsFromMatches(
        apiResult.team || normalizedName,
        rawMatches
      );
    } catch (err) {
      console.warn('Failed to compute stats from API data, falling back:', err);
    }
  }

  // Fall back to built-in verified dataset
  const dsMatches = datasetMatches(normalizedName);

  if (dsMatches.length === 0) {
    // If the API returned at least 1 match, use it as a last resort
    if (apiResult && apiResult.matches && apiResult.matches.length > 0) {
      try {
        const rawMatches: RawMatch[] = apiResult.matches.map(m => ({
          date: m.date,
          opponent: m.opponent,
          gf: m.gf,
          ga: m.ga,
          venue: m.venue,
        }));
        return computeStatsFromMatches(
          apiResult.team || normalizedName,
          rawMatches
        );
      } catch {
        // fall through
      }
    }
    console.warn(`No matches found for ${normalizedName}`);
    return null;
  }

  const mapped: RawMatch[] = dsMatches.map(match => {
    const isHome = match.homeTeam.toLowerCase() === normalizedName.toLowerCase();
    return {
      date: match.date,
      opponent: isHome ? match.awayTeam : match.homeTeam,
      gf: isHome ? match.homeGoals : match.awayGoals,
      ga: isHome ? match.awayGoals : match.homeGoals,
      venue: (isHome ? 'home' : 'away') as 'home' | 'away',
    };
  });

  return computeStatsFromMatches(normalizedName, mapped);
}

export function validateStatsIntegrity(stats: TeamStats): boolean {
  const checks = [
    stats.matchesAnalyzed > 0,
    stats.avgGoalsFor >= 0,
    stats.avgGoalsAgainst >= 0,
    stats.stability >= 0 && stats.stability <= 1,
    stats.volatility >= 0 && stats.volatility <= 1,
    stats.homePerformance >= 0,
    stats.awayPerformance >= 0,
    Math.abs(stats.winRate + stats.drawRate + stats.lossRate - 100) < 0.2,
    stats.matchHistory.length > 0
  ];

  return checks.every(check => check);
}
