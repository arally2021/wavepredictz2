import { supabase } from './supabase';
import type { MemoryEpisode, SemanticMemory, PatternAnalysisResult } from '../types/wavepredictz';

const N_PROMOTE = 5;
const PROMOTE_THRESHOLD = 0.6;
const DEMOTE_THRESHOLD = 0.3;

export async function storeEpisodicMemory(episode: Omit<MemoryEpisode, 'id' | 'created_at'>): Promise<string | null> {
  const { data, error } = await supabase
    .from('memory_episodes')
    .insert(episode)
    .select('id')
    .maybeSingle();

  if (error) {
    console.error('Error storing episodic memory:', error);
    return null;
  }

  await logEvent('episodic_memory_stored', { team_id: episode.team_id, type: episode.type });
  return data?.id || null;
}

export async function getEpisodicMemory(team_id: string, limit = 200): Promise<MemoryEpisode[]> {
  const { data, error } = await supabase
    .from('memory_episodes')
    .select('*')
    .eq('team_id', team_id)
    .order('created_at', { ascending: false })
    .limit(limit);

  if (error) {
    console.error('Error fetching episodic memory:', error);
    return [];
  }

  return data || [];
}

export async function getSemanticMemory(pattern_key?: string): Promise<SemanticMemory[]> {
  let query = supabase
    .from('memory_semantic')
    .select('*')
    .order('usefulness_score', { ascending: false });

  if (pattern_key) {
    query = query.eq('pattern_key', pattern_key);
  }

  const { data, error } = await query;

  if (error) {
    console.error('Error fetching semantic memory:', error);
    return [];
  }

  return data || [];
}

export async function evaluatePromotions(team_id: string): Promise<PatternAnalysisResult> {
  const episodes = await getEpisodicMemory(team_id);

  const counts: Record<string, { occurrences: number; avg_conf: number; samples: any[] }> = {};

  for (const episode of episodes) {
    const key = episode.content?.pattern_key || JSON.stringify(episode.content).slice(0, 80);

    if (!counts[key]) {
      counts[key] = { occurrences: 0, avg_conf: 0, samples: [] };
    }

    counts[key].occurrences += 1;
    counts[key].avg_conf += episode.confidence || 0;
    counts[key].samples.push(episode.content);
  }

  const promotions: PatternAnalysisResult['promotions'] = [];

  for (const key of Object.keys(counts)) {
    const avgConf = counts[key].avg_conf / counts[key].occurrences;
    const shouldPromote = counts[key].occurrences >= N_PROMOTE && avgConf >= PROMOTE_THRESHOLD;

    promotions.push({
      pattern_key: key,
      occurrences: counts[key].occurrences,
      avg_confidence: avgConf,
      promoted: shouldPromote
    });

    if (shouldPromote) {
      const existing = await supabase
        .from('memory_semantic')
        .select('id')
        .eq('pattern_key', key)
        .maybeSingle();

      if (!existing.data) {
        await supabase.from('memory_semantic').insert({
          pattern_key: key,
          pattern_doc: { samples: counts[key].samples },
          provenance: { source: 'auto-promotion', team: team_id },
          usefulness_score: avgConf,
          safety_review: false
        });

        await logEvent('promotion', { team_id, pattern_key: key, occurrences: counts[key].occurrences, avg_conf: avgConf });
      }
    }
  }

  const demotions = await evaluateDemotions();

  const suggestions = [
    `Analyzed ${episodes.length} episodes for ${team_id}`,
    `Found ${promotions.filter(p => p.promoted).length} patterns eligible for promotion`,
    `Processed ${demotions.length} demotion candidates`
  ];

  return {
    team_id,
    promotions,
    demotions,
    suggestions
  };
}

async function evaluateDemotions(): Promise<PatternAnalysisResult['demotions']> {
  const { data, error } = await supabase
    .from('memory_semantic')
    .select('*')
    .lt('usefulness_score', DEMOTE_THRESHOLD);

  if (error || !data) {
    return [];
  }

  const demotions: PatternAnalysisResult['demotions'] = [];

  for (const pattern of data) {
    await supabase
      .from('memory_semantic')
      .update({ safety_review: false })
      .eq('id', pattern.id);

    demotions.push({
      id: pattern.id,
      pattern_key: pattern.pattern_key,
      reason: `Usefulness score ${pattern.usefulness_score.toFixed(2)} below threshold ${DEMOTE_THRESHOLD}`
    });

    await logEvent('demotion', { id: pattern.id, pattern_key: pattern.pattern_key, score: pattern.usefulness_score });
  }

  return demotions;
}

export async function logEvent(event_type: string, details: Record<string, any>): Promise<void> {
  await supabase.from('event_log').insert({
    event_type,
    details
  });
}

export async function extractPatternsFromAnalysis(analysis: any, team_id: string): Promise<void> {
  const patterns: string[] = [];

  if (analysis.scoring_tendency_profile?.first_half_behavior) {
    patterns.push(analysis.scoring_tendency_profile.first_half_behavior);
  }

  if (analysis.scoring_tendency_profile?.burst_scoring_pattern) {
    patterns.push(analysis.scoring_tendency_profile.burst_scoring_pattern);
  }

  if (analysis.historical_trends) {
    patterns.push(...analysis.historical_trends);
  }

  for (const pattern of patterns) {
    await storeEpisodicMemory({
      team_id,
      type: 'pattern',
      content: { pattern_text: pattern, source: 'analysis' },
      confidence: analysis.consistency_matrix?.stability_index || 0.5
    });
  }
}
