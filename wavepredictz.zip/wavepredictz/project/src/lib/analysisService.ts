import { supabase } from './supabase';
import { extractPatternsFromAnalysis, evaluatePromotions, getEpisodicMemory, getSemanticMemory } from './memoryEngine';
import { calculateTeamStats, normalizeTeamName } from './footballDataService';
import type { AnalysisInput, WaveAnalysis, AnalysisRecord, HistoricalFacilityResponse, PatternAnalysisResult, MatchData } from '../types/wavepredictz';
import { computeWeightedStats } from './timeDecay';

const BANNED_KEYWORDS = ['bet', 'wager', 'odds', 'stake', 'fixed match', 'sure bet', 'gambling', 'bookmaker'];

export function detectsGamblingRequest(text: string): boolean {
  if (!text) return false;
  const lowercaseText = text.toLowerCase();
  return BANNED_KEYWORDS.some(keyword => lowercaseText.includes(keyword));
}

export function sanitizeInput(input: AnalysisInput): AnalysisInput {
  const sanitized = { ...input };

  if (sanitized.notes && detectsGamblingRequest(sanitized.notes)) {
    sanitized.notes = '[Content filtered for safety]';
  }

  if (sanitized.team && detectsGamblingRequest(sanitized.team)) {
    throw new Error('Request contains prohibited gambling-related content');
  }

  return sanitized;
}

export async function generateAnalysis(input: AnalysisInput): Promise<WaveAnalysis> {
  const sanitized = sanitizeInput(input);

  let matches = sanitized.recent_matches || [];

  // Auto-fetch match data if none was provided — prevents 0.00 placeholder output
  if (matches.length === 0) {
    console.log(`No matches provided for ${sanitized.team}, auto-fetching...`);
    const realMatches = await fetchRealMatchData(sanitized.team);
    if (realMatches.length > 0) {
      matches = realMatches;
    }
  }

  const ws = computeWeightedStats(matches);
  const hasData = matches.length > 0;

  const avgGoalsFor = ws.avgGoalsFor;
  const avgGoalsAgainst = ws.avgGoalsAgainst;
  const avgXg = ws.avgXg;
  const avgXga = ws.avgXga;
  const stabilityIndex = ws.stabilityIndex;
  const volatilityIndex = ws.volatilityIndex;
  const dualOffenseRate = ws.dualScoreRate;
  const formTrend = ws.formTrend;
  const recentPct = ws.totalWeight > 0 ? (ws.recentWeight / ws.totalWeight) * 100 : 0;

  const firstHalfGoals = matches.filter(m => m.pos && m.pos < 45).reduce((sum, m) => sum + m.gf, 0);
  const isLowFirstHalf = hasData && firstHalfGoals / matches.length < 0.5;

  const burstPattern = !hasData
    ? 'No data available - fetch match history to populate'
    : ws.burstRate > 0.25
    ? 'High - explosive multi-goal scoring phases detected, consistent with transition-heavy counter-pressing style'
    : ws.burstRate > 0.1
    ? 'Moderate - periodic burst-scoring phases within matches'
    : 'Low - limited burst scoring, gradual buildup reliance';

  // Dynamic output signature — driven by actual data, not generic labels
  const outputSignature = !hasData
    ? 'No data loaded - fetch match history to generate tactical profile'
    : avgGoalsFor >= 2 && avgGoalsAgainst < 1.2
    ? 'Elite Output Profile - high-volume attacking phases with disciplined defensive structure, sustained control in the final third'
    : avgGoalsFor >= 2 && avgGoalsAgainst >= 1.5
    ? 'High-Output Transition Profile - aggressive attacking output paired with a leaky defense, producing open volatile matches'
    : avgGoalsFor >= 1.5 && avgGoalsAgainst < 1
    ? 'Strong Output Profile - consistent goal-scoring capacity with organized defensive structure'
    : avgGoalsFor >= 1.5
    ? 'Balanced Output Profile - moderate attacking output with reasonable defensive coverage'
    : avgGoalsFor >= 1
    ? 'Conservative Output Pattern - measured offensive approach with emphasis on defensive structure'
    : 'Limited Output Signature - restricted creative output, reliance on set pieces or counter-attacks';

  const analysis: WaveAnalysis = {
    team_evaluated: sanitized.team,
    scoring_tendency_profile: {
      first_half_behavior: !hasData
        ? 'No data available - fetch match history to populate'
        : isLowFirstHalf
        ? 'Low First-Half Scoring Archetype - conservative buildup and compact defensive blocks in early phases'
        : 'Active First-Half Pattern - proactive attacking phases from the start',
      burst_scoring_pattern: burstPattern,
      dual_offense_activation: !hasData
        ? 'No data available'
        : dualOffenseRate > 0.6
        ? 'High - both teams regularly create scoring phases'
        : dualOffenseRate > 0.3
        ? 'Moderate - balanced offensive engagement'
        : 'Low - defensive dominance or one-sided matches',
      low_output_signature: outputSignature
    },
    consistency_matrix: {
      stability_index: stabilityIndex,
      volatility_index: volatilityIndex,
      inner_strength_rating: formTrend,
      required_value_metric: Math.max(0.3, stabilityIndex * 0.7 + formTrend * 0.3),
      instability_factors: !hasData
        ? ['No match data loaded']
        : volatilityIndex > 0.5
        ? ['High goal variance', 'Inconsistent performance levels', 'Form fluctuations']
        : ['Minor variance in output', 'Generally stable patterns']
    },
    statistical_overview: {
      avg_goals_for: avgGoalsFor,
      avg_goals_against: avgGoalsAgainst,
      avg_xg: avgXg,
      avg_xga: avgXga,
      clean_sheet_rate_last10: ws.cleanSheetRateLast10,
      xg_trends: !hasData
        ? 'No xG data - fetch match history'
        : avgXg > 1.8
        ? `High xG generation (${avgXg.toFixed(2)} per match)`
        : avgXg > 1.2
        ? `Moderate xG (${avgXg.toFixed(2)} per match)`
        : `Low xG output (${avgXg.toFixed(2)} per match)`,
      momentum_notes: !hasData
        ? 'No data - fetch match history'
        : formTrend > 0.6
        ? 'Positive momentum (recent-weighted)'
        : formTrend > 0.4
        ? 'Neutral momentum (recent-weighted)'
        : 'Negative momentum (recent-weighted)'
    },
    historical_trends: hasData ? [
      `Time-decay weighted average: ${avgGoalsFor.toFixed(2)} goals scored per match`,
      `Time-decay weighted average: ${avgGoalsAgainst.toFixed(2)} goals conceded per match`,
      `Weighted xG: ${avgXg.toFixed(2)} | xGA: ${avgXga.toFixed(2)} per match`,
      `Clean sheet rate (last 10): ${(ws.cleanSheetRateLast10 * 100).toFixed(0)}%`,
      `Recency signal: ${recentPct.toFixed(0)}% of statistical weight from last 60 days across ${ws.matchCount} matches`,
      stabilityIndex > 0.7 ? 'High consistency in current tactical era' : stabilityIndex > 0.5 ? 'Moderate consistency' : 'Variable performance patterns',
      isLowFirstHalf ? 'Cautious first-half approach observed' : 'Active early-phase engagement',
      dualOffenseRate > 0.5 ? 'Open matches with both-sided scoring' : 'Defensively structured matches'
    ] : [
      'No match data loaded - fetch match history to populate analysis',
      'Use the auto-fetch button or add matches manually to generate a tactical profile'
    ],
    safe_insight_summary: !hasData
      ? `${sanitized.team}: No match data was loaded. The analysis cannot generate a tactical profile without match history. Use the fetch button to load real data, or add matches manually.`
      : `${sanitized.team} demonstrates ${stabilityIndex > 0.6 ? 'consistent' : 'variable'} performance patterns with ${avgGoalsFor > 1.5 ? 'strong' : avgGoalsFor > 1 ? 'moderate' : 'limited'} offensive output across ${ws.matchCount} matches. Weighted xG of ${avgXg.toFixed(2)} vs xGA of ${avgXga.toFixed(2)} per match, with a ${(ws.cleanSheetRateLast10 * 100).toFixed(0)}% clean sheet rate over the last 10. ${recentPct.toFixed(0)}% of the statistical signal comes from the last 60 days, so the profile reflects the active tactical era. The team shows ${isLowFirstHalf ? 'conservative first-half tactics' : 'proactive early engagement'} and ${formTrend > 0.6 ? 'positive' : formTrend > 0.4 ? 'stable' : 'challenging'} recent form. This profile suggests ${volatilityIndex > 0.5 ? 'variable' : 'predictable'} match outcomes.`,
    interactive_steps: [
      'Review the consistency matrix to understand performance stability',
      'Examine scoring tendency profile for tactical patterns',
      'Analyze historical trends for recency-weighted behavior',
      'Compare statistical overview with league averages',
      'Monitor recent form trends for momentum shifts'
    ]
  };

  if (sanitized.league) {
    analysis.league_behavior_overview = getLeagueBehavior(sanitized.league);
  }

  return analysis;
}

function getLeagueBehavior(league: string): any {
  const leagueLower = league.toLowerCase();

  if (leagueLower.includes('italy') || leagueLower.includes('serie')) {
    return {
      italy: 'Tactical discipline, defensive compactness, low first-half scoring tendency',
      characteristic: 'Conservative buildup patterns dominate'
    };
  }

  if (leagueLower.includes('spain') || leagueLower.includes('laliga')) {
    return {
      spain: 'Possession-focused, technical play, controlled tempo, lower-table teams show limited output',
      characteristic: 'Methodical offensive construction'
    };
  }

  if (leagueLower.includes('england') || leagueLower.includes('premier')) {
    return {
      england: 'High tempo, transitional play, mixed patterns across tiers, strong teams show explosive phases',
      characteristic: 'Direct and vertical progression'
    };
  }

  if (leagueLower.includes('germany') || leagueLower.includes('bundes')) {
    return {
      germany: 'High-intensity pressing, burst-scoring profiles, vertical passing, strong offensive output',
      characteristic: 'Aggressive attacking football'
    };
  }

  return {
    general: 'Tactical patterns vary by league culture and competitive level'
  };
}

export async function saveAnalysis(input: AnalysisInput, output: WaveAnalysis, userId?: string): Promise<string | null> {
  const { data, error } = await supabase
    .from('analyses')
    .insert({
      user_id: userId || null,
      input,
      output
    })
    .select('id')
    .maybeSingle();

  if (error) {
    console.error('Error saving analysis:', error);
    return null;
  }

  await extractPatternsFromAnalysis(output, input.team);

  return data?.id || null;
}

export async function getHistoricalFacility(request: { team_id?: string; player_id?: string; date_range?: { start: string; end: string } }): Promise<HistoricalFacilityResponse> {
  let query = supabase
    .from('analyses')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(50);

  if (request.team_id) {
    query = query.or(`input->team.eq.${request.team_id},output->team_evaluated.eq.${request.team_id}`);
  }

  const { data: analyses, error } = await query;

  if (error) {
    console.error('Error fetching historical data:', error);
  }

  const episodes = request.team_id ? await getEpisodicMemory(request.team_id, 100) : [];
  const semanticPatterns = await getSemanticMemory();

  const analysisCount = analyses?.length || 0;
  const patternCount = semanticPatterns.length;
  const episodeCount = episodes.length;

  return {
    team_id: request.team_id,
    analyses: analyses || [],
    patterns: semanticPatterns,
    summary: `Retrieved ${analysisCount} historical analyses, ${episodeCount} episodic memories, and ${patternCount} identified patterns${request.team_id ? ` for ${request.team_id}` : ''}.`
  };
}

export async function analyzePatterns(team_id: string): Promise<PatternAnalysisResult> {
  return await evaluatePromotions(team_id);
}

/**
 * Fetch real match data from football-data.org and convert to MatchData format
 */
export async function fetchRealMatchData(teamName: string): Promise<MatchData[]> {
  try {
    const normalizedTeam = normalizeTeamName(teamName);
    console.log(`Fetching real match data for ${normalizedTeam}...`);

    const stats = await calculateTeamStats(normalizedTeam);

    if (!stats || !stats.matchHistory || stats.matchHistory.length === 0) {
      console.warn('No match history returned');
      return [];
    }

    const matchData: MatchData[] = stats.matchHistory.map(match => ({
      date: match.date,
      opponent: match.opponent,
      gf: match.goalsFor,
      ga: match.goalsAgainst,
      venue: match.venue,
    }));

    console.log(`Fetched ${matchData.length} real matches for ${normalizedTeam}`);
    return matchData;
  } catch (error) {
    console.error('Error fetching real match data:', error);
    return [];
  }
}

/**
 * Enhanced analysis that can optionally fetch real data from football-data.org
 */
export async function generateAnalysisWithRealData(
  input: AnalysisInput,
  useRealData: boolean = true
): Promise<WaveAnalysis> {
  let enrichedInput = { ...input };

  // If no matches provided and useRealData is true, fetch from API
  if (useRealData && (!input.recent_matches || input.recent_matches.length === 0)) {
    const realMatches = await fetchRealMatchData(input.team);
    if (realMatches.length > 0) {
      enrichedInput.recent_matches = realMatches;
      console.log(`📊 Using ${realMatches.length} real matches for analysis`);
    }
  }

  return generateAnalysis(enrichedInput);
}

// ---------------------------------------------------------------------------
// Forced Fresh Fetch Pipeline
// ---------------------------------------------------------------------------

export interface TacticalPattern {
  patternKey: string;
  title: string;
  description: string;
  category: 'scoring' | 'defensive' | 'tempo' | 'venue' | 'form';
  confidence: number;
  evidence: string[];
}

export interface ForcedFetchResult {
  team: string;
  matchesFetched: number;
  source: string;
  analysis: WaveAnalysis;
  tacticalPatterns: TacticalPattern[];
  baselineStored: boolean;
  patternsStored: number;
  summary: string;
}

interface ForcedMatch {
  date: string;
  opponent: string;
  gf: number;
  ga: number;
  venue: 'home' | 'away';
  result: 'W' | 'D' | 'L';
}

/**
 * Extract tactical semantic patterns from raw match data.
 * Always returns at least 3 patterns based on measurable signals.
 */
function extractTacticalPatterns(team: string, matches: ForcedMatch[]): TacticalPattern[] {
  const patterns: TacticalPattern[] = [];

  const matchData: MatchData[] = matches.map(m => ({
    date: m.date, opponent: m.opponent, gf: m.gf, ga: m.ga, venue: m.venue,
  }));
  const ws = computeWeightedStats(matchData);

  const avgGF = ws.avgGoalsFor;
  const avgGA = ws.avgGoalsAgainst;
  const winRate = ws.winRate * 100;
  const homeAvg = ws.homeAvg;
  const awayAvg = ws.awayAvg;
  const cleanSheetRate = ws.cleanSheetRate * 100;
  const bttsRate = ws.bttsRate * 100;
  const highScoringRate = ws.highScoringRate * 100;
  const burstMatches = matches.filter(m => m.gf >= 3).length;
  const goalVariance = ws.weightedVariance;
  const recentPct = ws.totalWeight > 0 ? (ws.recentWeight / ws.totalWeight) * 100 : 0;
  const wins = matches.filter(m => m.result === 'W').length;
  const draws = matches.filter(m => m.result === 'D').length;
  const losses = matches.filter(m => m.result === 'L').length;
  const highScoring = matches.filter(m => m.gf + m.ga >= 3).length;
  const totalGF = matches.reduce((s, m) => s + m.gf, 0);
  const totalGA = matches.reduce((s, m) => s + m.ga, 0);

  // Pattern 1: Scoring output profile
  const scoringCategory = avgGF >= 2 ? 'high-output' : avgGF >= 1.3 ? 'moderate-output' : 'low-output';
  patterns.push({
    patternKey: `${team.toLowerCase().replace(/\s+/g, '_')}_scoring_${scoringCategory}`,
    title: `${scoringCategory === 'high-output' ? 'High' : scoringCategory === 'moderate-output' ? 'Moderate' : 'Low'} Scoring Output Profile`,
    description:
      scoringCategory === 'high-output'
        ? `${team} generates ${avgGF.toFixed(2)} goals per match, placing them in the high-output tier. This suggests an aggressive attacking setup with frequent ball progression into the final third.`
        : scoringCategory === 'moderate-output'
        ? `${team} averages ${avgGF.toFixed(2)} goals per match, indicating a balanced offensive approach that mixes buildup control with direct attacking phases.`
        : `${team} averages only ${avgGF.toFixed(2)} goals per match, indicating limited attacking output and a reliance on defensive structure or set pieces.`,
    category: 'scoring',
    confidence: Math.min(0.95, 0.5 + Math.abs(avgGF - 1.3) / 2),
    evidence: [
      `Time-decay weighted average: ${avgGF.toFixed(2)} goals scored across ${matches.length} matches`,
      `Recency signal: ${recentPct.toFixed(0)}% of weight from last 60 days`,
      `Burst scoring (3+ goals in a match): ${burstMatches} occurrences`,
      `Failed to score in ${matches.filter(m => m.gf === 0).length} matches`,
    ],
  });

  // Pattern 2: Defensive solidity
  const defCategory = avgGA < 0.8 ? 'solid' : avgGA < 1.3 ? 'moderate' : 'leaky';
  patterns.push({
    patternKey: `${team.toLowerCase().replace(/\s+/g, '_')}_defensive_${defCategory}`,
    title: `${defCategory === 'solid' ? 'Solid' : defCategory === 'moderate' ? 'Moderate' : 'Leaky'} Defensive Structure`,
    description:
      defCategory === 'solid'
        ? `${team} concedes only ${avgGA.toFixed(2)} goals per match with a ${cleanSheetRate.toFixed(0)}% clean sheet rate, indicating a well-organized defensive block and effective pressing recovery.`
        : defCategory === 'moderate'
        ? `${team} concedes ${avgGA.toFixed(2)} goals per match with a ${cleanSheetRate.toFixed(0)}% clean sheet rate, showing a moderate defensive structure that can be exposed by high-tempo opponents.`
        : `${team} concedes ${avgGA.toFixed(2)} goals per match with only a ${cleanSheetRate.toFixed(0)}% clean sheet rate, indicating defensive vulnerabilities and potential issues with transition coverage.`,
    category: 'defensive',
    confidence: Math.min(0.95, 0.5 + Math.abs(avgGA - 1.0) / 1.5),
    evidence: [
      `Time-decay weighted average: ${avgGA.toFixed(2)} goals conceded per match`,
      `Clean sheet rate (weighted): ${cleanSheetRate.toFixed(0)}%`,
      `Both teams scored (weighted): ${bttsRate.toFixed(0)}% of matches`,
    ],
  });

  // Pattern 3: Home vs Away performance split
  const homeAdvantage = homeAvg - awayAvg;
  const venueCategory = homeAdvantage > 0.5 ? 'home-dominant' : homeAdvantage > 0 ? 'home-favored' : homeAdvantage > -0.5 ? 'balanced' : 'away-strong';
  patterns.push({
    patternKey: `${team.toLowerCase().replace(/\s+/g, '_')}_venue_${venueCategory}`,
    title: `${venueCategory === 'home-dominant' ? 'Home-Dominant' : venueCategory === 'home-favored' ? 'Home-Favored' : venueCategory === 'balanced' ? 'Balanced Venue' : 'Away-Strong'} Performance Profile`,
    description:
      venueCategory === 'home-dominant'
        ? `${team} shows a significant home advantage, scoring ${homeAvg.toFixed(2)} goals at home vs ${awayAvg.toFixed(2)} away. This suggests the team leverages home support and familiar conditions for more aggressive attacking play.`
        : venueCategory === 'home-favored'
        ? `${team} performs slightly better at home (${homeAvg.toFixed(2)} vs ${awayAvg.toFixed(2)} away), showing a mild home advantage typical of most league teams.`
        : venueCategory === 'balanced'
        ? `${team} shows balanced performance across venues (${homeAvg.toFixed(2)} home vs ${awayAvg.toFixed(2)} away), indicating tactical consistency regardless of location.`
        : `${team} actually performs better away from home (${awayAvg.toFixed(2)} vs ${homeAvg.toFixed(2)} at home), suggesting a counter-attacking style suited to away matches.`,
    category: 'venue',
    confidence: Math.min(0.9, 0.5 + Math.abs(homeAdvantage) / 2),
    evidence: [
      `Home scoring average: ${homeAvg.toFixed(2)} goals per match`,
      `Away scoring average: ${awayAvg.toFixed(2)} goals per match`,
      `Home/Away scoring differential: ${homeAdvantage > 0 ? '+' : ''}${homeAdvantage.toFixed(2)}`,
    ],
  });

  // Pattern 4: Match tempo / openness (if data supports it)
  if (highScoringRate > 40 || highScoringRate < 20) {
    patterns.push({
      patternKey: `${team.toLowerCase().replace(/\s+/g, '_')}_tempo_${highScoringRate > 40 ? 'open' : 'compact'}`,
      title: `${highScoringRate > 40 ? 'Open Match' : 'Compact Match'} Tempo Profile`,
      description:
        highScoringRate > 40
          ? `${team} is involved in high-scoring matches (${highScoringRate.toFixed(0)}% of games have 3+ total goals), indicating an open, transitional style that produces end-to-end football.`
          : `${team} plays in low-scoring, compact matches (only ${highScoringRate.toFixed(0)}% of games have 3+ total goals), suggesting a structured, possession-based or defensive approach.`,
      category: 'tempo',
      confidence: Math.min(0.9, 0.5 + Math.abs(highScoringRate - 30) / 50),
      evidence: [
        `Matches with 3+ total goals: ${highScoring} out of ${matches.length} (${highScoringRate.toFixed(0)}%)`,
        `Both teams scored rate (weighted): ${bttsRate.toFixed(0)}%`,
        `Weighted average total goals per match: ${(avgGF + avgGA).toFixed(2)}`,
      ],
    });
  }

  // Pattern 5: Form / consistency trend (if variance is notable)
  if (goalVariance > 1.0 || goalVariance < 0.3) {
    patterns.push({
      patternKey: `${team.toLowerCase().replace(/\s+/g, '_')}_form_${goalVariance > 1.0 ? 'volatile' : 'consistent'}`,
      title: `${goalVariance > 1.0 ? 'Volatile' : 'Consistent'} Performance Pattern`,
      description:
        goalVariance > 1.0
          ? `${team} shows high goal-scoring variance (${goalVariance.toFixed(2)}), indicating boom-or-bust performance cycles. The team can produce explosive scoring bursts but also goes through dry spells.`
          : `${team} shows remarkably consistent scoring output (variance: ${goalVariance.toFixed(2)}), indicating a stable tactical system that produces predictable goal-scoring patterns match over match.`,
      category: 'form',
      confidence: Math.min(0.9, 0.5 + Math.abs(goalVariance - 0.5) / 1.5),
      evidence: [
        `Weighted goal scoring variance: ${goalVariance.toFixed(3)}`,
        `Win rate: ${winRate.toFixed(1)}% (${wins}W ${draws}D ${losses}L)`,
        `Matches with 0 goals scored: ${matches.filter(m => m.gf === 0).length}`,
      ],
    });
  }

  return patterns;
}

/**
 * Store tactical patterns as semantic memory entries under the "All Teams" baseline.
 * Does NOT read from episodic memory — initializes a fresh data store.
 */
async function storePatternsAsBaseline(
  team: string,
  patterns: TacticalPattern[]
): Promise<number> {
  let stored = 0;

  for (const pattern of patterns) {
    // Check if this pattern already exists to avoid duplicates
    const { data: existing } = await supabase
      .from('memory_semantic')
      .select('id')
      .eq('pattern_key', pattern.patternKey)
      .maybeSingle();

    if (existing) {
      // Update existing pattern with fresh evidence
      await supabase
        .from('memory_semantic')
        .update({
          pattern_doc: {
            title: pattern.title,
            description: pattern.description,
            category: pattern.category,
            evidence: pattern.evidence,
            team,
          },
          provenance: { source: 'forced-fresh-fetch', team, timestamp: new Date().toISOString() },
          usefulness_score: pattern.confidence,
          safety_review: true,
        })
        .eq('id', existing.id);
    } else {
      await supabase.from('memory_semantic').insert({
        pattern_key: pattern.patternKey,
        pattern_doc: {
          title: pattern.title,
          description: pattern.description,
          category: pattern.category,
          evidence: pattern.evidence,
          team,
        },
        provenance: { source: 'forced-fresh-fetch', team, timestamp: new Date().toISOString() },
        usefulness_score: pattern.confidence,
        safety_review: true,
      });
    }

    stored++;
  }

  // Store a baseline summary entry under "All Teams"
  const baselineKey = 'all_teams_historical_baseline';
  const { data: baselineExisting } = await supabase
    .from('memory_semantic')
    .select('id')
    .eq('pattern_key', baselineKey)
    .maybeSingle();

  const baselineDoc = {
    title: 'All Teams Historical Baseline',
    description: `Baseline initialized from forced fresh fetch of ${team} on ${new Date().toISOString()}. Contains ${patterns.length} tactical patterns extracted from live API data.`,
    teamsCovered: [team],
    patternCount: patterns.length,
    initializedAt: new Date().toISOString(),
  };

  if (baselineExisting) {
    await supabase
      .from('memory_semantic')
      .update({
        pattern_doc: baselineDoc,
        usefulness_score: 1.0,
        safety_review: true,
      })
      .eq('id', baselineExisting.id);
  } else {
    await supabase.from('memory_semantic').insert({
      pattern_key: baselineKey,
      pattern_doc: baselineDoc,
      provenance: { source: 'forced-fresh-fetch-baseline' },
      usefulness_score: 1.0,
      safety_review: true,
    });
  }

  return stored;
}

/**
 * Force a fresh server-side fetch bypassing all caches, process the raw fixture
 * history, extract tactical semantic patterns, and build a new historical baseline.
 *
 * @param teamName   Team to fetch (e.g., "Arsenal")
 * @param matchLimit  Number of recent matches to retrieve (default 50)
 */
export async function forcedFreshFetch(
  teamName: string,
  matchLimit: number = 50
): Promise<ForcedFetchResult> {
  const normalizedTeam = normalizeTeamName(teamName);

  // Step 1: Force a fresh fetch from the edge function (bypass cache)
  const stats = await calculateTeamStats(normalizedTeam, undefined, true);

  if (!stats || !stats.matchHistory || stats.matchHistory.length === 0) {
    throw new Error(`No match data could be fetched for ${normalizedTeam}. The team may not be supported or the API may be rate-limited.`);
  }

  // Step 2: Convert to ForcedMatch format for pattern extraction
  const matches: ForcedMatch[] = stats.matchHistory.slice(0, matchLimit).map(m => ({
    date: m.date,
    opponent: m.opponent,
    gf: m.goalsFor,
    ga: m.goalsAgainst,
    venue: m.venue,
    result: m.result,
  }));

  // Step 3: Generate analysis from the fresh data
  const analysisInput: AnalysisInput = {
    team: normalizedTeam,
    recent_matches: matches.map(m => ({
      date: m.date,
      opponent: m.opponent,
      gf: m.gf,
      ga: m.ga,
      venue: m.venue,
    })),
  };
  const analysis = await generateAnalysis(analysisInput);

  // Step 4: Extract tactical semantic patterns (at least 3)
  const tacticalPatterns = extractTacticalPatterns(normalizedTeam, matches);

  // Step 5: Store patterns as a new "All Teams" historical baseline
  const patternsStored = await storePatternsAsBaseline(normalizedTeam, tacticalPatterns);

  // Step 6: Also save the analysis record
  await saveAnalysis(analysisInput, analysis);

  return {
    team: normalizedTeam,
    matchesFetched: matches.length,
    source: 'forced-fresh-fetch',
    analysis,
    tacticalPatterns,
    baselineStored: patternsStored > 0,
    patternsStored,
    summary: `Forced fresh fetch retrieved ${matches.length} matches for ${normalizedTeam}. Extracted ${tacticalPatterns.length} tactical patterns and stored ${patternsStored} as the new "All Teams" historical baseline.`,
  };
}
