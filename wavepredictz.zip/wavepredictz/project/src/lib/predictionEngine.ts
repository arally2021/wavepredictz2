import type { WeightedStats } from './timeDecay';
import type { MatchPrediction, MatchPredictionSet, TriggerType, SecondaryMarket } from '../types/prediction';

export interface TeamProfile {
  name: string;
  stats: WeightedStats;
  isHome: boolean;
}

interface MatchContext {
  home: TeamProfile;
  away: TeamProfile;
  league?: string;
  matchDate?: string;
}

const CLAMP = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));

function bttsProbability(home: TeamProfile, away: TeamProfile): number {
  const hScores = home.stats.avgGoalsFor > 0 ? CLAMP(0.35 + home.stats.avgGoalsFor * 0.18, 0, 0.95) : 0.2;
  const aScores = away.stats.avgGoalsFor > 0 ? CLAMP(0.35 + away.stats.avgGoalsFor * 0.18, 0, 0.95) : 0.2;
  return CLAMP(hScores * aScores, 0, 0.98);
}

function overTotalGoalsProb(home: TeamProfile, away: TeamProfile, line: number): number {
  const expTotal = home.stats.avgGoalsFor + away.stats.avgGoalsFor
    + (home.stats.avgGoalsAgainst + away.stats.avgGoalsAgainst) * 0.4;
  const highScoring = (home.stats.highScoringRate + away.stats.highScoringRate) / 2;
  const base = CLAMP(0.45 + (expTotal - line) * 0.22 + (highScoring - 0.3) * 0.2, 0.05, 0.97);
  return base;
}

function underTotalGoalsProb(home: TeamProfile, away: TeamProfile, line: number): number {
  return CLAMP(1 - overTotalGoalsProb(home, away, line), 0.03, 0.97);
}

function drawProbability(home: TeamProfile, away: TeamProfile): number {
  const drawRate = (home.stats.drawRate + away.stats.drawRate) / 2;
  const lowScoring = (home.stats.avgGoalsFor + away.stats.avgGoalsFor) < 2.2;
  const lowVol = (home.stats.volatilityIndex + away.stats.volatilityIndex) / 2 < 0.4;
  return CLAMP(drawRate * (lowScoring ? 1.25 : 1) * (lowVol ? 1.1 : 1), 0.1, 0.55);
}

function winProbability(team: TeamProfile, opp: TeamProfile): number {
  const diff = (team.stats.avgGoalsFor - team.stats.avgGoalsAgainst)
    - (opp.stats.avgGoalsFor - opp.stats.avgGoalsAgainst);
  const formDiff = team.stats.formTrend - opp.stats.formTrend;
  const venueBoost = team.isHome ? 0.08 : 0;
  return CLAMP(0.4 + diff * 0.12 + formDiff * 0.15 + venueBoost, 0.1, 0.85);
}

function hasTwoGoalsInARow(team: TeamProfile): boolean {
  return team.stats.avgGoalsFor >= 1.3 && team.stats.burstRate >= 0.12;
}

function isDefensiveStructure(team: TeamProfile): boolean {
  return team.stats.avgGoalsFor < 1.1 && team.stats.avgGoalsAgainst < 1.0;
}

function isOpenTacticalSetup(home: TeamProfile, away: TeamProfile): boolean {
  const combinedBtts = bttsProbability(home, away);
  const combinedXg = home.stats.avgXg + away.stats.avgXg;
  return combinedBtts > 0.45 && combinedXg > 2.2;
}

function isExplosiveMatch(home: TeamProfile, away: TeamProfile): boolean {
  const over05 = overTotalGoalsProb(home, away, 0.5);
  const burstAvg = (home.stats.burstRate + away.stats.burstRate) / 2;
  return over05 > 0.85 && burstAvg > 0.15;
}

function isRigidDefensive(home: TeamProfile, away: TeamProfile): boolean {
  return isDefensiveStructure(home) && isDefensiveStructure(away);
}

interface SecondaryMarketsInput {
  home: TeamProfile;
  away: TeamProfile;
}

function computeSecondaryMarkets(ctx: SecondaryMarketsInput): SecondaryMarket[] {
  const { home, away } = ctx;
  const markets: SecondaryMarket[] = [];

  const over25Pct = Math.round(overTotalGoalsProb(home, away, 2.5) * 100);
  const under25Pct = Math.round(underTotalGoalsProb(home, away, 2.5) * 100);
  const under55Pct = Math.round(underTotalGoalsProb(home, away, 5.5) * 100);
  const over05Pct = Math.round(overTotalGoalsProb(home, away, 0.5) * 100);
  const bttsPct = Math.round(bttsProbability(home, away) * 100);
  const homeWinPct = Math.round(winProbability(home, away) * 100);
  const awayWinPct = Math.round(winProbability(away, home) * 100);

  // Under 1.5 1st Half — derived from low first-half scoring tendency + low overall volume
  const expFirstHalf = (home.stats.avgGoalsFor + away.stats.avgGoalsFor) * 0.35;
  const under15FirstHalfPct = Math.round(CLAMP(0.55 + (1.5 - expFirstHalf) * 0.18, 0.2, 0.92) * 100);

  markets.push({ label: 'Over 2.5 Goals', pick: 'Over 2.5', confidence: over25Pct });
  markets.push({ label: 'Under 2.5 Goals', pick: 'Under 2.5', confidence: under25Pct });
  markets.push({ label: 'Under 5.5 Goals (Safety)', pick: 'Under 5.5', confidence: under55Pct });
  markets.push({ label: 'Over 0.5 Goals (1st Half Safety)', pick: 'Over 0.5 1H', confidence: over05Pct });
  markets.push({ label: 'Under 1.5 Goals (1st Half)', pick: 'Under 1.5 1H', confidence: under15FirstHalfPct });
  markets.push({ label: 'Both Teams to Score', pick: 'GG / BTTS — Yes', confidence: bttsPct });
  markets.push({ label: 'Home or Away (Double Chance 12)', pick: 'Home or Away (12)', confidence: Math.max(homeWinPct, awayWinPct) });

  return markets;
}

export function generateMatchPredictions(ctx: MatchContext): MatchPredictionSet {
  const { home, away } = ctx;
  const predictions: MatchPrediction[] = [];
  const secondaryMarkets = computeSecondaryMarkets({ home, away });

  // 1. 2 Goals in a Row Shift — Home or GG Alignment
  if (hasTwoGoalsInARow(home) && (winProbability(home, away) > 0.5 || bttsProbability(home, away) > 0.5)) {
    const winPct = Math.round(winProbability(home, away) * 100);
    const bttsPct = Math.round(bttsProbability(home, away) * 100);
    predictions.push({
      trigger: 'home_or_gg_alignment',
      triggerLabel: '2 Goals in a Row Shift — Home or GG Alignment',
      primaryPick: `Double Chance (1X — Home or Draw)`,
      safetyPick: 'Both Teams to Score (Yes / GG)',
      confidence: Math.max(winPct, bttsPct),
      strategy: `Home momentum detected with ${home.stats.avgGoalsFor.toFixed(2)} avg goals and ${(home.stats.burstRate * 100).toFixed(0)}% burst rate. Double chance covers a home win or draw; GG pivot covers a high-scoring exchange even if the favored side fails to win.`,
      secondaryMarkets,
    });
  }

  // 2. 2 Goals in a Row Shift — Away or GG Alignment
  if (hasTwoGoalsInARow(away) && (winProbability(away, home) > 0.45 || bttsProbability(home, away) > 0.5)) {
    const winPct = Math.round(winProbability(away, home) * 100);
    const bttsPct = Math.round(bttsProbability(home, away) * 100);
    predictions.push({
      trigger: 'away_or_gg_alignment',
      triggerLabel: '2 Goals in a Row Shift — Away or GG Alignment',
      primaryPick: `Double Chance (X2 — Away or Draw)`,
      safetyPick: 'Both Teams to Score (Yes / GG)',
      confidence: Math.max(winPct, bttsPct),
      strategy: `Away momentum detected with ${away.stats.avgGoalsFor.toFixed(2)} avg goals and ${(away.stats.burstRate * 100).toFixed(0)}% burst rate. Double chance covers an away win or draw; GG pivot covers a high-scoring exchange even if the away side fails to win.`,
      secondaryMarkets,
    });
  }

  // 3. GG Activated → Over 1.5 Match Volume
  if (isOpenTacticalSetup(home, away)) {
    const over15Pct = Math.round(overTotalGoalsProb(home, away, 1.5) * 100);
    const bttsPct = Math.round(bttsProbability(home, away) * 100);
    predictions.push({
      trigger: 'gg_activated_over_1_5',
      triggerLabel: 'GG Activated → Over 1.5 Match Volume',
      primaryPick: 'Over 1.5 Goals',
      safetyPick: bttsPct > 55 ? 'Both Teams to Score (Yes)' : 'Over 0.5 Goals (Safety)',
      confidence: Math.max(over15Pct, bttsPct),
      strategy: `Wide-open tactical setups detected. Combined xG of ${(home.stats.avgXg + away.stats.avgXg).toFixed(2)} and ${(bttsPct)}% BTTS probability. Over 1.5 is ideal for low-risk accumulators. ${bttsPct > 55 ? 'BTTS confidence above 55% — back both teams to score as premium pick.' : ''}`,
      secondaryMarkets,
    });
  }

  // 4. Draw or Under 2.5 Buffer / No 3 Goals Guard
  if (isRigidDefensive(home, away) || underTotalGoalsProb(home, away, 2.5) > 0.55) {
    const under25Pct = Math.round(underTotalGoalsProb(home, away, 2.5) * 100);
    const drawPct = Math.round(drawProbability(home, away) * 100);
    const isAbsolute = isRigidDefensive(home, away);
    predictions.push({
      trigger: 'draw_or_under_2_5_buffer',
      triggerLabel: isAbsolute
        ? 'Draw or Under 2.5 Buffer (Absolute) — No 3 Goals Guard'
        : 'Draw or Under 2.5 Buffer',
      primaryPick: 'Under 2.5 Goals',
      safetyPick: isAbsolute ? 'Draw (X)' : 'Under 3.5 Goals',
      confidence: Math.max(under25Pct, drawPct),
      strategy: isAbsolute
        ? `Both teams exhibit rigid defensive structures (${home.stats.avgGoalsFor.toFixed(2)} and ${away.stats.avgGoalsFor.toFixed(2)} avg goals). High probability of 0-0 or 1-1. Under 2.5 is the primary; straight Draw is the value pick when tagged Absolute.`
        : `Low attacking volume detected. Under 2.5 is primary with Under 3.5 as a safer baseline. Draw is the value alternative if defensive rigidity holds.`,
      secondaryMarkets,
    });
  }

  // 5. Under 3.5 Baseline Lock
  if (underTotalGoalsProb(home, away, 3.5) > 0.70 && !isOpenTacticalSetup(home, away)) {
    const under35Pct = Math.round(underTotalGoalsProb(home, away, 3.5) * 100);
    predictions.push({
      trigger: 'under_3_5_baseline_lock',
      triggerLabel: 'Under 3.5 Baseline Lock',
      primaryPick: 'Under 3.5 Goals',
      safetyPick: 'Under 2.5 Goals',
      confidence: under35Pct,
      strategy: `Combined expected total of ${(home.stats.avgXg + away.stats.avgXg).toFixed(2)} xG and ${(home.stats.highScoringRate * 100).toFixed(0)}/${(away.stats.highScoringRate * 100).toFixed(0)}% high-scoring rate. Under 3.5 maximizes safety; Under 2.5 offers higher value if both defenses hold.`,
      secondaryMarkets,
    });
  }

  // 6. Over 0.5 Node → 2 Goals in a Row Acceleration
  if (isExplosiveMatch(home, away)) {
    const over05Pct = Math.round(overTotalGoalsProb(home, away, 0.5) * 100);
    const over15Pct = Math.round(overTotalGoalsProb(home, away, 1.5) * 100);
    predictions.push({
      trigger: 'over_0_5_acceleration',
      triggerLabel: 'Over 0.5 Node → 2 Goals in a Row Acceleration',
      primaryPick: 'Over 1.5 Goals',
      safetyPick: 'Over 0.5 Goals (First Half Safety)',
      confidence: Math.max(over15Pct, over05Pct),
      strategy: `Explosive trigger — ${over05Pct}% chance of at least one goal and combined burst rate of ${(((home.stats.burstRate + away.stats.burstRate) / 2) * 100).toFixed(0)}%. Pre-match: Over 1.5. Live: if 0-0 after 15-20 minutes, place in-play Over 0.5 First Half or Over 1.5 Match at elevated odds.`,
      liveStrategy: 'Wait 15-20 min. If 0-0, bet Over 0.5 First Half Goals or Over 1.5 Match Goals in-play for higher odds.',
      secondaryMarkets,
    });
  }

  // Fallback: if no triggers fired, produce a conservative default
  if (predictions.length === 0) {
    const over15Pct = Math.round(overTotalGoalsProb(home, away, 1.5) * 100);
    const bttsPct = Math.round(bttsProbability(home, away) * 100);
    predictions.push({
      trigger: 'gg_activated_over_1_5',
      triggerLabel: 'GG Activated → Over 1.5 Match Volume (Default)',
      primaryPick: 'Over 1.5 Goals',
      safetyPick: 'Over 0.5 Goals (Safety)',
      confidence: Math.max(over15Pct, bttsPct),
      strategy: `No strong tactical trigger detected. Falling back to Over 1.5 as a moderate-confidence pick based on combined xG of ${(home.stats.avgXg + away.stats.avgXg).toFixed(2)}.`,
      secondaryMarkets,
    });
  }

  predictions.sort((a, b) => b.confidence - a.confidence);
  const bestPick = predictions[0];

  const triggerList = predictions.map(p => p.triggerLabel).join('; ');
  const summary = `${home.name} vs ${away.name}: ${predictions.length} trigger${predictions.length > 1 ? 's' : ''} detected — ${triggerList}. Best pick: ${bestPick.primaryPick} at ${bestPick.confidence}% confidence.`;

  return {
    homeTeam: home.name,
    awayTeam: away.name,
    league: ctx.league,
    matchDate: ctx.matchDate,
    predictions,
    bestPick,
    summary,
  };
}

export { bttsProbability, overTotalGoalsProb, underTotalGoalsProb, drawProbability, winProbability };
