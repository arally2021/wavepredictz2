export type TriggerType =
  | 'home_or_gg_alignment'
  | 'away_or_gg_alignment'
  | 'gg_activated_over_1_5'
  | 'draw_or_under_2_5_buffer'
  | 'under_3_5_baseline_lock'
  | 'over_0_5_acceleration';

export interface SecondaryMarket {
  label: string;
  pick: string;
  confidence: number;
}

export interface MatchPrediction {
  trigger: TriggerType;
  triggerLabel: string;
  primaryPick: string;
  safetyPick: string;
  confidence: number;
  strategy: string;
  liveStrategy?: string;
  secondaryMarkets: SecondaryMarket[];
}

export interface MatchPredictionSet {
  homeTeam: string;
  awayTeam: string;
  league?: string;
  matchDate?: string;
  predictions: MatchPrediction[];
  bestPick: MatchPrediction;
  summary: string;
}
