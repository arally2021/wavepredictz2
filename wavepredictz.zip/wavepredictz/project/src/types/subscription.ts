export type SubscriptionTier = 'free' | 'casual' | 'pro' | 'b2b' | 'elite';

export type BillingCycle = 'monthly' | 'annual';

export interface PricingTier {
  id: SubscriptionTier;
  name: string;
  tagline: string;
  monthlyPrice: number;
  annualPrice: number;
  features: string[];
  ctaLabel: string;
  ctaStyle: 'primary' | 'neon' | 'outline' | 'contact';
  popular?: boolean;
  badge?: string;
}

export interface CheckoutRequest {
  priceId: string;
  tier: SubscriptionTier;
  cycle: BillingCycle;
}

export interface CheckoutResponse {
  url: string;
  sessionId: string;
}

export interface SubscriptionState {
  tier: SubscriptionTier;
  isAuthenticated: boolean;
  isLoading: boolean;
  userId: string | null;
  email: string | null;
}
