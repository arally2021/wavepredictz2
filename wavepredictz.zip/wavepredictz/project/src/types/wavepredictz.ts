export interface ScoringTendencyProfile {
  first_half_behavior: string;
  burst_scoring_pattern: string;
  dual_offense_activation: string;
  low_output_signature: string;
}

export interface ConsistencyMatrix {
  stability_index: number;
  volatility_index: number;
  inner_strength_rating: number;
  required_value_metric: number;
  instability_factors?: string[];
}

export interface LeagueBehaviorOverview {
  italy?: string;
  spain?: string;
  england?: string;
  germany?: string;
  france?: string;
}

export interface StatisticalConfirmation {
  recent_trends: string[];
  variance_analysis: string;
  phase_clusters: string[];
  reliability_score: string;
}

export interface StatisticalOverview {
  avg_goals_for?: number;
  avg_goals_against?: number;
  avg_xg?: number;
  avg_xga?: number;
  clean_sheet_rate_last10?: number;
  xg_trends?: string;
  momentum_notes?: string;
  [key: string]: any;
}

export interface WaveAnalysis {
  team_evaluated: string;
  scoring_tendency_profile: ScoringTendencyProfile;
  consistency_matrix: ConsistencyMatrix;
  league_behavior_overview?: LeagueBehaviorOverview;
  statistical_confirmation?: StatisticalConfirmation;
  statistical_overview?: StatisticalOverview;
  historical_alignment?: string;
  historical_trends: string[];
  safe_insight_summary: string;
  interactive_steps: string[];
}

export interface MatchData {
  date: string;
  opponent?: string;
  gf: number;
  ga: number;
  pos?: number;
  venue?: 'home' | 'away';
  xg?: number;
  xga?: number;
}

export interface AnalysisInput {
  team: string;
  league?: string;
  recent_matches?: MatchData[];
  notes?: string;
  player_id?: string;
  date_range?: {
    start: string;
    end: string;
  };
}

export interface MemoryEpisode {
  id?: string;
  team_id: string;
  type: string;
  content: Record<string, any>;
  embedding?: Record<string, any>;
  confidence: number;
  created_at?: string;
}

export interface SemanticMemory {
  id?: string;
  pattern_key: string;
  pattern_doc: Record<string, any>;
  provenance: Record<string, any>;
  usefulness_score: number;
  safety_review: boolean;
  created_at?: string;
}

export interface PatternSuggestion {
  id?: string;
  team_id: string;
  suggestion: Record<string, any>;
  status: 'pending' | 'approved' | 'rejected';
  created_at?: string;
}

export interface AnalysisRecord {
  id?: string;
  user_id?: string;
  input: AnalysisInput;
  output: WaveAnalysis;
  created_at?: string;
}

export interface HistoricalFacilityRequest {
  team_id?: string;
  player_id?: string;
  date_range?: {
    start: string;
    end: string;
  };
}

export interface HistoricalFacilityResponse {
  team_id?: string;
  analyses: AnalysisRecord[];
  patterns: SemanticMemory[];
  summary: string;
}

export interface PatternAnalysisResult {
  team_id: string;
  promotions: Array<{
    pattern_key: string;
    occurrences: number;
    avg_confidence: number;
    promoted: boolean;
  }>;
  demotions: Array<{
    id: string;
    pattern_key: string;
    reason: string;
  }>;
  suggestions: string[];
}
export interface WaveAnalysis {
  team_evaluated: string;
  scoring_tendency_profile: {
    first_half_behavior: string;
    burst_scoring_pattern: string;
    dual_offense_activation: string;
    low_output_signature: string;
  };
  consistency_matrix: {
    stability_index: number;
    volatility_index: number;
    inner_strength_rating: number;
    required_value_metric: number;
    instability_factors?: string[];
  };
  statistical_overview: {
    avg_goals_for?: number;
    avg_goals_against?: number;
    avg_xg?: number;
    avg_xga?: number;
    clean_sheet_rate_last10?: number;
    xg_trends?: string;
    momentum_notes?: string;
  };
  historical_trends: string[];
  safe_insight_summary: string;
  interactive_steps: string[];
}
