export interface MatchData {
  date: string;
  opponent?: string;
  gf: number;
  ga: number;
  venue: 'home' | 'away';
}

export interface AnalysisInput {
  team: string;
  league?: string;
  notes?: string;
  recent_matches?: MatchData[];
}

export interface AnalysisResult {
  team: string;
  league?: string;
  matchesAnalyzed: number;
  avgGoalsFor: number;
  avgGoalsAgainst: number;
  formScore: number; // 0–1
  confidence: number; // 0–1
  insight: string;
}
