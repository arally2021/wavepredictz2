import { getEpisodicMemory, getSemanticMemory, evaluatePromotions } from './memoryService';
import type { PatternAnalysisResult } from '../types/wavepredictz';

export async function analyzePatternsService(teamId: string): Promise<PatternAnalysisResult> {
  // 1. Load episodic memories for the team
  const episodes = await getEpisodicMemory(teamId, 100);

  // 2. Load current semantic patterns
  const semanticPatterns = await getSemanticMemory();

  // 3. Evaluate patterns for promotion/demotion
  const evaluation = await evaluatePromotions(teamId);

  return evaluation;
}
