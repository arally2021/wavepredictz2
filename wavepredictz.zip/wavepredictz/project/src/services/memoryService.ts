import type { WaveAnalysis } from '../types/wavepredictz';
import { fetchHistoricalMatches } from '../db/dbClient';

export async function analyzeTeamMemory(teamId: string): Promise<Partial<WaveAnalysis>> {
  const matches = await fetchHistoricalMatches(teamId);

  if (!matches.length) return {};

  // Example reasoning
  const totalGoalsFor = matches.reduce((sum, m) => sum + m.goals_for, 0);
  const totalGoalsAgainst = matches.reduce((sum, m) => sum + m.goals_against, 0);
  const avgGoalsFor = totalGoalsFor / matches.length;
  const avgGoalsAgainst = totalGoalsAgainst / matches.length;

  // Determine tendencies
  const firstHalfBehavior = matches.filter(m => m.first_half_goals > 1).length / matches.length > 0.5
    ? 'Aggressive early'
    : 'Conservative early';
    
  const burstPattern = matches.some(m => m.goals_in_burst > 2) ? 'High burst' : 'Moderate burst';
  
  // Semantic promotions (patterns repeated across matches)
  const instabilityFactors = matches.filter(m => m.goals_for < 1).length > matches.length / 3 
    ? ['Low scoring consistency'] 
    : [];

  return {
    statistical_overview: {
      avg_goals_for: avgGoalsFor,
      avg_goals_against: avgGoalsAgainst,
      xg_trends: avgGoalsFor > 1.5 ? 'High xG' : 'Moderate xG',
      momentum_notes: avgGoalsFor > avgGoalsAgainst ? 'Positive momentum' : 'Neutral',
    },
    scoring_tendency_profile: {
      first_half_behavior: firstHalfBehavior,
      burst_scoring_pattern: burstPattern,
      dual_offense_activation: 'Dynamic',
      low_output_signature: avgGoalsFor < 1.5 ? 'Low output' : 'Strong output',
    },
    consistency_matrix: {
      stability_index: avgGoalsFor / (avgGoalsFor + avgGoalsAgainst),
      volatility_index: Math.random(), // can add historical variance computation
      inner_strength_rating: Math.random(),
      required_value_metric: Math.random(),
      instability_factors,
    },
    historical_trends: matches.map(m => `${m.date}: ${m.goals_for} - ${m.goals_against}`),
  };
}
