import { supabase } from './supabase';
import { getEpisodicMemory, getSemanticMemory } from './memoryService';
import type { AnalysisInput, WaveAnalysis, HistoricalFacilityResponse } from '../types/wavepredictz';

export async function generateAnalysis(input: AnalysisInput): Promise<WaveAnalysis> {
  // Implement scoring, consistency, trends, safe summary
  const matches = input.recent_matches || [];
  const avgGoalsFor = matches.reduce((sum, m) => sum + m.gf, 0) / Math.max(matches.length, 1);
  const avgGoalsAgainst = matches.reduce((sum, m) => sum + m.ga, 0) / Math.max(matches.length, 1);

  const stabilityIndex = 1 - (matches.reduce((acc, m) => acc + Math.pow(m.gf - avgGoalsFor, 2), 0) / Math.max(matches.length, 1)) / 4;
  const formTrend = matches.slice(0, 3).reduce((sum, m) => sum + (m.gf > m.ga ? 1 : m.gf === m.ga ? 0.5 : 0), 0) / Math.max(matches.slice(0, 3).length, 1);

  return {
    team_evaluated: input.team,
    scoring_tendency_profile: { /* build full profile */ },
    consistency_matrix: { stability_index: stabilityIndex, inner_strength_rating: formTrend },
    statistical_overview: { avg_goals_for: avgGoalsFor, avg_goals_against: avgGoalsAgainst },
    historical_trends: [`Average goals: ${avgGoalsFor.toFixed(2)}`, `Stability: ${stabilityIndex.toFixed(2)}`],
    safe_insight_summary: `${input.team} shows ${stabilityIndex > 0.6 ? 'consistent' : 'variable'} performance with ${avgGoalsFor > 1 ? 'strong' : 'low'} offensive output.`,
    interactive_steps: ['Review trends', 'Examine scoring profile', 'Monitor recent form']
  };
}

export async function getHistoricalFacility(request: { team_id?: string }): Promise<HistoricalFacilityResponse> {
  const { data: analyses } = await supabase
    .from('analyses')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(50)
    .eq(request.team_id ? 'input->team' : undefined, request.team_id || undefined);

  const episodes = request.team_id ? await getEpisodicMemory(request.team_id) : [];
  const patterns = await getSemanticMemory();

  return {
    team_id: request.team_id,
    analyses: analyses || [],
    patterns,
    summary: `Retrieved ${analyses?.length || 0} analyses, ${episodes.length} episodic memories, ${patterns.length} semantic patterns`
  };
}
