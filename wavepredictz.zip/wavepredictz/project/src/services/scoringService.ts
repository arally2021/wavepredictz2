import type { WaveAnalysis } from '../types/wavepredictz';
import { analyzeTeamMemory } from './memoryService';

export async function generateScoringProfile(teamId: string): Promise<WaveAnalysis> {
  const memoryData = await analyzeTeamMemory(teamId);

  return {
    team_evaluated: teamId,
    scoring_tendency_profile: memoryData.scoring_tendency_profile!,
    consistency_matrix: memoryData.consistency_matrix!,
    statistical_overview: memoryData.statistical_overview!,
    historical_trends: memoryData.historical_trends || [],
    safe_insight_summary: `Team ${teamId} demonstrates ${memoryData.consistency_matrix?.stability_index! > 0.6 ? 'highly consistent' : 'variable'} performance based on historical memory.`,
    interactive_steps: [
      'Review scoring tendency profile',
      'Analyze consistency matrix',
      'Check statistical overview',
      'Examine historical trends',
    ],
  };
}
