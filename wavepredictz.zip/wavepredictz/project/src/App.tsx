import { useState } from 'react';
import { Activity, Database, Sparkles, Target, Menu, X, BarChart3, Wrench, Radio, Zap, Clock, Home } from 'lucide-react';
import type { TimezoneMode } from './lib/timezone';
import { getTimezoneLabel } from './lib/timezone';
import { SubscriptionProvider, useSubscription } from './context/SubscriptionContext';
import AnalysisForm from './components/AnalysisForm';
import LiveStatsDisplay from './components/LiveStatsDisplay';
import LiveAnalyst from './components/LiveAnalyst';
import FreshFetch from './components/FreshFetch';
import PipelineDebug from './components/PipelineDebug';
import ScoringProfile from './components/ScoringProfile';
import HistoricalFacility from './components/HistoricalFacility';
import PatternAnalysis from './components/PatternAnalysis';
import LandingPage from './components/LandingPage';
import MatchPredictionView from './components/MatchPredictionView';
import { generateAnalysisWithRealData, saveAnalysis } from './lib/analysisService';
import type { AnalysisInput, WaveAnalysis } from './types/wavepredictz';

type View = 'landing' | 'home' | 'live-analyst' | 'fresh-fetch' | 'live-stats' | 'pipeline-debug' | 'analyze' | 'historical' | 'patterns' | 'predictions';

function AppContent() {
  const { tier } = useSubscription();
  const [currentView, setCurrentView] = useState<View>('landing');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [currentAnalysis, setCurrentAnalysis] = useState<WaveAnalysis | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [tzMode, setTzMode] = useState<TimezoneMode>('local');

  const handleAnalyze = async (input: AnalysisInput) => {
    setLoading(true);
    setError('');

    try {
      const analysis = await generateAnalysisWithRealData(input, true);
      setCurrentAnalysis(analysis);
      await saveAnalysis(input, analysis);
      setCurrentView('analyze');
    } catch (err) {
      setError('Analysis failed. Please check your input and try again.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const navItems = [
    { id: 'landing' as View, label: 'Home', icon: Home, short: 'Home' },
    { id: 'home' as View, label: 'New Analysis', icon: Target, short: 'Analyze' },
    { id: 'live-analyst' as View, label: 'Live Analyst', icon: Radio, short: 'Live' },
    { id: 'fresh-fetch' as View, label: 'Fresh Fetch', icon: Zap, short: 'Fetch' },
    { id: 'live-stats' as View, label: 'Live Stats', icon: BarChart3, short: 'Stats' },
    { id: 'pipeline-debug' as View, label: 'Diagnostic', icon: Wrench, short: 'Diag' },
    { id: 'analyze' as View, label: 'Current Analysis', icon: Activity, short: 'Current' },
    { id: 'historical' as View, label: 'Historical Data', icon: Database, short: 'History' },
    { id: 'patterns' as View, label: 'Pattern Analysis', icon: Sparkles, short: 'Patterns' },
    { id: 'predictions' as View, label: 'Predictions', icon: Zap, short: 'Predict' }
  ];

  const isLanding = currentView === 'landing';
  const isDarkView = currentView === 'predictions';

  return (
    <div className={isLanding ? 'min-h-screen bg-slate-900' : isDarkView ? 'min-h-screen bg-slate-950' : 'min-h-screen bg-gradient-to-br from-gray-50 to-blue-50'}>
      {!isLanding && (
      <nav className={`shadow-lg sticky top-0 z-50 ${isDarkView ? 'bg-slate-900 border-b border-white/5' : 'bg-white'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Activity className={`w-8 h-8 mr-3 ${isDarkView ? 'text-emerald-400' : 'text-blue-600'}`} />
              <div>
                <h1 className={`text-xl font-bold ${isDarkView ? 'text-white' : 'text-gray-900'}`}>WavePredictz</h1>
                <p className={`text-xs ${isDarkView ? 'text-slate-400' : 'text-gray-600'}`}>Super-Advanced Analytics Engine</p>
              </div>
            </div>

            <div className="hidden lg:flex items-center gap-0.5 xl:gap-1 max-w-[calc(100vw-260px)] overflow-x-auto dark-scroll">
              <div className="flex items-center gap-1 mr-1 px-2 py-1 bg-gray-50 rounded-lg border border-gray-200 flex-shrink-0">
                <Clock className="w-3.5 h-3.5 text-gray-400" />
                <button
                  onClick={() => setTzMode('local')}
                  className={`px-2 py-0.5 text-xs font-medium rounded transition ${
                    tzMode === 'local' ? 'bg-blue-600 text-white' : 'text-gray-600 hover:text-gray-900'
                  }`}
                  title={`Your local time (${getTimezoneLabel('local')})`}
                >
                  Local
                </button>
                <button
                  onClick={() => setTzMode('stadium')}
                  className={`px-2 py-0.5 text-xs font-medium rounded transition ${
                    tzMode === 'stadium' ? 'bg-blue-600 text-white' : 'text-gray-600 hover:text-gray-900'
                  }`}
                  title={`Stadium/UK time (${getTimezoneLabel('stadium')})`}
                >
                  Stadium
                </button>
              </div>
              {navItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setCurrentView(item.id);
                      setError('');
                    }}
                    className={`flex items-center gap-1 xl:gap-1.5 px-2 xl:px-3 py-2 rounded-lg transition-colors flex-shrink-0 ${
                      currentView === item.id
                        ? isDarkView ? 'bg-emerald-600 text-white' : 'bg-blue-600 text-white'
                        : isDarkView ? 'text-slate-300 hover:bg-white/5' : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span className="text-xs xl:text-sm font-medium whitespace-nowrap">{item.short}</span>
                  </button>
                );
              })}
            </div>

            <div className="lg:hidden flex items-center">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className={isDarkView ? 'text-slate-300 hover:text-white' : 'text-gray-700 hover:text-gray-900'}
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {mobileMenuOpen && !isLanding && (
          <div className={`lg:hidden border-t ${isDarkView ? 'bg-slate-900 border-white/5' : 'bg-white border-gray-200'}`}>
            <div className="px-4 py-3 space-y-2">
              <div className="flex items-center gap-2 px-4 py-2 flex-wrap">
                <Clock className="w-4 h-4 text-gray-400" />
                <span className="text-xs text-gray-500 font-medium">Timezone</span>
                <button
                  onClick={() => setTzMode('local')}
                  className={`px-2 py-0.5 text-xs font-medium rounded ${
                    tzMode === 'local' ? 'bg-blue-600 text-white' : 'text-gray-600 bg-gray-100'
                  }`}
                >
                  Local ({getTimezoneLabel('local')})
                </button>
                <button
                  onClick={() => setTzMode('stadium')}
                  className={`px-2 py-0.5 text-xs font-medium rounded ${
                    tzMode === 'stadium' ? 'bg-blue-600 text-white' : 'text-gray-600 bg-gray-100'
                  }`}
                >
                  Stadium ({getTimezoneLabel('stadium')})
                </button>
              </div>
              {navItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setCurrentView(item.id);
                      setMobileMenuOpen(false);
                      setError('');
                    }}
                    className={`w-full flex items-center gap-2 px-4 py-3 rounded-lg transition-colors ${
                      currentView === item.id
                        ? isDarkView ? 'bg-emerald-600 text-white' : 'bg-blue-600 text-white'
                        : isDarkView ? 'text-slate-300 hover:bg-white/5' : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="font-medium">{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </nav>
      )}

      {isLanding ? (
        <LandingPage onGetStarted={() => setCurrentView('home')} />
      ) : (
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
            <p className="text-red-700">{error}</p>
          </div>
        )}

        {currentView === 'home' && (
          <div className="space-y-8">
            <div className="text-center mb-8">
              <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                Football Intelligence System
              </h2>
              <p className="text-base sm:text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">
                Safe, educational tactical analysis specializing in scoring patterns, consistency
                metrics, and behavioral insights
              </p>
              <div className="mt-6 flex flex-wrap justify-center gap-4 text-sm text-gray-600">
                <div className="flex items-center gap-2 bg-white px-4 py-2 rounded-lg shadow">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>Non-Gambling</span>
                </div>
                <div className="flex items-center gap-2 bg-white px-4 py-2 rounded-lg shadow">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <span>Educational</span>
                </div>
                <div className="flex items-center gap-2 bg-white px-4 py-2 rounded-lg shadow">
                  <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                  <span>Safe for Minors</span>
                </div>
              </div>
            </div>

            <AnalysisForm onSubmit={handleAnalyze} loading={loading} />

            <div className="bg-white rounded-lg shadow-md p-8">
              <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-6">System Capabilities</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <h4 className="font-semibold text-gray-800 flex items-center gap-2">
                    <Target className="w-5 h-5 text-blue-600" />
                    Scoring Tendency Analysis
                  </h4>
                  <ul className="text-sm text-gray-600 space-y-2 pl-7">
                    <li>• Low First-Half Scoring Archetype</li>
                    <li>• High First-Half Control Pattern</li>
                    <li>• Burst-Scoring Engine Profile</li>
                    <li>• Dual-Offense Activation Index</li>
                  </ul>
                </div>
                <div className="space-y-3">
                  <h4 className="font-semibold text-gray-800 flex items-center gap-2">
                    <Activity className="w-5 h-5 text-green-600" />
                    Consistency Framework
                  </h4>
                  <ul className="text-sm text-gray-600 space-y-2 pl-7">
                    <li>• Stability Index measurement</li>
                    <li>• Volatility tracking</li>
                    <li>• Inner Strength Rating</li>
                    <li>• Required Value Metric</li>
                  </ul>
                </div>
                <div className="space-y-3">
                  <h4 className="font-semibold text-gray-800 flex items-center gap-2">
                    <Database className="w-5 h-5 text-teal-600" />
                    Memory Systems
                  </h4>
                  <ul className="text-sm text-gray-600 space-y-2 pl-7">
                    <li>• Episodic memory storage</li>
                    <li>• Semantic pattern promotion</li>
                    <li>• Historical facility access</li>
                    <li>• Pattern usefulness scoring</li>
                  </ul>
                </div>
                <div className="space-y-3">
                  <h4 className="font-semibold text-gray-800 flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-purple-600" />
                    Pattern Discovery
                  </h4>
                  <ul className="text-sm text-gray-600 space-y-2 pl-7">
                    <li>• Automatic pattern detection</li>
                    <li>• Confidence scoring</li>
                    <li>• Promotion/demotion logic</li>
                    <li>• Safety review workflows</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}

        {currentView === 'live-analyst' && <LiveAnalyst tzMode={tzMode} />}

        {currentView === 'fresh-fetch' && <FreshFetch tzMode={tzMode} />}

        {currentView === 'live-stats' && <LiveStatsDisplay />}

        {currentView === 'pipeline-debug' && <PipelineDebug />}

        {currentView === 'analyze' && (
          <div>
            {currentAnalysis ? (
              <ScoringProfile data={currentAnalysis} />
            ) : (
              <div className="bg-white rounded-lg shadow-md p-12 text-center">
                <Activity className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 mb-4">No analysis available</p>
                <button
                  onClick={() => setCurrentView('home')}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Create New Analysis
                </button>
              </div>
            )}
          </div>
        )}

        {currentView === 'historical' && <HistoricalFacility />}

        {currentView === 'patterns' && <PatternAnalysis />}

        {currentView === 'predictions' && <MatchPredictionView />}
      </main>
      )}

      {!isLanding && (
      <footer className={`mt-16 ${isDarkView ? 'bg-slate-900 border-t border-white/5' : 'bg-white border-t border-gray-200'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center text-gray-600 text-sm">
            <p className="mb-2">
              <strong>WavePredictz</strong> - Safe Educational Football Analytics
            </p>
            <p className="text-xs text-gray-500">
              This system provides tactical analysis and pattern recognition for educational
              purposes only. No gambling or wagering guidance is provided.
            </p>
          </div>
        </div>
      </footer>
      )}
    </div>
  );
}

export default function App() {
  return (
    <SubscriptionProvider>
      <AppContent />
    </SubscriptionProvider>
  );
}
