export interface StripeProduct {
  id: string;
  priceId: string;
  name: string;
  description: string;
  price: number;
  currencySymbol: string;
  mode: 'subscription' | 'payment';
}

export const STRIPE_PRODUCTS: StripeProduct[] = [
  {
    id: 'prod_Tj5MC6wcnE11hV',
    priceId: 'price_1SldBJJUGXF0jxHBxgqFQts3',
    name: 'Football Prediction',
    description:
      'WavePredict Football Analytics is an intelligent match analysis platform designed to support informed football predictions through structured reasoning, probability modeling, and scenario evaluation. It combines statistical trends, contextual factors, and collective insight to produce clear, explainable forecasts. WavePredict emphasizes transparency, discipline, and conscious decision-making over hype or guarantees.',
    price: 5.0,
    currencySymbol: '$',
    mode: 'subscription',
  },
];

export const getProductByPriceId = (priceId: string): StripeProduct | undefined =>
  STRIPE_PRODUCTS.find((p) => p.priceId === priceId);