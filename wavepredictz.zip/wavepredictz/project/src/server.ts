import express from 'express';
import cors from 'cors';
import analysisRoutes from './routes/analysisRoutes';
import patternRoutes from './routes/patternRoutes';
import historicalFacilityRoutes from './routes/historicalFacility';
import scoringRoutes from './routes/scoringRoutes';

const app = express();

app.use(cors());
app.use(express.json());

app.use('/api/analysis', analysisRoutes);
app.use('/api/pattern', patternRoutes);
app.use('/api', historicalFacilityRoutes);
app.use('/api/scoring', scoringRoutes);

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Backend running on port ${PORT}`));

