import { Request, Response } from 'express';
import { generateScoringProfile } from '../services/scoringService';

export const getScoringProfile = async (req: Request, res: Response) => {
  try {
    const { teamId } = req.params;
    if (!teamId) return res.status(400).json({ error: 'Team ID is required' });

    const profile = await generateScoringProfile(teamId);
    res.json(profile);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to generate scoring profile' });
  }
};
