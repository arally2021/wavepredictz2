import { Request, Response } from 'express';
import { analyzePatternsService } from '../services/patternService';

export const handlePatternAnalysis = async (req: Request, res: Response) => {
  try {
    const { teamId } = req.body;
    if (!teamId) return res.status(400).json({ error: 'teamId is required' });

    const result = await analyzePatternsService(teamId);
    res.json(result);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to analyze patterns' });
  }
};
