import { Request, Response } from 'express';
import { getHistoricalFacility, generateAnalysis } from '../services/analysisService';

export const handleHistoricalAnalysis = async (req: Request, res: Response) => {
  try {
    const { teamId } = req.query;
    const data = await getHistoricalFacility({ team_id: teamId as string });
    res.json(data);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch historical analysis' });
  }
};

export const handleGenerateAnalysis = async (req: Request, res: Response) => {
  try {
    const input = req.body;
    const analysis = await generateAnalysis(input);
    res.json(analysis);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to generate analysis' });
  }
};
