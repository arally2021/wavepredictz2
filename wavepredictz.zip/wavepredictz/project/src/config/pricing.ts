import type { PricingTier } from '../types/subscription';

export const PRICING_TIERS: PricingTier[] = [
  {
    id: 'casual',
    name: 'Casual Fans',
    tagline: 'Basic AI match simulations & win probabilities',
    monthlyPrice: 25,
    annualPrice: 240,
    features: [
      'Basic AI match simulations',
      'Win probability predictions',
      'Clean, intuitive dashboards',
      '3 free predictions per day',
      'Educational tactical insights',
    ],
    ctaLabel: 'Get 3 Free Predictions / Day',
    ctaStyle: 'primary',
  },
  {
    id: 'pro',
    name: 'Professional Traders & Syndicates',
    tagline: 'Value-betting streams & backtesting datasets',
    monthlyPrice: 99,
    annualPrice: 948,
    features: [
      'Value-betting streams (Expected Value)',
      'Prop-bet models',
      'Backtesting datasets',
      'Advanced pattern recognition',
      'Historical facility access',
      'Priority data refresh',
    ],
    ctaLabel: 'Go Professional',
    ctaStyle: 'neon',
    popular: true,
    badge: 'Most Popular',
  },
  {
    id: 'b2b',
    name: 'B2B API Integration',
    tagline: 'Data access keys for developers & apps',
    monthlyPrice: 79,
    annualPrice: 756,
    features: [
      'Developer data access keys',
      'Custom scraper endpoints',
      'App integration APIs',
      'Webhook event delivery',
      'Rate-limited production access',
      'Technical documentation',
    ],
    ctaLabel: 'Get API Access',
    ctaStyle: 'outline',
  },
  {
    id: 'elite',
    name: 'Elite Teams & Media',
    tagline: 'Advanced spatial tracking & predictive metrics',
    monthlyPrice: 599,
    annualPrice: 5748,
    features: [
      'Advanced spatial tracking data',
      'Predictive player metrics (xG, xA)',
      'Video alignment tools',
      'Custom model integration',
      'Dedicated account manager',
      'White-label options',
    ],
    ctaLabel: 'Contact Sales',
    ctaStyle: 'contact',
  },
];

export const ANNUAL_DISCOUNT = 0.2;

export function formatPrice(price: number, cycle: 'monthly' | 'annual'): string {
  if (cycle === 'annual') {
    const monthly = price / 12;
    return `$${monthly.toFixed(0)}`;
  }
  return `$${price}`;
}
