// Stripe Price ID configuration map.
// These map each subscription tier to its Stripe Price ID for both billing cycles.
export const STRIPE_PRICING_MAP: Record<string, { monthly: string; annual: string }> = {
  casual: {
    monthly: 'price_1UBxOqGgWeF9kZ8tomZ8KNEw',
    annual: 'price_YOUR_CASUAL_ANNUAL_ID_HERE',
  },
  professional: {
    monthly: 'price_1UBxMqGgWeF9kZ8tB5hXlYqZ',
    annual: 'price_YOUR_PRO_ANNUAL_ID_HERE',
  },
  b2b: {
    monthly: 'price_1UBxRMGgWeF9kZ8tR8y5OY9X',
    annual: 'price_YOUR_B2B_ANNUAL_ID_HERE',
  },
  elite: {
    monthly: 'price_1UBxQ4GgWeF9kZ8teg8wGeia',
    annual: 'price_YOUR_ELITE_ANNUAL_ID_HERE',
  },
};

// Tier name used in the checkout edge function metadata
export const TIER_METADATA_MAP: Record<string, string> = {
  casual: 'casual_fans',
  professional: 'professional_trader',
  pro: 'professional_trader',
  b2b: 'b2b_api',
  elite: 'elite_teams_media',
};
