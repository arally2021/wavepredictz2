// pattern.service.ts
import { evaluatePromotions } from './memory.engine';
import type { PatternAnalysisResult } from '../types/wavepredictz';

export async function analyzeTeamPatterns(
  team_id: string
): Promise<PatternAnalysisResult> {
  return evaluatePromotions(team_id);
}
