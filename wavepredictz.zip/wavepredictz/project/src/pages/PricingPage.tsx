import React from 'react';
import { Check, Zap, Shield, TrendingUp, Brain } from 'lucide-react';
import { STRIPE_PRODUCTS } from '../stripe-config';
import { useCheckout } from '../hooks/useCheckout';
import { useSubscription } from '../hooks/useSubscription';
import { supabase } from '../lib/supabase';
import { useEffect, useState } from 'react';

const features = [
  { icon: Brain, text: 'AI-powered match analysis & probability modeling' },
  { icon: TrendingUp, text: 'Statistical trends & contextual factor evaluation' },
  { icon: Shield, text: 'Structured reasoning with transparent forecasts' },
  { icon: Zap, text: 'Real-time scenario evaluation & collective insights' },
];

export default function PricingPage() {
  const { startCheckout, loading, error } = useCheckout();
  const [userId, setUserId] = useState<string | undefined>(undefined);
  const { subscription } = useSubscription(userId);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUserId(session?.user?.id);
    });
  }, []);

  const product = STRIPE_PRODUCTS[0];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-20 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-sm font-medium mb-6">
            Simple Pricing
          </span>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 tracking-tight">
            Unlock Football Intelligence
          </h1>
          <p className="text-slate-400 text-lg max-w-2xl mx-auto leading-relaxed">
            Get access to structured match analysis, probability modeling, and transparent forecasts
            designed for disciplined decision-making.
          </p>
        </div>

        {/* Pricing Card */}
        <div className="relative max-w-lg mx-auto">
          <div className="absolute inset-0 bg-emerald-500/5 rounded-3xl blur-xl" />
          <div className="relative bg-slate-800/60 backdrop-blur-sm border border-slate-700/50 rounded-3xl p-8 md:p-10">
            {/* Badge */}
            <div className="flex items-center justify-between mb-8">
              <span className="px-3 py-1 bg-emerald-500/20 border border-emerald-500/30 rounded-full text-emerald-400 text-xs font-semibold uppercase tracking-wider">
                Monthly Subscription
              </span>
              {subscription.isActive && (
                <span className="px-3 py-1 bg-blue-500/20 border border-blue-500/30 rounded-full text-blue-400 text-xs font-semibold">
                  ✓ Active Plan
                </span>
              )}
            </div>

            {/* Product Name & Price */}
            <h2 className="text-2xl font-bold text-white mb-2">{product.name}</h2>
            <div className="flex items-baseline gap-1 mb-6">
              <span className="text-5xl font-bold text-white">
                {product.currencySymbol}{product.price.toFixed(2)}
              </span>
              <span className="text-slate-400 text-lg">/month</span>
            </div>

            {/* Description */}
            <p className="text-slate-400 text-sm leading-relaxed mb-8 border-t border-slate-700/50 pt-6">
              {product.description}
            </p>

            {/* Features */}
            <ul className="space-y-3 mb-8">
              {features.map(({ icon: Icon, text }) => (
                <li key={text} className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-5 h-5 rounded-full bg-emerald-500/20 flex items-center justify-center mt-0.5">
                    <Check className="w-3 h-3 text-emerald-400" />
                  </div>
                  <span className="text-slate-300 text-sm">{text}</span>
                </li>
              ))}
            </ul>

            {/* Error */}
            {error && (
              <div className="mb-4 p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm">
                {error}
              </div>
            )}

            {/* CTA Button */}
            <button
              onClick={() => startCheckout(product.priceId, product.mode)}
              disabled={loading || subscription.isActive}
              className="w-full py-4 rounded-2xl font-semibold text-base transition-all duration-200 disabled:opacity-60 disabled:cursor-not-allowed
                bg-emerald-500 hover:bg-emerald-400 active:scale-[0.98] text-white shadow-lg shadow-emerald-500/25 hover:shadow-emerald-500/40"
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                  </svg>
                  Redirecting to Checkout…
                </span>
              ) : subscription.isActive ? (
                'Already Subscribed'
              ) : (
                'Subscribe Now'
              )}
            </button>

            <p className="text-center text-slate-500 text-xs mt-4">
              Secure payment via Stripe · Cancel anytime
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}