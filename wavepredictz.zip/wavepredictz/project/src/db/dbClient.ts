interface Match {
  date: string;
  goals_for: number;
  goals_against: number;
  first_half_goals: number;
  goals_in_burst: number;
}

export async function fetchHistoricalMatches(teamId: string): Promise<Match[]> {
  // Replace with real DB query
  return [
    { date: '2025-01-01', goals_for: 2, goals_against: 1, first_half_goals: 1, goals_in_burst: 2 },
    { date: '2025-01-08', goals_for: 1, goals_against: 2, first_half_goals: 0, goals_in_burst: 0 },
    { date: '2025-01-15', goals_for: 3, goals_against: 0, first_half_goals: 2, goals_in_burst: 3 },
  ];
}
