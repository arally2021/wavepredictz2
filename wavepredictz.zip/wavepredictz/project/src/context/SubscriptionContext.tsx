import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react';
import type { SubscriptionTier, SubscriptionState } from '../types/subscription';
import { supabase } from '../lib/supabase';

interface SubscriptionContextValue extends SubscriptionState {
  refresh: () => Promise<void>;
  setTier: (tier: SubscriptionTier) => void;
  signOut: () => Promise<void>;
}

const SubscriptionContext = createContext<SubscriptionContextValue | undefined>(undefined);

const TIER_PRIORITY: Record<SubscriptionTier, number> = {
  free: 0,
  casual: 1,
  pro: 2,
  b2b: 3,
  elite: 4,
};

export function tierMeets(tier: SubscriptionTier, required: SubscriptionTier): boolean {
  return TIER_PRIORITY[tier] >= TIER_PRIORITY[required];
}

export function useSubscription() {
  const ctx = useContext(SubscriptionContext);
  if (!ctx) throw new Error('useSubscription must be used within SubscriptionProvider');
  return ctx;
}

export function SubscriptionProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<SubscriptionState>({
    tier: 'free',
    isAuthenticated: false,
    isLoading: true,
    userId: null,
    email: null,
  });

  const fetchState = useCallback(async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) {
        setState({
          tier: 'free',
          isAuthenticated: false,
          isLoading: false,
          userId: null,
          email: null,
        });
        return;
      }

      const { data: userRow } = await supabase
        .from('users')
        .select('subscription_tier, access_level, email')
        .eq('id', session.user.id)
        .maybeSingle();

      setState({
        tier: (userRow?.subscription_tier as SubscriptionTier) || 'free',
        isAuthenticated: true,
        isLoading: false,
        userId: session.user.id,
        email: userRow?.email || session.user.email || null,
      });
    } catch {
      setState({
        tier: 'free',
        isAuthenticated: false,
        isLoading: false,
        userId: null,
        email: null,
      });
    }
  }, []);

  useEffect(() => {
    fetchState();

    const { data: authListener } = supabase.auth.onAuthStateChange(() => {
      fetchState();
    });

    return () => {
      authListener.subscription.unsubscribe();
    };
  }, [fetchState]);

  const setTier = useCallback((tier: SubscriptionTier) => {
    setState(prev => ({ ...prev, tier }));
  }, []);

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
    setState({
      tier: 'free',
      isAuthenticated: false,
      isLoading: false,
      userId: null,
      email: null,
    });
  }, []);

  return (
    <SubscriptionContext.Provider value={{ ...state, refresh: fetchState, setTier, signOut }}>
      {children}
    </SubscriptionContext.Provider>
  );
}
